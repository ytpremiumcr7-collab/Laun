import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play, Pause, Volume2, Volume1, VolumeX, Maximize, Minimize,
  SkipBack, SkipForward, Settings, Film
} from 'lucide-react';

/* ── sample videos ── */
interface VideoInfo {
  id: number;
  title: string;
  duration: number;
  color: string;
}

const SAMPLE_VIDEOS: VideoInfo[] = [
  { id: 1, title: 'Cornstone OS Overview', duration: 525, color: '#C9A84C' },
  { id: 2, title: 'Getting Started Tutorial', duration: 783, color: '#5A8AB8' },
  { id: 3, title: 'Advanced Features Guide', duration: 1240, color: '#5A9E6F' },
  { id: 4, title: 'Developer Documentation', duration: 960, color: '#7B6FB8' },
];

function formatTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function VideoPlayer() {
  const [currentVideo, setCurrentVideo] = useState<VideoInfo>(SAMPLE_VIDEOS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(80);
  const [speed, setSpeed] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [fileLoaded, setFileLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const controlsTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  /* Simulated playback */
  useEffect(() => {
    if (isPlaying) {
      progressInterval.current = setInterval(() => {
        setProgress(prev => {
          if (prev >= currentVideo.duration) {
            setIsPlaying(false);
            return currentVideo.duration;
          }
          return prev + (0.5 * speed);
        });
      }, 500);
    } else {
      if (progressInterval.current) clearInterval(progressInterval.current);
    }
    return () => { if (progressInterval.current) clearInterval(progressInterval.current); };
  }, [isPlaying, currentVideo, speed]);

  /* Canvas animation for placeholder video */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animId: number;

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;

      /* Background gradient */
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#0A0A0F');
      grad.addColorStop(1, '#12121A');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      /* Animated wave pattern */
      const time = Date.now() * 0.001;
      ctx.strokeStyle = `${currentVideo.color}40`;
      ctx.lineWidth = 1.5;
      for (let y = 0; y < h; y += 20) {
        ctx.beginPath();
        for (let x = 0; x < w; x += 5) {
          const offset = Math.sin(x * 0.01 + time + y * 0.005) * 10;
          if (x === 0) ctx.moveTo(x, y + offset);
          else ctx.lineTo(x, y + offset);
        }
        ctx.stroke();
      }

      /* Central play icon area */
      ctx.fillStyle = `${currentVideo.color}20`;
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 50, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = `${currentVideo.color}60`;
      ctx.lineWidth = 2;
      ctx.stroke();

      /* Play triangle */
      if (!isPlaying) {
        ctx.fillStyle = currentVideo.color;
        ctx.beginPath();
        ctx.moveTo(w / 2 - 12, h / 2 - 16);
        ctx.lineTo(w / 2 + 16, h / 2);
        ctx.lineTo(w / 2 - 12, h / 2 + 16);
        ctx.closePath();
        ctx.fill();
      }

      /* Progress indicator on canvas */
      const pct = progress / currentVideo.duration;
      ctx.fillStyle = `${currentVideo.color}30`;
      ctx.fillRect(0, h - 4, w * pct, 4);

      /* Title */
      ctx.fillStyle = '#E8E4DC';
      ctx.font = '16px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(currentVideo.title, w / 2, h - 30);
      ctx.fillStyle = '#8A8578';
      ctx.font = '12px Inter, sans-serif';
      ctx.fillText(formatTime(progress) + ' / ' + formatTime(currentVideo.duration), w / 2, h - 14);

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, [currentVideo, isPlaying, progress]);

  /* Controls auto-hide */
  const handleMouseMove = useCallback(() => {
    setShowControls(true);
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
    if (isPlaying) {
      controlsTimeout.current = setTimeout(() => setShowControls(false), 3000);
    }
  }, [isPlaying]);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  const progressPercent = currentVideo.duration > 0 ? (progress / currentVideo.duration) * 100 : 0;

  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileLoaded(true);
      setCurrentVideo({
        id: Date.now(),
        title: file.name,
        duration: 300,
        color: '#C9A84C',
      });
      setProgress(0);
      setIsPlaying(false);
    }
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden relative select-none"
      onMouseMove={handleMouseMove}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      {/* Video display area */}
      <div className="flex-1 relative bg-[#0A0A0F] flex items-center justify-center overflow-hidden">
        <canvas
          ref={canvasRef}
          width={800}
          height={450}
          className="w-full h-full max-w-full max-h-full cursor-pointer"
          onClick={() => setIsPlaying(!isPlaying)}
        />

        {/* Upload overlay when no file */}
        {!fileLoaded && (
          <div className="absolute top-4 right-4">
            <label className="flex items-center gap-2 px-3 py-2 rounded bg-[#1A1A26]/80 border border-[#2A2A3E] cursor-pointer hover:bg-[#222235] transition-colors text-xs">
              <Film className="w-3.5 h-3.5 text-[#8A8578]" />
              Open File
              <input type="file" accept="video/*" className="hidden" onChange={handleFileUpload} />
            </label>
          </div>
        )}
      </div>

      {/* Controls overlay */}
      <div className={`absolute bottom-0 left-0 right-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent pointer-events-none" />

        <div className="relative z-10 px-3 pb-3 pt-6">
          {/* Progress bar */}
          <div
            className="w-full h-2 bg-white/10 rounded-full cursor-pointer mb-2 hover:h-3 transition-all"
            onClick={e => {
              const rect = e.currentTarget.getBoundingClientRect();
              const pct = (e.clientX - rect.left) / rect.width;
              setProgress(pct * currentVideo.duration);
            }}
          >
            <div
              className="h-full rounded-full relative"
              style={{ width: `${progressPercent}%`, background: currentVideo.color }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-lg opacity-0 hover:opacity-100" />
            </div>
          </div>

          {/* Controls row */}
          <div className="flex items-center gap-2">
            {/* Play/Pause */}
            <button
              className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
              onClick={() => setIsPlaying(!isPlaying)}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
            </button>

            {/* Prev/Next */}
            <button className="p-1.5 text-[#8A8578] hover:text-[#E8E4DC] transition-colors"
              onClick={() => {
                const idx = SAMPLE_VIDEOS.findIndex(v => v.id === currentVideo.id);
                const prevIdx = (idx - 1 + SAMPLE_VIDEOS.length) % SAMPLE_VIDEOS.length;
                setCurrentVideo(SAMPLE_VIDEOS[prevIdx]);
                setProgress(0);
              }}
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button className="p-1.5 text-[#8A8578] hover:text-[#E8E4DC] transition-colors"
              onClick={() => {
                const idx = SAMPLE_VIDEOS.findIndex(v => v.id === currentVideo.id);
                const nextIdx = (idx + 1) % SAMPLE_VIDEOS.length;
                setCurrentVideo(SAMPLE_VIDEOS[nextIdx]);
                setProgress(0);
              }}
            >
              <SkipForward className="w-4 h-4" />
            </button>

            {/* Time */}
            <span className="text-[11px] font-mono text-[#8A8578]">
              {formatTime(progress)} / {formatTime(currentVideo.duration)}
            </span>

            <div className="flex-1" />

            {/* Speed selector */}
            <div className="relative">
              <button
                className="flex items-center gap-1 px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[11px] transition-colors"
                onClick={() => setShowSpeedMenu(!showSpeedMenu)}
              >
                <Settings className="w-3 h-3" /> {speed}x
              </button>
              {showSpeedMenu && (
                <div className="absolute bottom-full right-0 mb-1 w-20 bg-[#1A1A26] border border-[#2A2A3E] rounded shadow-lg overflow-hidden">
                  {[0.5, 1, 1.25, 1.5, 2].map(s => (
                    <button
                      key={s}
                      className={`w-full text-left px-3 py-1.5 text-xs hover:bg-[#222235] transition-colors ${speed === s ? 'text-[#C9A84C]' : ''}`}
                      onClick={() => { setSpeed(s); setShowSpeedMenu(false); }}
                    >
                      {s}x
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Volume */}
            <div className="relative"
              onMouseEnter={() => setShowVolumeSlider(true)}
              onMouseLeave={() => setShowVolumeSlider(false)}
            >
              <button
                className="p-1.5 text-[#8A8578] hover:text-[#E8E4DC]"
                onClick={() => setVolume(v => v === 0 ? 80 : 0)}
              >
                {volume === 0 ? <VolumeX className="w-4 h-4" /> : volume < 50 ? <Volume1 className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              {showVolumeSlider && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-3 bg-[#1A1A26] border border-[#2A2A3E] rounded shadow-lg">
                  <div
                    className="w-1 h-20 bg-white/10 rounded-full cursor-pointer relative"
                    onClick={e => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setVolume(Math.round((1 - (e.clientY - rect.top) / rect.height) * 100));
                    }}
                  >
                    <div className="absolute bottom-0 left-0 right-0 bg-[#C9A84C] rounded-full" style={{ height: `${volume}%` }} />
                  </div>
                </div>
              )}
            </div>

            {/* Fullscreen */}
            <button
              className="p-1.5 text-[#8A8578] hover:text-[#E8E4DC] transition-colors"
              onClick={toggleFullscreen}
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Video playlist */}
      <div className="shrink-0 bg-[#12121A] border-t border-[#2A2A3E] px-3 py-2">
        <div className="text-[10px] text-[#4D4A42] uppercase tracking-wider mb-1.5">Videos</div>
        <div className="flex gap-2 overflow-x-auto">
          {SAMPLE_VIDEOS.map(video => (
            <button
              key={video.id}
              className={`flex items-center gap-2 px-3 py-2 rounded border transition-colors shrink-0 ${
                currentVideo.id === video.id ? 'border-[#C9A84C] bg-[#C9A84C]/10' : 'border-[#2A2A3E] hover:bg-[#1A1A26]'
              }`}
              onClick={() => { setCurrentVideo(video); setProgress(0); setIsPlaying(false); }}
            >
              <Film className="w-4 h-4" style={{ color: video.color }} />
              <div className="text-left">
                <div className="text-xs">{video.title}</div>
                <div className="text-[10px] text-[#4D4A42]">{formatTime(video.duration)}</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
