import { useState, useEffect, useMemo, useRef } from 'react';
import {
  Plus,
  Trash2,
  Search,
  Pin,
  PinOff,
  Bold,
  Italic,
  Heading1,
  Heading2,
  List,
  ListOrdered,
  Clock,
  Tag,
  X,
  StickyNote,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface Note {
  id: string;
  title: string;
  content: string;
  pinned: boolean;
  category: string;
  categoryColor: string;
  createdAt: number;
  updatedAt: number;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const STORAGE_KEY = 'cornstone-notes';

const CATEGORIES = [
  { name: 'General', color: '#8A8578' },
  { name: 'Work', color: '#5A8AB8' },
  { name: 'Personal', color: '#5A9E6F' },
  { name: 'Ideas', color: '#C9A84C' },
  { name: 'Important', color: '#B84A4A' },
  { name: 'Learning', color: '#7B6FB8' },
];

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */
function loadNotes(): Note[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { /* ignore */ }
  return [];
}

function saveNotes(notes: Note[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
function generateId() {
  return `note-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function timeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return `${Math.floor(days / 30)}mo ago`;
}

function extractTitle(content: string): string {
  const firstLine = content.split('\n')[0].trim();
  return firstLine.replace(/^#+\s*/, '').slice(0, 60) || 'Untitled Note';
}

/* ------------------------------------------------------------------ */
/*  Markdown-ish Renderer (simple)                                     */
/* ------------------------------------------------------------------ */
function renderContent(content: string): string {
  return content
    .replace(/^### (.*$)/gim, '<h3 class="text-sm font-bold text-[#E8E4DC] mt-3 mb-1">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-base font-bold text-[#E8E4DC] mt-4 mb-2">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="text-lg font-bold text-[#E8E4DC] mt-4 mb-2">$1</h1>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/^\* (.*$)/gim, '<li class="ml-4 list-disc">$1</li>')
    .replace(/^\d+\. (.*$)/gim, '<li class="ml-4 list-decimal">$1</li>')
    .replace(/^(?!<[hl]|<li)(.*$)/gim, '<p class="mb-1 leading-relaxed">$1</p>')
    .replace(/<\/li>\s*<li/g, '</li><li')
    .replace(/<p class="mb-1"><\/p>/g, '<br/>');
}

/* ------------------------------------------------------------------ */
/*  Main Notes App                                                     */
/* ------------------------------------------------------------------ */
export default function NotesApp() {
  const [notes, setNotes] = useState<Note[]>(loadNotes);
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { saveNotes(notes); }, [notes]);

  const filteredNotes = useMemo(() => {
    let filtered = notes;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = notes.filter(
        (n) =>
          n.title.toLowerCase().includes(q) ||
          n.content.toLowerCase().includes(q) ||
          n.category.toLowerCase().includes(q)
      );
    }
    // Sort: pinned first, then by updatedAt desc
    return [...filtered].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return b.updatedAt - a.updatedAt;
    });
  }, [notes, searchQuery]);

  const selectedNote = notes.find((n) => n.id === selectedNoteId) || null;

  const createNote = () => {
    const note: Note = {
      id: generateId(),
      title: 'New Note',
      content: '',
      pinned: false,
      category: 'General',
      categoryColor: CATEGORIES[0].color,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setNotes((prev) => [note, ...prev]);
    setSelectedNoteId(note.id);
    setShowPreview(false);
    setTimeout(() => textareaRef.current?.focus(), 0);
  };

  const updateNote = (id: string, updates: Partial<Note>) => {
    setNotes((prev) =>
      prev.map((n) =>
        n.id === id
          ? { ...n, ...updates, updatedAt: Date.now(), title: updates.content !== undefined ? extractTitle(updates.content) : (updates.title || n.title) }
          : n
      )
    );
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    if (selectedNoteId === id) setSelectedNoteId(null);
  };

  const togglePin = (id: string) => {
    const note = notes.find((n) => n.id === id);
    if (note) updateNote(id, { pinned: !note.pinned });
  };

  const insertFormat = (format: string) => {
    if (!textareaRef.current || !selectedNote) return;
    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = selectedNote.content;
    const before = text.substring(0, start);
    const selection = text.substring(start, end);
    const after = text.substring(end);

    let insert = '';
    switch (format) {
      case 'bold': insert = `**${selection || 'bold text'}**`; break;
      case 'italic': insert = `*${selection || 'italic text'}*`; break;
      case 'h1': insert = `\n# ${selection || 'Heading'}\n`; break;
      case 'h2': insert = `\n## ${selection || 'Subheading'}\n`; break;
      case 'ul': insert = `\n* ${selection || 'List item'}\n`; break;
      case 'ol': insert = `\n1. ${selection || 'List item'}\n`; break;
    }

    const newContent = before + insert + after;
    updateNote(selectedNote.id, { content: newContent });
    setTimeout(() => {
      textarea.focus();
      const newCursor = start + insert.length;
      textarea.setSelectionRange(newCursor, newCursor);
    }, 0);
  };

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex">
      {/* Left panel - Note list */}
      <div className="w-[280px] border-r border-[#2A2A3E] flex flex-col bg-[#0A0A0F]">
        {/* Header */}
        <div className="flex items-center justify-between px-3 py-2.5 border-b border-[#2A2A3E]">
          <div className="flex items-center gap-2">
            <StickyNote className="w-4 h-4 text-[#C9A84C]" />
            <span className="text-sm font-semibold text-[#E8E4DC]">Notes</span>
            <span className="text-[10px] text-[#4D4A42] bg-[#1A1A26] px-1.5 py-0.5 rounded-full">{notes.length}</span>
          </div>
          <button
            onClick={createNote}
            className="p-1.5 bg-[#C9A84C] text-[#030305] rounded-md hover:bg-[#D4B85A] transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Search */}
        <div className="px-3 py-2 border-b border-[#2A2A3E]">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#4D4A42] absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search notes..."
              className="w-full h-8 pl-8 pr-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2">
                <X className="w-3 h-3 text-[#4D4A42]" />
              </button>
            )}
          </div>
        </div>

        {/* Note list */}
        <div className="flex-1 overflow-auto">
          {filteredNotes.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-[#4D4A42]">
              <StickyNote className="w-8 h-8 mb-2 opacity-30" />
              <div className="text-xs">
                {searchQuery ? 'No matching notes' : 'No notes yet'}
              </div>
              {!searchQuery && (
                <button onClick={createNote} className="mt-2 text-xs text-[#C9A84C] hover:underline">
                  Create your first note
                </button>
              )}
            </div>
          ) : (
            <div className="divide-y divide-[#2A2A3E]/50">
              {filteredNotes.map((note) => (
                <button
                  key={note.id}
                  onClick={() => { setSelectedNoteId(note.id); setShowPreview(false); }}
                  className={`w-full text-left p-3 transition-colors group ${
                    selectedNoteId === note.id ? 'bg-[#222235]' : 'hover:bg-[#1A1A26]'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {note.pinned && <Pin className="w-3 h-3 text-[#C9A84C] mt-0.5 flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium text-[#E8E4DC] truncate">{note.title}</div>
                      <div className="text-[10px] text-[#8A8578] mt-0.5 line-clamp-2">
                        {note.content.replace(/[#*\-_]/g, ' ').slice(0, 80) || 'No content'}
                      </div>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span
                          className="text-[9px] px-1.5 py-0.5 rounded-full flex items-center gap-1"
                          style={{ backgroundColor: note.categoryColor + '20', color: note.categoryColor }}
                        >
                          <Tag className="w-2.5 h-2.5" />
                          {note.category}
                        </span>
                        <span className="text-[9px] text-[#4D4A42] flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {timeAgo(note.updatedAt)}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); deleteNote(note.id); }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-[#B84A4A]/20 rounded transition-all flex-shrink-0"
                    >
                      <Trash2 className="w-3 h-3 text-[#B84A4A]" />
                    </button>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right panel - Editor */}
      {selectedNote ? (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Editor toolbar */}
          <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E] bg-[#1A1A26]">
            <div className="flex items-center gap-0.5">
              {[
                { icon: Bold, action: () => insertFormat('bold'), title: 'Bold' },
                { icon: Italic, action: () => insertFormat('italic'), title: 'Italic' },
                { icon: Heading1, action: () => insertFormat('h1'), title: 'Heading 1' },
                { icon: Heading2, action: () => insertFormat('h2'), title: 'Heading 2' },
                { icon: List, action: () => insertFormat('ul'), title: 'Bullet List' },
                { icon: ListOrdered, action: () => insertFormat('ol'), title: 'Numbered List' },
              ].map((btn) => (
                <button
                  key={btn.title}
                  onClick={btn.action}
                  className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]"
                  title={btn.title}
                >
                  <btn.icon className="w-3.5 h-3.5" />
                </button>
              ))}
              <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
              {/* Category selector */}
              <div className="flex gap-0.5">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.name}
                    onClick={() => updateNote(selectedNote.id, { category: cat.name, categoryColor: cat.color })}
                    className={`px-2 h-6 rounded text-[10px] font-medium transition-colors ${
                      selectedNote.category === cat.name
                        ? 'text-[#030305]'
                        : 'text-[#8A8578] hover:bg-[#222235]'
                    }`}
                    style={
                      selectedNote.category === cat.name
                        ? { backgroundColor: cat.color }
                        : {}
                    }
                    title={cat.name}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
              <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
              <button
                onClick={() => setShowPreview(!showPreview)}
                className={`px-2 h-6 rounded text-[10px] font-medium transition-colors ${
                  showPreview ? 'bg-[#C9A84C] text-[#030305]' : 'text-[#8A8578] hover:bg-[#222235]'
                }`}
              >
                Preview
              </button>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => togglePin(selectedNote.id)}
                className={`p-1.5 rounded transition-colors ${
                  selectedNote.pinned ? 'text-[#C9A84C] bg-[#C9A84C]/10' : 'text-[#8A8578] hover:bg-[#222235]'
                }`}
                title={selectedNote.pinned ? 'Unpin' : 'Pin'}
              >
                {selectedNote.pinned ? <Pin className="w-3.5 h-3.5" /> : <PinOff className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => deleteNote(selectedNote.id)}
                className="p-1.5 hover:bg-[#B84A4A]/20 rounded transition-colors text-[#B84A4A]"
                title="Delete"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Note info bar */}
          <div className="px-4 py-1.5 border-b border-[#2A2A3E] bg-[#0A0A0F] flex items-center gap-3">
            <span className="text-[10px] text-[#4D4A42]">
              Edited {timeAgo(selectedNote.updatedAt)}
            </span>
            <span className="text-[10px] text-[#4D4A42]">
              {selectedNote.content.length} characters
            </span>
          </div>

          {/* Editor / Preview area */}
          <div className="flex-1 overflow-auto">
            {showPreview ? (
              <div
                className="p-6 text-sm leading-relaxed"
                dangerouslySetInnerHTML={{ __html: renderContent(selectedNote.content) }}
              />
            ) : (
              <textarea
                ref={textareaRef}
                value={selectedNote.content}
                onChange={(e) => updateNote(selectedNote.id, { content: e.target.value })}
                placeholder="Start typing...\n\nUse **bold**, *italic*, # headings, * bullets, 1. numbered lists"
                className="w-full h-full p-4 bg-transparent text-sm text-[#E8E4DC] placeholder-[#4D4A42] outline-none resize-none leading-relaxed font-mono"
                spellCheck={false}
              />
            )}
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-[#4D4A42]">
          <StickyNote className="w-12 h-12 mb-3 opacity-20" />
          <div className="text-sm">Select a note or create a new one</div>
          <button
            onClick={createNote}
            className="mt-3 px-4 h-9 bg-[#C9A84C] text-[#030305] rounded-md text-sm font-semibold hover:bg-[#D4B85A] transition-colors"
          >
            New Note
          </button>
        </div>
      )}
    </div>
  );
}
