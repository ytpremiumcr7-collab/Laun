import { useState, useEffect, useCallback } from 'react';
import { History, Trash2 } from 'lucide-react';

type Mode = 'standard' | 'scientific';

type HistoryEntry = {
  expr: string;
  result: string;
  timestamp: number;
};

function factorial(n: number): number {
  if (n < 0) return NaN;
  if (n > 170) return Infinity;
  if (n === 0 || n === 1) return 1;
  let result = 1;
  for (let i = 2; i <= n; i++) result *= i;
  return result;
}

function evaluate(expr: string): string {
  try {
    const clean = expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/\^/g, '**')
      .replace(/π/g, 'Math.PI')
      .replace(/(?<![a-zA-Z])e(?![a-zA-Z])/g, 'Math.E')
      .replace(/sin\(/g, 'Math.sin(')
      .replace(/cos\(/g, 'Math.cos(')
      .replace(/tan\(/g, 'Math.tan(')
      .replace(/log\(/g, 'Math.log10(')
      .replace(/ln\(/g, 'Math.log(')
      .replace(/sqrt\(/g, 'Math.sqrt(')
      .replace(/abs\(/g, 'Math.abs(')
      .replace(/asin\(/g, 'Math.asin(')
      .replace(/acos\(/g, 'Math.acos(')
      .replace(/atan\(/g, 'Math.atan(');

    const func = new Function('Math', 'factorial', `return (${clean})`);
    const result = func(Math, factorial);
    if (typeof result === 'number') {
      if (!isFinite(result) || isNaN(result)) return 'Error';
      if (Math.abs(result) > 1e15) return result.toExponential(10);
      return String(parseFloat(result.toPrecision(15)));
    }
    return String(result);
  } catch {
    return 'Error';
  }
}

export default function CalculatorApp() {
  const [display, setDisplay] = useState('0');
  const [prevDisplay, setPrevDisplay] = useState('');
  const [mode, setMode] = useState<Mode>('standard');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [memory, setMemory] = useState(0);
  const [hasMemory, setHasMemory] = useState(false);
  const [pendingOp, setPendingOp] = useState('');
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [angleMode, setAngleMode] = useState<'DEG' | 'RAD'>('DEG');
  const [secondFn, setSecondFn] = useState(false);

  const handleNumber = useCallback((num: string) => {
    if (waitingForOperand) {
      setDisplay(num);
      setWaitingForOperand(false);
    } else {
      setDisplay(prev => prev === '0' ? num : prev + num);
    }
  }, [waitingForOperand]);

  const handleOperator = useCallback((op: string) => {
    if (pendingOp && !waitingForOperand) {
      const result = evaluate(`${prevDisplay} ${pendingOp} ${display}`);
      setPrevDisplay(result);
      setDisplay(result);
    } else {
      setPrevDisplay(display);
    }
    setPendingOp(op);
    setWaitingForOperand(true);
  }, [display, pendingOp, waitingForOperand, prevDisplay]);

  const handleEquals = useCallback(() => {
    if (pendingOp) {
      const expr = `${prevDisplay} ${pendingOp} ${display}`;
      const result = evaluate(expr);
      setHistory(h => [{ expr, result, timestamp: Date.now() }, ...h].slice(0, 50));
      setDisplay(result);
      setPrevDisplay('');
      setPendingOp('');
      setWaitingForOperand(true);
    }
  }, [display, pendingOp, prevDisplay]);

  const handleClear = useCallback(() => {
    setDisplay('0');
    setPrevDisplay('');
    setPendingOp('');
    setWaitingForOperand(false);
  }, []);

  const handleDelete = useCallback(() => {
    setDisplay(prev => {
      if (prev.length <= 1) return '0';
      return prev.slice(0, -1);
    });
  }, []);

  const handleDecimal = useCallback(() => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (!display.includes('.')) {
      setDisplay(prev => prev + '.');
    }
  }, [display, waitingForOperand]);

  const handlePercent = useCallback(() => {
    setDisplay(prev => {
      const val = parseFloat(prev);
      if (isNaN(val)) return 'Error';
      return String(val / 100);
    });
  }, []);

  const handleToggleSign = useCallback(() => {
    setDisplay(prev => {
      if (prev === '0') return prev;
      return prev.startsWith('-') ? prev.slice(1) : '-' + prev;
    });
  }, []);

  const handleSciFn = useCallback((fn: string) => {
    const val = parseFloat(display);
    if (isNaN(val)) { setDisplay('Error'); return; }
    let result = 'Error';
    const rad = angleMode === 'DEG' ? val * Math.PI / 180 : val;

    switch (fn) {
      case 'sin': result = String(Math.sin(rad)); break;
      case 'cos': result = String(Math.cos(rad)); break;
      case 'tan': result = String(Math.tan(rad)); break;
      case 'asin': {
        const r = Math.asin(val);
        result = String(angleMode === 'DEG' ? r * 180 / Math.PI : r);
        break;
      }
      case 'acos': {
        const r = Math.acos(val);
        result = String(angleMode === 'DEG' ? r * 180 / Math.PI : r);
        break;
      }
      case 'atan': {
        const r = Math.atan(val);
        result = String(angleMode === 'DEG' ? r * 180 / Math.PI : r);
        break;
      }
      case 'log': result = String(Math.log10(val)); break;
      case 'ln': result = String(Math.log(val)); break;
      case 'sqrt': result = val < 0 ? 'Error' : String(Math.sqrt(val)); break;
      case 'sq': result = String(val * val); break;
      case 'inv': result = String(1 / val); break;
      case 'abs': result = String(Math.abs(val)); break;
      case 'factorial': result = String(factorial(Math.floor(val))); break;
      default: result = String(val);
    }

    if (!isFinite(parseFloat(result)) || result === 'NaN') result = 'Error';
    setDisplay(result);
    setWaitingForOperand(true);
  }, [display, angleMode]);

  const handleMemory = useCallback((action: string) => {
    const val = parseFloat(display);
    switch (action) {
      case 'MC': setMemory(0); setHasMemory(false); break;
      case 'MR': setDisplay(String(memory)); setWaitingForOperand(true); break;
      case 'M+': setMemory(m => m + val); setHasMemory(true); break;
      case 'M-': setMemory(m => m - val); setHasMemory(true); break;
    }
  }, [display, memory]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') handleNumber(e.key);
      else if (e.key === '.') handleDecimal();
      else if (e.key === '+') handleOperator('+');
      else if (e.key === '-') handleOperator('-');
      else if (e.key === '*') handleOperator('*');
      else if (e.key === '/') { e.preventDefault(); handleOperator('/'); }
      else if (e.key === 'Enter' || e.key === '=') handleEquals();
      else if (e.key === 'Escape') handleClear();
      else if (e.key === 'Backspace') handleDelete();
      else if (e.key === '%') handlePercent();
      else if (e.key === '^') handleOperator('**');
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleNumber, handleOperator, handleEquals, handleClear, handleDelete, handleDecimal, handlePercent]);

  const stdButtons = [
    [{ label: 'AC', onClick: handleClear, className: 'bg-[#B84A4A]/20 text-[#B84A4A] hover:bg-[#B84A4A]/30' },
     { label: '+/−', onClick: handleToggleSign, className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235]' },
     { label: '%', onClick: handlePercent, className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235]' },
     { label: '÷', onClick: () => handleOperator('/'), className: 'bg-[#222235] text-[#C9A84C] hover:bg-[#2A2A3E]' }],
    [{ label: '7', onClick: () => handleNumber('7'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '8', onClick: () => handleNumber('8'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '9', onClick: () => handleNumber('9'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '×', onClick: () => handleOperator('*'), className: 'bg-[#222235] text-[#C9A84C] hover:bg-[#2A2A3E]' }],
    [{ label: '4', onClick: () => handleNumber('4'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '5', onClick: () => handleNumber('5'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '6', onClick: () => handleNumber('6'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '−', onClick: () => handleOperator('-'), className: 'bg-[#222235] text-[#C9A84C] hover:bg-[#2A2A3E]' }],
    [{ label: '1', onClick: () => handleNumber('1'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '2', onClick: () => handleNumber('2'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '3', onClick: () => handleNumber('3'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '+', onClick: () => handleOperator('+'), className: 'bg-[#222235] text-[#C9A84C] hover:bg-[#2A2A3E]' }],
    [{ label: '0', onClick: () => handleNumber('0'), className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235] col-span-2' },
     { label: '.', onClick: handleDecimal, className: 'bg-[#1A1A26] text-[#E8E4DC] hover:bg-[#222235]' },
     { label: '=', onClick: handleEquals, className: 'bg-[#C9A84C] text-[#030305] font-bold hover:brightness-110' }],
  ];

  const sciButtons = [
    [{ label: secondFn ? 'asin' : 'sin', onClick: () => handleSciFn(secondFn ? 'asin' : 'sin'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: secondFn ? 'acos' : 'cos', onClick: () => handleSciFn(secondFn ? 'acos' : 'cos'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: secondFn ? 'atan' : 'tan', onClick: () => handleSciFn(secondFn ? 'atan' : 'tan'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: 'log', onClick: () => handleSciFn('log'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: 'ln', onClick: () => handleSciFn('ln'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' }],
    [{ label: 'x²', onClick: () => handleSciFn('sq'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: '√', onClick: () => handleSciFn('sqrt'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: '1/x', onClick: () => handleSciFn('inv'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: '(', onClick: () => { setDisplay(prev => prev === '0' ? '(' : prev + '('); setWaitingForOperand(false); }, className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235]' },
     { label: ')', onClick: () => { setDisplay(prev => prev + ')'); setWaitingForOperand(false); }, className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235]' }],
    [{ label: 'n!', onClick: () => handleSciFn('factorial'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: 'π', onClick: () => { setDisplay(String(Math.PI)); setWaitingForOperand(true); }, className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235]' },
     { label: 'e', onClick: () => { setDisplay(String(Math.E)); setWaitingForOperand(true); }, className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235]' },
     { label: '2nd', onClick: () => setSecondFn(s => !s), className: secondFn ? 'bg-[#C9A84C] text-[#030305]' : 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: angleMode, onClick: () => setAngleMode(a => a === 'DEG' ? 'RAD' : 'DEG'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' }],
    [{ label: 'MC', onClick: () => handleMemory('MC'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: 'MR', onClick: () => handleMemory('MR'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: 'M+', onClick: () => handleMemory('M+'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: 'M−', onClick: () => handleMemory('M-'), className: 'bg-[#1A1A26] text-[#8A8578] hover:bg-[#222235] text-xs' },
     { label: '⌫', onClick: handleDelete, className: 'bg-[#B84A4A]/20 text-[#B84A4A] hover:bg-[#B84A4A]/30' }],
  ];

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col select-none">
      {/* Mode tabs */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E]">
        <div className="flex gap-1">
          <button
            onClick={() => setMode('standard')}
            className={`px-3 py-1 rounded text-xs font-medium transition-colors ${mode === 'standard' ? 'bg-[#222235] text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
          >
            Standard
          </button>
          <button
            onClick={() => setMode('scientific')}
            className={`px-3 py-1 rounded text-xs font-medium transition-colors ${mode === 'scientific' ? 'bg-[#222235] text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
          >
            Scientific
          </button>
        </div>
        <div className="flex items-center gap-2">
          {hasMemory && <span className="text-[10px] text-[#C9A84C] font-mono">M</span>}
          <button onClick={() => setShowHistory(!showHistory)} className={`p-1 rounded transition-colors ${showHistory ? 'text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}>
            <History className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* History sidebar + main */}
      <div className="flex flex-1 overflow-hidden">
        {showHistory && (
          <div className="w-48 border-r border-[#2A2A3E] flex flex-col bg-[#0A0A0F]">
            <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E]">
              <span className="text-xs text-[#8A8578]">History</span>
              <button onClick={() => setHistory([])} className="text-[#8A8578] hover:text-[#B84A4A] transition-colors">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-2 space-y-1">
              {history.length === 0 && (
                <div className="text-xs text-[#4D4A42] text-center py-4">No history yet</div>
              )}
              {history.map((h, i) => (
                <button
                  key={i}
                  onClick={() => { setDisplay(h.result); setWaitingForOperand(true); }}
                  className="w-full text-right p-2 rounded hover:bg-[#1A1A26] transition-colors"
                >
                  <div className="text-[10px] text-[#4D4A42] font-mono">{h.expr}</div>
                  <div className="text-sm font-mono text-[#C9A84C]">= {h.result}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="flex-1 flex flex-col p-3 gap-2">
          {/* Display */}
          <div className="bg-[#0A0A0F] rounded-lg p-3 border border-[#2A2A3E]">
            {prevDisplay && pendingOp && (
              <div className="text-right text-[10px] text-[#4D4A42] font-mono mb-1 truncate">
                {prevDisplay} {pendingOp}
              </div>
            )}
            <div className="text-right text-2xl font-mono text-[#E8E4DC] overflow-hidden text-ellipsis whitespace-nowrap" style={{ minHeight: '32px' }}>
              {display}
            </div>
          </div>

          {/* Scientific functions */}
          {mode === 'scientific' && (
            <div className="grid grid-cols-5 gap-1">
              {sciButtons.map((row, ri) =>
                row.map((btn, bi) => (
                  <button
                    key={`${ri}-${bi}`}
                    onClick={btn.onClick}
                    className={`rounded-lg text-sm font-medium transition-all duration-75 active:scale-95 h-10 ${btn.className}`}
                  >
                    {btn.label}
                  </button>
                ))
              )}
            </div>
          )}

          {/* Standard keypad */}
          <div className="grid grid-cols-4 gap-1.5 flex-1">
            {stdButtons.map((row, ri) =>
              row.map((btn, bi) => (
                <button
                  key={`${ri}-${bi}`}
                  onClick={btn.onClick}
                  className={`rounded-lg text-base font-medium transition-all duration-75 active:scale-95 ${btn.className}`}
                  style={btn.label.length > 1 && '0123456789.'.includes(btn.label) ? {} : {}}
                >
                  {btn.label}
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
