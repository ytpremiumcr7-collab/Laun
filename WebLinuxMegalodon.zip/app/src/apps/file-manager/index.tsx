import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import {
  ChevronRight, ChevronDown, Folder, FileText, ArrowLeft, ArrowUp,
  Grid3X3, List, Search, Trash2, RotateCcw, FolderPlus,
  X, FileImage, FileCode, Settings, Monitor, Home, Download, Music,
  Image, Film, HardDrive
} from 'lucide-react';
import { useFileSystem } from '@/stores/useFileSystem';
import type { FileSystemNode } from '@/types';

type ViewMode = 'list' | 'grid';
type SortCol = 'name' | 'size' | 'modified' | 'type';

const QUICK_ACCESS = [
  { id: 'home', name: 'Home', icon: Home, path: null as string | null },
  { id: 'desktop', name: 'Desktop', icon: Monitor, path: 'root-desktop' },
  { id: 'documents', name: 'Documents', icon: FileText, path: 'root-documents' },
  { id: 'downloads', name: 'Downloads', icon: Download, path: 'root-downloads' },
  { id: 'pictures', name: 'Pictures', icon: Image, path: 'root-pictures' },
  { id: 'music', name: 'Music', icon: Music, path: 'root-music' },
  { id: 'videos', name: 'Videos', icon: Film, path: 'root-videos' },
];

function formatSize(bytes?: number): string {
  if (!bytes) return '--';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' });
}

function getFileIcon(node: FileSystemNode) {
  if (node.type === 'folder') return <Folder className="w-5 h-5 text-[#C9A84C] shrink-0" />;
  const ext = node.name.split('.').pop()?.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '')) return <FileImage className="w-5 h-5 text-[#7B6FB8] shrink-0" />;
  if (['js', 'ts', 'jsx', 'tsx', 'py', 'html', 'css', 'json'].includes(ext || '')) return <FileCode className="w-5 h-5 text-[#4A9E9E] shrink-0" />;
  return <FileText className="w-5 h-5 text-[#8A8578] shrink-0" />;
}

export default function FileManager() {
  const { nodes, addNode, deleteNode, renameNode, expandedFolders, toggleFolder } = useFileSystem();
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [sortCol, setSortCol] = useState<SortCol>('name');
  const [sortDesc, setSortDesc] = useState(false);
  const [search, setSearch] = useState('');
  const [showTrash, setShowTrash] = useState(false);
  const [trashItems, setTrashItems] = useState<(FileSystemNode & { originalParent: string | null })[]>([]);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; node: FileSystemNode } | null>(null);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [previewNode, setPreviewNode] = useState<FileSystemNode | null>(null);
  const [navHistory, setNavHistory] = useState<string[]>([]);
  const [navIndex, setNavIndex] = useState(-1);
  const [showPreview, setShowPreview] = useState(true);
  const renameRef = useRef<HTMLInputElement>(null);

  // Focus rename input
  useEffect(() => {
    if (renamingId && renameRef.current) {
      renameRef.current.focus();
      renameRef.current.select();
    }
  }, [renamingId]);

  // Close context menu on click outside
  useEffect(() => {
    const handler = () => setContextMenu(null);
    window.addEventListener('click', handler);
    return () => window.removeEventListener('click', handler);
  }, []);

  const navigateTo = useCallback((folderId: string | null) => {
    setCurrentFolderId(folderId);
    setSelectedId(null);
    setPreviewNode(null);
    setNavHistory(prev => {
      const newHistory = prev.slice(0, navIndex + 1);
      return [...newHistory, folderId ?? 'root'];
    });
    setNavIndex(prev => prev + 1);
  }, [navIndex]);

  const goBack = useCallback(() => {
    if (navIndex > 0) {
      const prevId = navHistory[navIndex - 1];
      setCurrentFolderId(prevId === 'root' ? null : prevId);
      setNavIndex(navIndex - 1);
      setSelectedId(null);
    }
  }, [navIndex, navHistory]);

  const goUp = useCallback(() => {
    if (currentFolderId) {
      const node = nodes.find(n => n.id === currentFolderId);
      if (node?.parentId !== undefined) {
        navigateTo(node.parentId);
      } else {
        navigateTo(null);
      }
    }
  }, [currentFolderId, nodes, navigateTo]);

  const children = useMemo(() => {
    let items = nodes.filter(n => n.parentId === currentFolderId);
    if (search) {
      items = items.filter(n => n.name.toLowerCase().includes(search.toLowerCase()));
    }
    return items.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
      let cmp = 0;
      switch (sortCol) {
        case 'name': cmp = a.name.localeCompare(b.name); break;
        case 'size': cmp = (a.size || 0) - (b.size || 0); break;
        case 'modified': cmp = a.modifiedAt - b.modifiedAt; break;
        case 'type': cmp = (a.name.split('.').pop() || '').localeCompare(b.name.split('.').pop() || ''); break;
      }
      return sortDesc ? -cmp : cmp;
    });
  }, [nodes, currentFolderId, search, sortCol, sortDesc]);

  const breadcrumb = useMemo(() => {
    const path: FileSystemNode[] = [];
    let current = nodes.find(n => n.id === currentFolderId);
    while (current) {
      path.unshift(current);
      current = nodes.find(n => n.id === current!.parentId);
    }
    return path;
  }, [currentFolderId, nodes]);

  const handleNewFolder = useCallback(() => {
    const name = 'New Folder';
    let finalName = name;
    let counter = 1;
    while (nodes.some(n => n.parentId === currentFolderId && n.name === finalName)) {
      finalName = `${name} (${counter})`;
      counter++;
    }
    addNode({ name: finalName, type: 'folder', parentId: currentFolderId });
  }, [currentFolderId, nodes, addNode]);

  const handleDelete = useCallback((node: FileSystemNode) => {
    if (showTrash) {
      deleteNode(node.id);
      setTrashItems(prev => prev.filter(t => t.id !== node.id));
    } else {
      // Move to trash
      setTrashItems(prev => [...prev, { ...node, originalParent: node.parentId }]);
      deleteNode(node.id);
    }
    setSelectedId(null);
    setPreviewNode(null);
  }, [deleteNode, showTrash]);

  const handleRestore = useCallback((item: FileSystemNode & { originalParent: string | null }) => {
    addNode({ name: item.name, type: item.type, parentId: item.originalParent, content: item.content, size: item.size });
    setTrashItems(prev => prev.filter(t => t.id !== item.id));
  }, [addNode]);

  const handleEmptyTrash = useCallback(() => {
    setTrashItems([]);
  }, []);

  const handleRename = useCallback((node: FileSystemNode) => {
    setRenamingId(node.id);
    setRenameValue(node.name);
  }, []);

  const submitRename = useCallback(() => {
    if (renamingId && renameValue.trim()) {
      renameNode(renamingId, renameValue.trim());
    }
    setRenamingId(null);
  }, [renamingId, renameValue, renameNode]);

  const handleSort = useCallback((col: SortCol) => {
    setSortCol(prev => {
      if (prev === col) { setSortDesc(d => !d); return prev; }
      setSortDesc(false);
      return col;
    });
  }, []);

  const handleContextMenu = useCallback((e: React.MouseEvent, node: FileSystemNode) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedId(node.id);
    setPreviewNode(node);
    setContextMenu({ x: e.clientX, y: e.clientY, node });
  }, []);

  const displayItems = showTrash ? trashItems : children;
  const totalSize = displayItems.reduce((acc, n) => acc + (n.size || 0), 0);

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col overflow-hidden select-none">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#0A0A0F] border-b border-[#2A2A3E] shrink-0">
        <button onClick={goBack} className="p-1.5 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors" title="Back">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button onClick={goUp} className="p-1.5 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors" title="Up">
          <ArrowUp className="w-4 h-4" />
        </button>
        <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
        {/* Breadcrumb */}
        <div className="flex items-center gap-1 text-xs text-[#8A8578] flex-1 overflow-hidden">
          <button onClick={() => navigateTo(null)} className="hover:text-[#E8E4DC] transition-colors shrink-0">Home</button>
          {breadcrumb.map(node => (
            <span key={node.id} className="flex items-center gap-1 shrink-0">
              <ChevronRight className="w-3 h-3" />
              <button onClick={() => navigateTo(node.id)} className="hover:text-[#E8E4DC] transition-colors">{node.name}</button>
            </span>
          ))}
        </div>
        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-[#4D4A42] absolute left-2 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg pl-7 pr-2 py-1 text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C] w-40 focus:w-52 transition-all placeholder-[#4D4A42]"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#4D4A42] hover:text-[#8A8578]">
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
        <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
        <button onClick={handleNewFolder} className="p-1.5 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors" title="New Folder">
          <FolderPlus className="w-4 h-4" />
        </button>
        <button onClick={() => setViewMode(v => v === 'list' ? 'grid' : 'list')} className="p-1.5 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors" title="Toggle View">
          {viewMode === 'list' ? <Grid3X3 className="w-4 h-4" /> : <List className="w-4 h-4" />}
        </button>
        <button onClick={() => setShowPreview(v => !v)} className={`p-1.5 rounded transition-colors ${showPreview ? 'text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`} title="Toggle Preview">
          <Settings className="w-4 h-4" />
        </button>
      </div>

      {/* Main area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col py-2 shrink-0 overflow-y-auto">
          <div className="px-3 py-1 text-[10px] text-[#4D4A42] font-medium uppercase tracking-wider">Quick Access</div>
          {QUICK_ACCESS.map(item => (
            <button
              key={item.id}
              onClick={() => { setShowTrash(false); navigateTo(item.path); }}
              className={`flex items-center gap-2.5 px-3 py-1.5 text-xs transition-colors text-left ${
                currentFolderId === item.path && !showTrash ? 'bg-[#222235] text-[#C9A84C] border-l-2 border-[#C9A84C]' : 'text-[#8A8578] hover:bg-[#1A1A26] hover:text-[#E8E4DC]'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.name}
            </button>
          ))}

          {/* Tree view */}
          <div className="mt-4 px-3 py-1 text-[10px] text-[#4D4A42] font-medium uppercase tracking-wider">Folders</div>
          {nodes.filter(n => n.type === 'folder' && n.parentId === null).map(folder => (
            <SidebarTreeItem
              key={folder.id}
              node={folder}
              nodes={nodes}
              currentFolderId={currentFolderId}
              expandedFolders={expandedFolders}
              toggleFolder={toggleFolder}
              navigateTo={navigateTo}
              depth={0}
            />
          ))}

          {/* Trash */}
          <div className="mt-4 border-t border-[#2A2A3E] pt-2">
            <button
              onClick={() => { setShowTrash(true); setCurrentFolderId(null); setSelectedId(null); }}
              className={`flex items-center gap-2.5 px-3 py-1.5 text-xs transition-colors text-left w-full ${
                showTrash ? 'bg-[#222235] text-[#B84A4A] border-l-2 border-[#B84A4A]' : 'text-[#8A8578] hover:bg-[#1A1A26] hover:text-[#E8E4DC]'
              }`}
            >
              <Trash2 className="w-4 h-4" />
              Trash
              {trashItems.length > 0 && (
                <span className="ml-auto text-[10px] bg-[#B84A4A]/20 text-[#B84A4A] px-1.5 py-0.5 rounded-full">{trashItems.length}</span>
              )}
            </button>
          </div>
        </div>

        {/* File area */}
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Column headers (list view) */}
            {viewMode === 'list' && !showTrash && (
              <div className="flex items-center px-3 py-1.5 bg-[#1A1A26] border-b border-[#2A2A3E] text-[10px] text-[#8A8578] font-medium shrink-0">
                <button onClick={() => handleSort('name')} className="flex-1 text-left hover:text-[#E8E4DC] transition-colors">
                  Name {sortCol === 'name' && (sortDesc ? '↓' : '↑')}
                </button>
                <button onClick={() => handleSort('size')} className="w-20 text-right hover:text-[#E8E4DC] transition-colors">
                  Size {sortCol === 'size' && (sortDesc ? '↓' : '↑')}
                </button>
                <button onClick={() => handleSort('modified')} className="w-28 text-right hover:text-[#E8E4DC] transition-colors">
                  Modified {sortCol === 'modified' && (sortDesc ? '↓' : '↑')}
                </button>
                <button onClick={() => handleSort('type')} className="w-20 text-right hover:text-[#E8E4DC] transition-colors">
                  Type {sortCol === 'type' && (sortDesc ? '↓' : '↑')}
                </button>
              </div>
            )}

            {/* Trash header */}
            {showTrash && (
              <div className="flex items-center justify-between px-3 py-2 bg-[#1A1A26] border-b border-[#2A2A3E] shrink-0">
                <span className="text-xs text-[#8A8578]">Trash</span>
                {trashItems.length > 0 && (
                  <button
                    onClick={handleEmptyTrash}
                    className="text-xs px-2 py-1 bg-[#B84A4A]/20 hover:bg-[#B84A4A]/30 text-[#B84A4A] rounded transition-colors"
                  >
                    Empty Trash
                  </button>
                )}
              </div>
            )}

            {/* File list */}
            <div className="flex-1 overflow-auto">
              {displayItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-[#4D4A42]">
                  <Folder className="w-12 h-12 mb-2" />
                  <span className="text-sm">
                    {showTrash ? 'Trash is empty' : search ? 'No matching items' : 'This folder is empty'}
                  </span>
                </div>
              ) : viewMode === 'list' ? (
                <div className="divide-y divide-[#2A2A3E]/50">
                  {displayItems.map(node => (
                    <div
                      key={node.id}
                      onClick={() => { setSelectedId(node.id); setPreviewNode(node); }}
                      onDoubleClick={() => {
                        if (node.type === 'folder' && !showTrash) {
                          navigateTo(node.id);
                        }
                      }}
                      onContextMenu={e => handleContextMenu(e, node)}
                      className={`flex items-center px-3 py-2 cursor-pointer transition-colors ${
                        selectedId === node.id ? 'bg-[#222235] border-l-2 border-l-[#C9A84C]' : 'hover:bg-[#1A1A26]/50 border-l-2 border-l-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        {getFileIcon(node)}
                        {renamingId === node.id ? (
                          <input
                            ref={renameRef}
                            value={renameValue}
                            onChange={e => setRenameValue(e.target.value)}
                            onBlur={submitRename}
                            onKeyDown={e => { if (e.key === 'Enter') submitRename(); if (e.key === 'Escape') setRenamingId(null); }}
                            className="bg-[#1A1A26] border border-[#C9A84C] rounded px-1.5 py-0.5 text-xs text-[#E8E4DC] outline-none"
                            onClick={e => e.stopPropagation()}
                          />
                        ) : (
                          <span className={`text-xs truncate ${node.type === 'folder' ? 'text-[#E8E4DC] font-medium' : 'text-[#8A8578]'}`}>
                            {node.name}
                          </span>
                        )}
                      </div>
                      {!showTrash && (
                        <>
                          <span className="w-20 text-right text-[10px] text-[#8A8578] font-mono shrink-0">{formatSize(node.size)}</span>
                          <span className="w-28 text-right text-[10px] text-[#8A8578] shrink-0">{formatDate(node.modifiedAt)}</span>
                          <span className="w-20 text-right text-[10px] text-[#8A8578] shrink-0">
                            {node.type === 'folder' ? 'Folder' : node.name.split('.').pop()?.toUpperCase() || 'File'}
                          </span>
                        </>
                      )}
                      {showTrash && (
                        <button
                          onClick={(e) => { e.stopPropagation(); handleRestore(node as FileSystemNode & { originalParent: string | null }); }}
                          className="ml-auto text-[#8A8578] hover:text-[#5A9E6F] transition-colors p-1"
                          title="Restore"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                /* Grid view */
                <div className="grid grid-cols-[repeat(auto-fill,minmax(96px,1fr))] gap-2 p-4">
                  {displayItems.map(node => (
                    <div
                      key={node.id}
                      onClick={() => { setSelectedId(node.id); setPreviewNode(node); }}
                      onDoubleClick={() => {
                        if (node.type === 'folder' && !showTrash) navigateTo(node.id);
                      }}
                      onContextMenu={e => handleContextMenu(e, node)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedId === node.id ? 'bg-[#222235] border-2 border-[#C9A84C]' : 'hover:bg-[#1A1A26] border-2 border-transparent'
                      }`}
                    >
                      {node.type === 'folder' ? (
                        <Folder className="w-10 h-10 text-[#C9A84C]" />
                      ) : (
                        <FileText className="w-10 h-10 text-[#8A8578]" />
                      )}
                      <span className="text-[10px] text-center text-[#E8E4DC] line-clamp-2 break-all leading-tight">{node.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Status bar */}
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#0A0A0F] border-t border-[#2A2A3E] text-[10px] text-[#8A8578] shrink-0">
              <span>{displayItems.length} items{displayItems.length > 0 && selectedId ? ` | 1 selected` : ''}</span>
              <div className="flex items-center gap-3">
                {totalSize > 0 && <span>{formatSize(totalSize)} total</span>}
                <button
                  onClick={() => { setShowTrash(!showTrash); setShowTrash(v => !v); }}
                  className="flex items-center gap-1 hover:text-[#E8E4DC] transition-colors"
                >
                  <HardDrive className="w-3 h-3" />
                  512 GB
                </button>
              </div>
            </div>
          </div>

          {/* Preview pane */}
          {showPreview && previewNode && previewNode.type === 'file' && (
            <div className="w-56 border-l border-[#2A2A3E] bg-[#0A0A0F] flex flex-col shrink-0">
              <div className="flex items-center justify-between px-3 py-2 border-b border-[#2A2A3E]">
                <span className="text-[10px] text-[#8A8578] uppercase tracking-wider">Preview</span>
                <button onClick={() => setPreviewNode(null)} className="text-[#4D4A42] hover:text-[#8A8578]">
                  <X className="w-3 h-3" />
                </button>
              </div>
              <div className="p-3 space-y-2">
                <div className="flex flex-col items-center py-3">
                  {getFileIcon(previewNode)}
                  <span className="text-xs text-[#E8E4DC] mt-2 text-center break-all">{previewNode.name}</span>
                </div>
                <div className="space-y-1 text-[10px]">
                  <div className="flex justify-between"><span className="text-[#8A8578]">Type</span><span className="text-[#E8E4DC]">{previewNode.name.split('.').pop()?.toUpperCase() || 'File'}</span></div>
                  <div className="flex justify-between"><span className="text-[#8A8578]">Size</span><span className="text-[#E8E4DC]">{formatSize(previewNode.size)}</span></div>
                  <div className="flex justify-between"><span className="text-[#8A8578]">Modified</span><span className="text-[#E8E4DC]">{formatDate(previewNode.modifiedAt)}</span></div>
                </div>
                {previewNode.content && (
                  <div className="mt-2 p-2 bg-[#12121A] rounded border border-[#2A2A3E] max-h-40 overflow-auto">
                    <pre className="text-[10px] text-[#8A8578] font-mono whitespace-pre-wrap break-all">{previewNode.content.slice(0, 500)}{previewNode.content.length > 500 ? '...' : ''}</pre>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Context menu */}
      {contextMenu && (
        <div
          className="fixed z-[60000] bg-[#1A1A26] border border-[#2A2A3E] rounded-lg shadow-lg py-1 min-w-[160px]"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={e => e.stopPropagation()}
        >
          {contextMenu.node.type === 'folder' && (
            <button
              onClick={() => { navigateTo(contextMenu.node.id); setContextMenu(null); }}
              className="flex items-center gap-2 px-3 py-1.5 text-xs text-[#E8E4DC] hover:bg-[#222235] transition-colors w-full text-left"
            >
              <Folder className="w-3.5 h-3.5 text-[#C9A84C]" /> Open
            </button>
          )}
          <button
            onClick={() => { handleRename(contextMenu.node); setContextMenu(null); }}
            className="flex items-center gap-2 px-3 py-1.5 text-xs text-[#E8E4DC] hover:bg-[#222235] transition-colors w-full text-left"
          >
            <FileText className="w-3.5 h-3.5 text-[#8A8578]" /> Rename
          </button>
          <button
            onClick={() => { handleDelete(contextMenu.node); setContextMenu(null); }}
            className="flex items-center gap-2 px-3 py-1.5 text-xs text-[#B84A4A] hover:bg-[#B84A4A]/10 transition-colors w-full text-left"
          >
            <Trash2 className="w-3.5 h-3.5" /> {showTrash ? 'Delete Permanently' : 'Move to Trash'}
          </button>
        </div>
      )}
    </div>
  );
}

// Sidebar tree item component
function SidebarTreeItem({
  node, nodes, currentFolderId, expandedFolders, toggleFolder, navigateTo, depth
}: {
  node: FileSystemNode;
  nodes: FileSystemNode[];
  currentFolderId: string | null;
  expandedFolders: string[];
  toggleFolder: (id: string) => void;
  navigateTo: (id: string | null) => void;
  depth: number;
}) {
  const children = nodes.filter(n => n.parentId === node.id && n.type === 'folder');
  const isExpanded = expandedFolders.includes(node.id);

  return (
    <div>
      <button
        onClick={() => {
          navigateTo(node.id);
          if (children.length > 0) toggleFolder(node.id);
        }}
        className={`flex items-center gap-1.5 px-3 py-1 text-xs transition-colors text-left w-full ${
          currentFolderId === node.id ? 'bg-[#222235] text-[#C9A84C] border-l-2 border-[#C9A84C]' : 'text-[#8A8578] hover:bg-[#1A1A26] hover:text-[#E8E4DC]'
        }`}
        style={{ paddingLeft: `${12 + depth * 12}px` }}
      >
        {children.length > 0 ? (
          isExpanded ? <ChevronDown className="w-3 h-3 shrink-0" /> : <ChevronRight className="w-3 h-3 shrink-0" />
        ) : (
          <span className="w-3 shrink-0" />
        )}
        <Folder className="w-3.5 h-3.5 text-[#C9A84C] shrink-0" />
        <span className="truncate">{node.name}</span>
      </button>
      {isExpanded && children.map(child => (
        <SidebarTreeItem
          key={child.id}
          node={child}
          nodes={nodes}
          currentFolderId={currentFolderId}
          expandedFolders={expandedFolders}
          toggleFolder={toggleFolder}
          navigateTo={navigateTo}
          depth={depth + 1}
        />
      ))}
    </div>
  );
}
