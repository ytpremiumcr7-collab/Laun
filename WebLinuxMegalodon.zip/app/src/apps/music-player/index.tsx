import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat,
  Volume2, Volume1, VolumeX, Search, Plus, X,
  Music, ListMusic
} from 'lucide-react';

/* ── demo tracks ── */
interface Track {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: number; // seconds
  color: string;
}

const DEMO_TRACKS: Track[] = [
  { id: 1, title: 'Cornstone Ambient', artist: 'Cornstone OS', album: 'Genesis', duration: 346, color: '#C9A84C' },
  { id: 2, title: 'Sacred Minimalism', artist: 'Cornstone OS', album: 'Exodus', duration: 272, color: '#5A8AB8' },
  { id: 3, title: 'Golden Hour', artist: 'Cornstone OS', album: 'Leviticus', duration: 238, color: '#5A9E6F' },
  { id: 4, title: 'Deep Space', artist: 'Cornstone OS', album: 'Numbers', duration: 372, color: '#7B6FB8' },
  { id: 5, title: 'Exodus 33:14', artist: 'Cornstone OS', album: 'Deuteronomy', duration: 423, color: '#D4953A' },
  { id: 6, title: 'Abyssal Drift', artist: 'Cornstone OS', album: 'Genesis', duration: 298, color: '#4A9E9E' },
  { id: 7, title: 'Stone Altar', artist: 'Cornstone OS', album: 'Exodus', duration: 315, color: '#B84A4A' },
  { id: 8, title: 'Morning Manna', artist: 'Cornstone OS', album: 'Leviticus', duration: 256, color: '#8B7340' },
];

interface Playlist {
  id: string;
  name: string;
  trackIds: number[];
}

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function MusicPlayer() {
  const [tracks] = useState<Track[]>(DEMO_TRACKS);
  const [currentTrack, setCurrentTrack] = useState<Track>(DEMO_TRACKS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // seconds
  const [volume, setVolume] = useState(70);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [playlists, setPlaylists] = useState<Playlist[]>([
    { id: 'default', name: 'All Tracks', trackIds: DEMO_TRACKS.map(t => t.id) },
    { id: 'favorites', name: 'Favorites', trackIds: [1, 3, 5] },
  ]);
  const [activePlaylist, setActivePlaylist] = useState('default');
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  const filteredTracks = tracks.filter(t => {
    const inPlaylist = activePlaylist === 'default' || playlists.find(p => p.id === activePlaylist)?.trackIds.includes(t.id);
    const matchesSearch = !searchQuery || t.title.toLowerCase().includes(searchQuery.toLowerCase()) || t.artist.toLowerCase().includes(searchQuery.toLowerCase());
    return inPlaylist && matchesSearch;
  });

  /* Simulated playback */
  useEffect(() => {
    if (isPlaying) {
      progressInterval.current = setInterval(() => {
        setProgress(prev => {
          if (prev >= currentTrack.duration) {
            if (repeat) return 0;
            /* Auto-advance */
            const idx = tracks.findIndex(t => t.id === currentTrack.id);
            const nextIdx = shuffle
              ? Math.floor(Math.random() * tracks.length)
              : (idx + 1) % tracks.length;
            setCurrentTrack(tracks[nextIdx]);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      if (progressInterval.current) clearInterval(progressInterval.current);
    }
    return () => { if (progressInterval.current) clearInterval(progressInterval.current); };
  }, [isPlaying, currentTrack, repeat, shuffle, tracks]);

  /* Visualizer */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animId: number;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (!isPlaying) {
        /* Static bars */
        const barCount = 30;
        const barWidth = canvas.width / barCount;
        for (let i = 0; i < barCount; i++) {
          const h = 5 + Math.sin(i * 0.5) * 5;
          ctx.fillStyle = `${currentTrack.color}40`;
          ctx.fillRect(i * barWidth, canvas.height - h, barWidth - 2, h);
        }
        animId = requestAnimationFrame(draw);
        return;
      }

      const barCount = 30;
      const barWidth = canvas.width / barCount;
      for (let i = 0; i < barCount; i++) {
        const simFreq = Math.sin(Date.now() * 0.005 + i * 0.3) * 0.5 + 0.5;
        const h = 5 + simFreq * (canvas.height - 5);
        ctx.fillStyle = currentTrack.color;
        ctx.globalAlpha = 0.4 + simFreq * 0.6;
        const x = i * barWidth;
        const y = canvas.height - h;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth - 2, h, 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, currentTrack]);

  const playTrack = useCallback((track: Track) => {
    setCurrentTrack(track);
    setProgress(0);
    setIsPlaying(true);
  }, []);

  const togglePlay = useCallback(() => setIsPlaying(prev => !prev), []);

  const prevTrack = useCallback(() => {
    const idx = tracks.findIndex(t => t.id === currentTrack.id);
    const prevIdx = (idx - 1 + tracks.length) % tracks.length;
    setCurrentTrack(tracks[prevIdx]);
    setProgress(0);
  }, [currentTrack, tracks]);

  const nextTrack = useCallback(() => {
    const idx = tracks.findIndex(t => t.id === currentTrack.id);
    const nextIdx = shuffle
      ? Math.floor(Math.random() * tracks.length)
      : (idx + 1) % tracks.length;
    setCurrentTrack(tracks[nextIdx]);
    setProgress(0);
  }, [currentTrack, tracks, shuffle]);

  const createPlaylist = useCallback(() => {
    if (!newPlaylistName.trim()) return;
    setPlaylists(prev => [...prev, { id: Date.now().toString(), name: newPlaylistName, trackIds: [] }]);
    setNewPlaylistName('');
    setShowCreatePlaylist(false);
  }, [newPlaylistName]);

  const progressPercent = currentTrack.duration > 0 ? (progress / currentTrack.duration) * 100 : 0;

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden">
      {/* Now playing */}
      <div className="shrink-0 p-4 flex flex-col items-center border-b border-[#2A2A3E]">
        {/* Album art / visualizer */}
        <div
          className="w-44 h-44 rounded-xl border-2 border-[#2A2A3E] flex items-center justify-center relative overflow-hidden mb-3"
          style={{ background: `linear-gradient(135deg, ${currentTrack.color}20, #12121A)` }}
        >
          <canvas ref={canvasRef} width={176} height={176} className="absolute inset-0" />
          <Music className="w-12 h-12 relative z-10" style={{ color: currentTrack.color, opacity: 0.6 }} />
        </div>

        {/* Track info */}
        <h2 className="text-base font-medium text-center">{currentTrack.title}</h2>
        <p className="text-xs text-[#8A8578] mt-0.5">{currentTrack.artist} — {currentTrack.album}</p>

        {/* Progress bar */}
        <div className="w-full max-w-sm mt-3 flex items-center gap-2">
          <span className="text-[10px] text-[#4D4A42] font-mono w-8 text-right">{formatTime(progress)}</span>
          <div
            className="flex-1 h-1 bg-[#2A2A3E] rounded-full cursor-pointer relative"
            onClick={e => {
              const rect = e.currentTarget.getBoundingClientRect();
              const pct = (e.clientX - rect.left) / rect.width;
              setProgress(Math.floor(pct * currentTrack.duration));
            }}
          >
            <div
              className="h-full rounded-full transition-all duration-1000"
              style={{ width: `${progressPercent}%`, background: currentTrack.color }}
            />
          </div>
          <span className="text-[10px] text-[#4D4A42] font-mono w-8">{formatTime(currentTrack.duration)}</span>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-4 mt-3">
          <button
            className={`p-2 rounded-full transition-colors ${shuffle ? 'text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
            onClick={() => setShuffle(!shuffle)}
          >
            <Shuffle className="w-4 h-4" />
          </button>
          <button className="p-2 rounded-full text-[#8A8578] hover:text-[#E8E4DC] transition-colors" onClick={prevTrack}>
            <SkipBack className="w-5 h-5" />
          </button>
          <button
            className="w-11 h-11 rounded-full flex items-center justify-center transition-colors"
            style={{ background: currentTrack.color }}
            onClick={togglePlay}
          >
            {isPlaying ? <Pause className="w-5 h-5 text-[#030305]" /> : <Play className="w-5 h-5 text-[#030305] ml-0.5" />}
          </button>
          <button className="p-2 rounded-full text-[#8A8578] hover:text-[#E8E4DC] transition-colors" onClick={nextTrack}>
            <SkipForward className="w-5 h-5" />
          </button>
          <button
            className={`p-2 rounded-full transition-colors ${repeat ? 'text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
            onClick={() => setRepeat(!repeat)}
          >
            <Repeat className="w-4 h-4" />
          </button>
        </div>

        {/* Volume */}
        <div className="flex items-center gap-2 mt-2 w-full max-w-xs">
          <button onClick={() => setVolume(v => v === 0 ? 70 : 0)}>
            {volume === 0 ? <VolumeX className="w-4 h-4 text-[#8A8578]" /> : volume < 50 ? <Volume1 className="w-4 h-4 text-[#8A8578]" /> : <Volume2 className="w-4 h-4 text-[#8A8578]" />}
          </button>
          <div
            className="flex-1 h-1 bg-[#2A2A3E] rounded-full cursor-pointer"
            onClick={e => {
              const rect = e.currentTarget.getBoundingClientRect();
              setVolume(Math.round(((e.clientX - rect.left) / rect.width) * 100));
            }}
          >
            <div className="h-full bg-[#C9A84C] rounded-full" style={{ width: `${volume}%` }} />
          </div>
          <span className="text-[10px] text-[#4D4A42] w-6 text-right">{volume}</span>
        </div>
      </div>

      {/* Playlist */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        {/* Playlist tabs + search */}
        <div className="flex items-center gap-2 px-3 py-2 border-b border-[#2A2A3E] shrink-0">
          <ListMusic className="w-4 h-4 text-[#8A8578]" />
          <div className="flex items-center gap-0 flex-1 overflow-x-auto">
            {playlists.map(p => (
              <button
                key={p.id}
                className={`px-3 py-1.5 text-xs transition-colors border-b-2 shrink-0 ${
                  activePlaylist === p.id ? 'border-[#C9A84C] text-[#C9A84C]' : 'border-transparent text-[#8A8578] hover:text-[#E8E4DC]'
                }`}
                onClick={() => setActivePlaylist(p.id)}
              >
                {p.name}
              </button>
            ))}
            <button
              className="px-2 py-1.5 text-xs text-[#8A8578] hover:text-[#C9A84C] transition-colors shrink-0"
              onClick={() => setShowCreatePlaylist(!showCreatePlaylist)}
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A1A26] border border-[#2A2A3E] shrink-0">
            <Search className="w-3 h-3 text-[#4D4A42]" />
            <input
              type="text"
              className="bg-transparent outline-none text-[11px] w-24 placeholder-[#4D4A42]"
              placeholder="Search..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {showCreatePlaylist && (
          <div className="flex items-center gap-2 px-3 py-1.5 border-b border-[#2A2A3E] shrink-0 bg-[#0A0A0F]">
            <input
              type="text"
              className="flex-1 bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs outline-none focus:border-[#C9A84C]"
              placeholder="Playlist name..."
              value={newPlaylistName}
              onChange={e => setNewPlaylistName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && createPlaylist()}
              autoFocus
            />
            <button className="px-2 py-1 text-xs bg-[#C9A84C] text-[#030305] rounded hover:bg-[#D4B85A]" onClick={createPlaylist}>Create</button>
            <button className="p-1 rounded hover:bg-[#222235]" onClick={() => setShowCreatePlaylist(false)}>
              <X className="w-3 h-3 text-[#8A8578]" />
            </button>
          </div>
        )}

        {/* Track list */}
        <div className="flex-1 overflow-y-auto">
          {filteredTracks.map((track, i) => (
            <div
              key={track.id}
              className={`flex items-center gap-3 px-3 py-2 cursor-pointer transition-colors ${
                currentTrack.id === track.id ? 'bg-[#222235] border-l-2 border-l-[#C9A84C]' : 'hover:bg-[#1A1A26] border-l-2 border-l-transparent'
              }`}
              onClick={() => playTrack(track)}
            >
              <span className="text-[10px] text-[#4D4A42] w-4 text-right shrink-0">{i + 1}</span>
              <div
                className="w-8 h-8 rounded flex items-center justify-center shrink-0"
                style={{ background: `${track.color}20` }}
              >
                <Music className="w-4 h-4" style={{ color: track.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className={`text-xs truncate ${currentTrack.id === track.id ? 'text-[#C9A84C]' : ''}`}>{track.title}</div>
                <div className="text-[10px] text-[#8A8578]">{track.artist}</div>
              </div>
              <span className="text-[10px] text-[#4D4A42] shrink-0">{formatTime(track.duration)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
