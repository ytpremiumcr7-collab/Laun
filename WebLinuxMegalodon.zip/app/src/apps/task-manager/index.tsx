import { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  Trash2,
  X,
  Search,
  CheckSquare,
  Clock,
  AlertCircle,
  ChevronDown,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
type Priority = 'Low' | 'Medium' | 'High';
type ColumnId = 'todo' | 'inprogress' | 'review' | 'done';

interface Task {
  id: string;
  title: string;
  description: string;
  priority: Priority;
  tags: string[];
  dueDate: string;
  column: ColumnId;
  createdAt: number;
}

interface Column {
  id: ColumnId;
  title: string;
  color: string;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const STORAGE_KEY = 'cornstone-tasks';

const COLUMNS: Column[] = [
  { id: 'todo', title: 'To Do', color: '#8A8578' },
  { id: 'inprogress', title: 'In Progress', color: '#5A8AB8' },
  { id: 'review', title: 'Review', color: '#C9A84C' },
  { id: 'done', title: 'Done', color: '#5A9E6F' },
];

const PRIORITY_COLORS: Record<Priority, string> = {
  Low: '#5A9E6F',
  Medium: '#C9A84C',
  High: '#B84A4A',
};

const DEFAULT_TAGS = ['bug', 'feature', 'design', 'urgent', 'backend', 'frontend'];

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */
function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { /* ignore */ }
  return [
    { id: 't1', title: 'Design system tokens', description: 'Define color palette, typography, spacing scale', priority: 'High', tags: ['design'], dueDate: '2025-07-01', column: 'todo', createdAt: Date.now() - 86400000 },
    { id: 't2', title: 'Calendar component', description: 'Build month grid with event support', priority: 'High', tags: ['feature', 'frontend'], dueDate: '2025-07-05', column: 'inprogress', createdAt: Date.now() - 172800000 },
    { id: 't3', title: 'Formula engine', description: 'Implement SUM, AVG, IF for spreadsheet', priority: 'Medium', tags: ['backend'], dueDate: '2025-07-10', column: 'inprogress', createdAt: Date.now() - 200000 },
    { id: 't4', title: 'PDF viewer render', description: 'Simulated PDF page display with zoom', priority: 'Low', tags: ['feature'], dueDate: '2025-07-15', column: 'done', createdAt: Date.now() - 300000000 },
  ];
}

function saveTasks(tasks: Task[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function generateId() {
  return `task-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

/* ------------------------------------------------------------------ */
/*  Task Modal                                                         */
/* ------------------------------------------------------------------ */
function TaskModal({
  task,
  onSave,
  onDelete,
  onClose,
}: {
  task?: Task;
  onSave: (t: Task) => void;
  onDelete?: (id: string) => void;
  onClose: () => void;
}) {
  const [title, setTitle] = useState(task?.title ?? '');
  const [description, setDescription] = useState(task?.description ?? '');
  const [priority, setPriority] = useState<Priority>(task?.priority ?? 'Medium');
  const [tags, setTags] = useState<string[]>(task?.tags ?? []);
  const [dueDate, setDueDate] = useState(task?.dueDate ?? '');
  const [column, setColumn] = useState<ColumnId>(task?.column ?? 'todo');
  const [tagInput, setTagInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSave({
      id: task?.id ?? generateId(),
      title: title.trim(),
      description: description.trim(),
      priority,
      tags,
      dueDate,
      column,
      createdAt: task?.createdAt ?? Date.now(),
    });
    onClose();
  };

  const toggleTag = (tag: string) => {
    setTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-[#030305]/60 backdrop-blur-sm" />
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="relative z-10 w-[460px] bg-[#1A1A26] border border-[#2A2A3E] rounded-xl shadow-[0_12px_48px_rgba(0,0,0,0.5)] p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-[#E8E4DC]">{task ? 'Edit Task' : 'New Task'}</h3>
          <button onClick={onClose} className="p-1 hover:bg-[#222235] rounded-lg transition-colors">
            <X className="w-4 h-4 text-[#8A8578]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Title *</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Task title"
              autoFocus
              className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details..."
              rows={3}
              className="w-full px-3 py-2 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none resize-none transition-colors"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-[#8A8578] mb-1">Priority</label>
              <div className="flex gap-1">
                {(['Low', 'Medium', 'High'] as Priority[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`flex-1 h-8 rounded-md text-xs font-medium transition-colors ${
                      priority === p ? 'text-[#030305]' : 'text-[#8A8578] hover:bg-[#222235] border border-[#2A2A3E]'
                    }`}
                    style={priority === p ? { backgroundColor: PRIORITY_COLORS[p] } : {}}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs text-[#8A8578] mb-1">Column</label>
              <select
                value={column}
                onChange={(e) => setColumn(e.target.value as ColumnId)}
                className="w-full h-8 px-2 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C]"
              >
                {COLUMNS.map((c) => (
                  <option key={c.id} value={c.id}>{c.title}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Due Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Tags</label>
            <div className="flex flex-wrap gap-1 mb-2">
              {DEFAULT_TAGS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={`px-2 h-6 rounded-full text-[10px] font-medium transition-colors ${
                    tags.includes(tag)
                      ? 'bg-[#C9A84C]/20 text-[#C9A84C] border border-[#C9A84C]/40'
                      : 'bg-[#222235] text-[#8A8578] border border-[#2A2A3E] hover:border-[#3D3D5C]'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
            <div className="flex gap-1">
              <input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                placeholder="Add custom tag"
                className="flex-1 h-8 px-2 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && tagInput.trim()) {
                    e.preventDefault();
                    if (!tags.includes(tagInput.trim())) setTags([...tags, tagInput.trim()]);
                    setTagInput('');
                  }
                }}
              />
              <button
                type="button"
                onClick={() => {
                  if (tagInput.trim() && !tags.includes(tagInput.trim())) {
                    setTags([...tags, tagInput.trim()]);
                    setTagInput('');
                  }
                }}
                className="px-2 h-8 bg-[#222235] text-[#8A8578] rounded-md text-xs hover:bg-[#2A2A3E] transition-colors"
              >
                Add
              </button>
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            {task && onDelete && (
              <button
                type="button"
                onClick={() => { onDelete(task.id); onClose(); }}
                className="px-4 h-9 bg-[#B84A4A]/10 text-[#B84A4A] rounded-md text-sm font-medium hover:bg-[#B84A4A]/20 transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete
              </button>
            )}
            <div className="flex-1" />
            <button
              type="button"
              onClick={onClose}
              className="px-4 h-9 bg-[#222235] text-[#E8E4DC] rounded-md text-sm font-medium hover:bg-[#2A2A3E] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 h-9 bg-[#C9A84C] text-[#030305] rounded-md text-sm font-semibold hover:bg-[#D4B85A] transition-colors"
            >
              Save
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Task Card                                                          */
/* ------------------------------------------------------------------ */
function TaskCard({
  task,
  onEdit,
  onDelete,
  onMove,
}: {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onMove: (id: string, column: ColumnId) => void;
}) {
  const [showMenu, setShowMenu] = useState(false);
  const overdue = task.dueDate && new Date(task.dueDate) < new Date() && task.column !== 'done';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg p-3 cursor-pointer hover:border-[#3D3D5C] hover:shadow-[0_2px_8px_rgba(0,0,0,0.2)] hover:-translate-y-0.5 transition-all group"
      onClick={() => onEdit(task)}
    >
      <div className="flex items-start justify-between mb-1.5">
        <h4 className="text-xs font-medium text-[#E8E4DC] flex-1 mr-2 leading-snug">{task.title}</h4>
        <div className="relative">
          <button
            onClick={(e) => { e.stopPropagation(); setShowMenu(!showMenu); }}
            className="opacity-0 group-hover:opacity-100 p-0.5 hover:bg-[#222235] rounded transition-all"
          >
            <ChevronDown className="w-3 h-3 text-[#8A8578]" />
          </button>
          {showMenu && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
              <div className="absolute right-0 top-5 z-20 w-[120px] bg-[#1A1A26] border border-[#2A2A3E] rounded-lg shadow-[0_4px_16px_rgba(0,0,0,0.3)] py-1">
                {COLUMNS.filter((c) => c.id !== task.column).map((col) => (
                  <button
                    key={col.id}
                    onClick={(e) => { e.stopPropagation(); onMove(task.id, col.id); setShowMenu(false); }}
                    className="w-full text-left px-3 py-1.5 text-[11px] text-[#E8E4DC] hover:bg-[#222235] transition-colors"
                  >
                    Move to {col.title}
                  </button>
                ))}
                <div className="border-t border-[#2A2A3E] my-0.5" />
                <button
                  onClick={(e) => { e.stopPropagation(); onDelete(task.id); setShowMenu(false); }}
                  className="w-full text-left px-3 py-1.5 text-[11px] text-[#B84A4A] hover:bg-[#B84A4A]/10 transition-colors"
                >
                  Delete
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {task.description && (
        <p className="text-[10px] text-[#8A8578] mb-2 line-clamp-2 leading-relaxed">{task.description}</p>
      )}

      <div className="flex flex-wrap gap-1 mb-2">
        {task.tags.map((tag) => (
          <span key={tag} className="px-1.5 py-0.5 bg-[#222235] text-[10px] text-[#8A8578] rounded-full">
            {tag}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <span
          className="flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded"
          style={{ backgroundColor: PRIORITY_COLORS[task.priority] + '20', color: PRIORITY_COLORS[task.priority] }}
        >
          <AlertCircle className="w-2.5 h-2.5" />
          {task.priority}
        </span>

        {task.dueDate && (
          <span className={`flex items-center gap-0.5 text-[10px] ${overdue ? 'text-[#B84A4A]' : 'text-[#8A8578]'}`}>
            <Clock className="w-2.5 h-2.5" />
            {task.dueDate}
          </span>
        )}
      </div>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Task Manager App                                              */
/* ------------------------------------------------------------------ */
export default function TaskManagerApp() {
  const [tasks, setTasks] = useState<Task[]>(loadTasks);
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPriority, setFilterPriority] = useState<Priority | 'All'>('All');
  const [filterTag, setFilterTag] = useState<string>('');
  const [dragOverColumn, setDragOverColumn] = useState<ColumnId | null>(null);

  useEffect(() => { saveTasks(tasks); }, [tasks]);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    tasks.forEach((t) => t.tags.forEach((tag) => tags.add(tag)));
    return Array.from(tags);
  }, [tasks]);

  const stats = useMemo(() => {
    const total = tasks.length;
    const done = tasks.filter((t) => t.column === 'done').length;
    return { total, done };
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (searchQuery && !t.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !t.description.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      if (filterPriority !== 'All' && t.priority !== filterPriority) return false;
      if (filterTag && !t.tags.includes(filterTag)) return false;
      return true;
    });
  }, [tasks, searchQuery, filterPriority, filterTag]);

  const handleSave = (task: Task) => {
    setTasks((prev) => {
      const idx = prev.findIndex((t) => t.id === task.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = task;
        return next;
      }
      return [...prev, task];
    });
  };

  const handleDelete = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  const handleMove = (id: string, column: ColumnId) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, column } : t)));
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    e.dataTransfer.setData('text/plain', taskId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, columnId: ColumnId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverColumn(columnId);
  };

  const handleDrop = (e: React.DragEvent, columnId: ColumnId) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    if (taskId) handleMove(taskId, columnId);
    setDragOverColumn(null);
  };

  const openEdit = (task: Task) => {
    setEditingTask(task);
    setShowModal(true);
  };

  const openNew = () => {
    setEditingTask(undefined);
    setShowModal(true);
  };

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#2A2A3E] bg-[#0A0A0F]">
        <div className="flex items-center gap-3">
          <CheckSquare className="w-5 h-5 text-[#C9A84C]" />
          <div>
            <h2 className="text-sm font-semibold text-[#E8E4DC]">Task Board</h2>
            <div className="text-[10px] text-[#8A8578]">
              {stats.total} tasks · {stats.done} completed · {stats.total - stats.done} remaining
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-3 h-3 text-[#4D4A42] absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search..."
              className="h-8 w-[140px] pl-7 pr-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          {/* Priority filter */}
          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value as Priority | 'All')}
            className="h-8 px-2 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C]"
          >
            <option value="All">All Priorities</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          {/* Tag filter */}
          <select
            value={filterTag}
            onChange={(e) => setFilterTag(e.target.value)}
            className="h-8 px-2 bg-[#12121A] border border-[#2A2A3E] rounded-md text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C]"
          >
            <option value="">All Tags</option>
            {allTags.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>

          <button
            onClick={openNew}
            className="h-8 px-3 bg-[#C9A84C] text-[#030305] rounded-md text-xs font-semibold hover:bg-[#D4B85A] transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Task
          </button>
        </div>
      </div>

      {/* Kanban board */}
      <div className="flex-1 overflow-x-auto overflow-y-hidden">
        <div className="flex gap-3 h-full p-4 min-w-[900px]">
          {COLUMNS.map((col) => {
            const colTasks = filteredTasks.filter((t) => t.column === col.id);
            const isDragOver = dragOverColumn === col.id;

            return (
              <div
                key={col.id}
                className={`flex-1 min-w-[220px] flex flex-col rounded-lg transition-colors ${
                  isDragOver ? 'bg-[#222235]/60 ring-1 ring-[#C9A84C] ring-dashed' : ''
                }`}
                onDragOver={(e) => handleDragOver(e, col.id)}
                onDragLeave={() => setDragOverColumn(null)}
                onDrop={(e) => handleDrop(e, col.id)}
              >
                {/* Column header */}
                <div className="flex items-center justify-between px-3 py-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: col.color }}
                    />
                    <span className="text-xs font-medium text-[#E8E4DC]">{col.title}</span>
                    <span className="text-[10px] text-[#8A8578] bg-[#1A1A26] px-1.5 py-0.5 rounded-full">
                      {colTasks.length}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setEditingTask({
                        id: generateId(),
                        title: '',
                        description: '',
                        priority: 'Medium',
                        tags: [],
                        dueDate: '',
                        column: col.id,
                        createdAt: Date.now(),
                      });
                      setShowModal(true);
                    }}
                    className="p-0.5 hover:bg-[#222235] rounded transition-colors text-[#4D4A42] hover:text-[#8A8578]"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Tasks */}
                <div className="flex-1 overflow-y-auto space-y-2 px-1 pb-2">
                  <AnimatePresence mode="popLayout">
                    {colTasks.map((task) => (
                      <div
                        key={task.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, task.id)}
                      >
                        <TaskCard
                          task={task}
                          onEdit={openEdit}
                          onDelete={handleDelete}
                          onMove={handleMove}
                        />
                      </div>
                    ))}
                  </AnimatePresence>
                  {colTasks.length === 0 && (
                    <div className="text-center py-6 text-[10px] text-[#4D4A42]">
                      Drop tasks here
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-4 py-2 border-t border-[#2A2A3E] bg-[#0A0A0F] flex items-center gap-3">
        <div className="flex-1 h-1.5 bg-[#1A1A26] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#5A9E6F] rounded-full transition-all duration-300"
            style={{ width: stats.total ? `${(stats.done / stats.total) * 100}%` : '0%' }}
          />
        </div>
        <span className="text-[10px] text-[#8A8578]">
          {stats.total ? Math.round((stats.done / stats.total) * 100) : 0}% complete
        </span>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
          <TaskModal
            task={editingTask}
            onSave={handleSave}
            onDelete={editingTask ? handleDelete : undefined}
            onClose={() => { setShowModal(false); setEditingTask(undefined); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
