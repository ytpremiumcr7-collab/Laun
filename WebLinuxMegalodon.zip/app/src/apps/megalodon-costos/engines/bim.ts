// =============================================================================
// Megalodon CostOS — BIM Quantification Engine
// =============================================================================

import { CATALOGO_CONCEPTOS, getMaterialsSubtotal, getLaborSubtotal, getEquipmentSubtotal, verifyUnitPrice } from '../data/catalogo';

export interface BIMElement {
  id: string;
  ifcClass: string;
  description: string;
  level: string;
  quantity: number;
  unit: string;
  conceptKey: string;
  cost: number;
}

export interface QuantificationResult {
  elements: BIMElement[];
  totalCost: number;
  byLevel: Record<string, number>;
  byCategory: Record<string, number>;
  verified: boolean;
  discrepancies: string[];
}

/** Synthetic BIM elements for a hospital project */
export function generateHospitalElements(): BIMElement[] {
  const elements: BIMElement[] = [
    // Foundation
    { id: 'BIM-001', ifcClass: 'IfcFooting', description: 'Zapata combinada Z-1', level: 'Cimentación', quantity: 45.5, unit: 'm3', conceptKey: 'CC-HG-003', cost: 0 },
    { id: 'BIM-002', ifcClass: 'IfcFooting', description: 'Zapata aislada Z-2', level: 'Cimentación', quantity: 28.3, unit: 'm3', conceptKey: 'CC-HG-003', cost: 0 },
    { id: 'BIM-003', ifcClass: 'IfcWall', description: 'Muro de contención M-1', level: 'Cimentación', quantity: 120.0, unit: 'm2', conceptKey: 'MA-HG-002', cost: 0 },
    // Ground floor
    { id: 'BIM-004', ifcClass: 'IfcColumn', description: 'Columna C-1 40x40cm', level: 'Planta Baja', quantity: 68.4, unit: 'm3', conceptKey: 'CC-HG-002', cost: 0 },
    { id: 'BIM-005', ifcClass: 'IfcSlab', description: 'Losa losa-1 20cm espesor', level: 'Planta Baja', quantity: 425.0, unit: 'm3', conceptKey: 'CC-HG-001', cost: 0 },
    { id: 'BIM-006', ifcClass: 'IfcWall', description: 'Muro divisorio MD-1 tabique 14cm', level: 'Planta Baja', quantity: 850.0, unit: 'm2', conceptKey: 'MA-HG-001', cost: 0 },
    { id: 'BIM-007', ifcClass: 'IfcWall', description: 'Muro exterior ME-1 block 15cm', level: 'Planta Baja', quantity: 620.0, unit: 'm2', conceptKey: 'MA-HG-002', cost: 0 },
    { id: 'BIM-008', ifcClass: 'IfcReinforcingBar', description: 'Acero refuerzo losa Grade 42', level: 'Planta Baja', quantity: 18450.0, unit: 'kg', conceptKey: 'ACR-HG-001', cost: 0 },
    { id: 'BIM-009', ifcClass: 'IfcReinforcingBar', description: 'Acero refuerzo columna Grade 60', level: 'Planta Baja', quantity: 22400.0, unit: 'kg', conceptKey: 'ACR-HG-002', cost: 0 },
    // First floor
    { id: 'BIM-010', ifcClass: 'IfcColumn', description: 'Columna C-2 35x35cm', level: 'Planta Alta', quantity: 52.8, unit: 'm3', conceptKey: 'CC-HG-002', cost: 0 },
    { id: 'BIM-011', ifcClass: 'IfcSlab', description: 'Losa losa-2 15cm espesor', level: 'Planta Alta', quantity: 380.0, unit: 'm3', conceptKey: 'CC-HG-001', cost: 0 },
    { id: 'BIM-012', ifcClass: 'IfcWall', description: 'Muro divisorio MD-2 tabique 14cm', level: 'Planta Alta', quantity: 720.0, unit: 'm2', conceptKey: 'MA-HG-001', cost: 0 },
    { id: 'BIM-013', ifcClass: 'IfcReinforcingBar', description: 'Acero refuerzo losa Grade 42', level: 'Planta Alta', quantity: 15200.0, unit: 'kg', conceptKey: 'ACR-HG-001', cost: 0 },
    // Finishes
    { id: 'BIM-014', ifcClass: 'IfcCovering', description: 'Aplanado muros interiores', level: 'Acabados', quantity: 2850.0, unit: 'm2', conceptKey: 'RE-HG-001', cost: 0 },
    { id: 'BIM-015', ifcClass: 'IfcCovering', description: 'Aplanado muros exteriores', level: 'Acabados', quantity: 1200.0, unit: 'm2', conceptKey: 'RE-HG-001', cost: 0 },
    { id: 'BIM-016', ifcClass: 'IfcCovering', description: 'Piso cerámico 30x30 pasillos', level: 'Acabados', quantity: 1850.0, unit: 'm2', conceptKey: 'PI-HG-001', cost: 0 },
    { id: 'BIM-017', ifcClass: 'IfcCovering', description: 'Piso cerámico 30x30 habitaciones', level: 'Acabados', quantity: 1420.0, unit: 'm2', conceptKey: 'PI-HG-001', cost: 0 },
    { id: 'BIM-018', ifcClass: 'IfcCovering', description: 'Pintura vinílica muros interiores 2 manos', level: 'Acabados', quantity: 4200.0, unit: 'm2', conceptKey: 'PN-HG-001', cost: 0 },
    // MEP
    { id: 'BIM-019', ifcClass: 'IfcDistributionElement', description: 'Instalación eléctrica planta baja', level: 'MEP', quantity: 2850.0, unit: 'm2', conceptKey: 'IE-HG-001', cost: 0 },
    { id: 'BIM-020', ifcClass: 'IfcDistributionElement', description: 'Instalación eléctrica planta alta', level: 'MEP', quantity: 2450.0, unit: 'm2', conceptKey: 'IE-HG-001', cost: 0 },
    { id: 'BIM-021', ifcClass: 'IfcDistributionElement', description: 'Instalación hidráulica planta baja', level: 'MEP', quantity: 2850.0, unit: 'm2', conceptKey: 'IH-HG-001', cost: 0 },
    { id: 'BIM-022', ifcClass: 'IfcDistributionElement', description: 'Instalación hidráulica planta alta', level: 'MEP', quantity: 2450.0, unit: 'm2', conceptKey: 'IH-HG-001', cost: 0 },
    // Doors
    { id: 'BIM-023', ifcClass: 'IfcDoor', description: 'Puerta metárica de tambor PM-1', level: 'Mobiliario', quantity: 24, unit: 'pza', conceptKey: 'PYV-HG-001', cost: 0 },
    { id: 'BIM-024', ifcClass: 'IfcDoor', description: 'Puerta metárica de tambor PM-2 doble', level: 'Mobiliario', quantity: 8, unit: 'pza', conceptKey: 'PYV-HG-001', cost: 0 },
    // Excavation
    { id: 'BIM-025', ifcClass: 'IfcEarthworksElement', description: 'Excavación cimentación maquinaria', level: 'Trabajos Temporales', quantity: 1250.0, unit: 'm3', conceptKey: 'TR-HG-002', cost: 0 },
    { id: 'BIM-026', ifcClass: 'IfcEarthworksElement', description: 'Excavación zanjas sanitarias manual', level: 'Trabajos Temporales', quantity: 85.0, unit: 'm3', conceptKey: 'TR-HG-001', cost: 0 },
  ];

  // Compute costs from catalog
  return elements.map((el) => {
    const concept = CATALOGO_CONCEPTOS.find((c) => c.key === el.conceptKey);
    if (concept) {
      return { ...el, cost: concept.unitPrice * el.quantity };
    }
    return el;
  });
}

/** Quantify a BIM model: compute costs, verify prices, group by level/category */
export function quantifyBIM(bimElements: BIMElement[]): QuantificationResult {
  const byLevel: Record<string, number> = {};
  const byCategory: Record<string, number> = {};
  const discrepancies: string[] = [];
  let totalCost = 0;

  for (const el of bimElements) {
    const concept = CATALOGO_CONCEPTOS.find((c) => c.key === el.conceptKey);
    if (!concept) {
      discrepancies.push(`Concepto "${el.conceptKey}" no encontrado en catálogo para ${el.id}`);
      continue;
    }

    const computedCost = concept.unitPrice * el.quantity;
    if (Math.abs(computedCost - el.cost) > 0.01) {
      discrepancies.push(`${el.id}: Costo computado $${computedCost.toFixed(2)} ≠ registrado $${el.cost.toFixed(2)}`);
    }

    const verified = verifyUnitPrice(concept);
    if (!verified.matches) {
      discrepancies.push(`${el.id}: Precio unitario desbalanceado — computado $${verified.computed.toFixed(2)} vs listado $${verified.listed.toFixed(2)} (dif: $${verified.diff.toFixed(2)})`);
    }

    byLevel[el.level] = (byLevel[el.level] || 0) + computedCost;
    byCategory[concept.category] = (byCategory[concept.category] || 0) + computedCost;
    totalCost += computedCost;
  }

  return {
    elements: bimElements,
    totalCost,
    byLevel,
    byCategory,
    verified: discrepancies.length === 0,
    discrepancies,
  };
}

/** Get concept breakdown for display */
export function getConceptBreakdown(conceptKey: string) {
  const concept = CATALOGO_CONCEPTOS.find((c) => c.key === conceptKey);
  if (!concept) return null;
  return {
    key: concept.key,
    description: concept.description,
    unit: concept.unit,
    unitPrice: concept.unitPrice,
    materials: { items: concept.materials, subtotal: getMaterialsSubtotal(concept) },
    labor: { items: concept.labor, subtotal: getLaborSubtotal(concept) },
    equipment: { items: concept.equipment, subtotal: getEquipmentSubtotal(concept) },
    verified: verifyUnitPrice(concept),
  };
}
