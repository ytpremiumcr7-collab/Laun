import { useStarMapStore } from '../../../stores/useStarMapStore';
import { COMMUNITIES } from '../data/papers';

interface LegendProps {
  paperCounts: Record<string, number>;
}

export default function Legend({ paperCounts }: LegendProps) {
  const activeCommunity = useStarMapStore((s) => s.activeCommunity);
  const setActiveCommunity = useStarMapStore((s) => s.setActiveCommunity);
  const resetView = useStarMapStore((s) => s.resetView);

  return (
    <div className="absolute bottom-0 left-0 right-0 h-10 bg-[rgba(3,3,5,0.7)] backdrop-blur-sm border-t border-[#2A2A3E] flex items-center px-4 gap-1 z-10">
      <button
        onClick={() => { setActiveCommunity(null); resetView(); }}
        className={`px-2.5 py-1 rounded text-[11px] font-medium transition-all ${
          activeCommunity === null
            ? 'bg-[#C9A84C]/20 text-[#C9A84C] ring-1 ring-[#C9A84C]'
            : 'text-[#8A8578] hover:text-[#E8E4DC] hover:bg-[#222235]'
        }`}
      >
        Todos
      </button>

      <div className="w-px h-4 bg-[#2A2A3E] mx-1" />

      {Object.entries(COMMUNITIES).map(([key, { color, label }]) => {
        const count = paperCounts[key] || 0;
        const isActive = activeCommunity === key;

        return (
          <button
            key={key}
            onClick={() => setActiveCommunity(isActive ? null : key)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] transition-all ${
              isActive
                ? 'ring-1'
                : 'hover:bg-[#222235]'
            }`}
            style={
              isActive
                ? { color, backgroundColor: `${color}15`, outline: `1px solid ${color}` }
                : { color: '#8A8578' }
            }
            title={`${label}: ${count} papers`}
          >
            <span
              className="w-2.5 h-2.5 rounded-full shrink-0"
              style={{ backgroundColor: color, opacity: isActive ? 1 : 0.6 }}
            />
            <span className="whitespace-nowrap">{label}</span>
            <span className="text-[10px] opacity-50">({count})</span>
          </button>
        );
      })}
    </div>
  );
}
