import { useRef, useMemo, useCallback } from 'react';
import { useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { useStarMapStore } from '../../../stores/useStarMapStore';
import Node from './Node';
import Edge from './Edge';
import { PAPERS, EDGES } from '../data/papers';

/** Starfield background particles */
function Starfield() {
  const pointsRef = useRef<THREE.Points>(null);

  const { positions, colors } = useMemo(() => {
    const count = 1000;
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const palette = [
      [1, 1, 1],
      [0.788, 0.659, 0.298],
      [0.482, 0.435, 0.722],
    ];

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const r = 70 + Math.random() * 80;

      pos[i3] = r * Math.sin(phi) * Math.cos(theta) * 1.4;
      pos[i3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.9;
      pos[i3 + 2] = r * Math.cos(phi) * 0.8;

      const colorIdx = Math.random() < 0.7 ? 0 : Math.random() < 0.85 ? 1 : 2;
      const c = palette[colorIdx];
      const intensity = 0.3 + Math.random() * 0.7;
      col[i3] = c[0] * intensity;
      col[i3 + 1] = c[1] * intensity;
      col[i3 + 2] = c[2] * intensity;
    }

    return { positions: pos, colors: col };
  }, []);

  useFrame((_, delta) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y += delta * 0.005;
      pointsRef.current.rotation.x += delta * 0.002;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
        <bufferAttribute
          attach="attributes-color"
          args={[colors, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.3}
        vertexColors
        transparent
        opacity={0.8}
        depthWrite={false}
        sizeAttenuation
      />
    </points>
  );
}

/** Main 3D Scene */
export default function Scene() {
  const setSelectedNode = useStarMapStore((s) => s.setSelectedNode);
  const setCameraTarget = useStarMapStore((s) => s.setCameraTarget);
  const resetSelection = useStarMapStore((s) => s.resetSelection);
  const selectedNode = useStarMapStore((s) => s.selectedNode);
  const controlsRef = useRef<any>(null);

  const neighborIds = useMemo(() => {
    if (!selectedNode) return new Set<string>();
    const neighbors = new Set<string>();
    for (const edge of EDGES) {
      if (edge.source === selectedNode) neighbors.add(edge.target);
      if (edge.target === selectedNode) neighbors.add(edge.source);
    }
    return neighbors;
  }, [selectedNode]);

  const targetPos = useRef(new THREE.Vector3(0, 0, 0));

  const handleNodeClick = useCallback((paper: typeof PAPERS[0]) => {
    setSelectedNode(paper.id);
    setCameraTarget(paper.position);
    targetPos.current.set(...paper.position);
  }, [setSelectedNode, setCameraTarget]);

  const handleBackgroundClick = useCallback(() => {
    resetSelection();
  }, [resetSelection]);

  useFrame((_, delta) => {
    if (controlsRef.current) {
      const currentTarget = controlsRef.current.target as THREE.Vector3;
      currentTarget.lerp(targetPos.current, delta * 3);
    }
  });

  useMemo(() => {
    if (!selectedNode) {
      targetPos.current.set(0, 0, 0);
    }
  }, [selectedNode]);

  return (
    <>
      <ambientLight color="#404040" intensity={0.5} />
      <pointLight color="#C9A84C" intensity={0.8} position={[0, 50, 50]} />

      <Starfield />

      {EDGES.map((edge, i) => (
        <Edge key={`edge-${i}`} edge={edge} papers={PAPERS} />
      ))}

      {PAPERS.map((paper) => (
        <Node
          key={paper.id}
          paper={paper}
          neighborIds={neighborIds}
          onClick={handleNodeClick}
        />
      ))}

      <mesh onClick={handleBackgroundClick} visible={false}>
        <sphereGeometry args={[200, 8, 8]} />
        <meshBasicMaterial side={THREE.BackSide} />
      </mesh>

      <OrbitControls
        ref={controlsRef}
        enableDamping
        dampingFactor={0.05}
        minDistance={20}
        maxDistance={150}
        autoRotate
        autoRotateSpeed={0.3}
        enablePan
        mouseButtons={{
          LEFT: 0,
          MIDDLE: 1,
          RIGHT: 2,
        }}
        onStart={() => {
          if (controlsRef.current) {
            controlsRef.current.autoRotate = false;
          }
        }}
        onEnd={() => {
          setTimeout(() => {
            if (controlsRef.current) {
              controlsRef.current.autoRotate = true;
            }
          }, 5000);
        }}
      />
    </>
  );
}
