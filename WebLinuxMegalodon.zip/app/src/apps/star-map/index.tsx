import { useMemo, useCallback, Suspense, Component, type ReactNode } from 'react';
import { Canvas } from '@react-three/fiber';
import Scene from './components/Scene';
import DetailCard from './components/DetailCard';
import Legend from './components/Legend';
import Controls from './components/Controls';
import { PAPERS, EDGES } from './data/papers';
import { useStarMapStore } from '../../stores/useStarMapStore';

/** Simple error boundary for WebGL failures */
interface EBState { hasError: boolean; error: Error | null }
interface EBProps { children: ReactNode; fallback: React.ComponentType<{ error: Error }> }

class ErrorBoundary extends Component<EBProps, EBState> {
  constructor(props: EBProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error: Error): EBState {
    return { hasError: true, error };
  }
  render() {
    if (this.state.hasError && this.state.error) {
      const Fallback = this.props.fallback;
      return <Fallback error={this.state.error} />;
    }
    return this.props.children;
  }
}

function CanvasErrorFallback({ error }: { error: Error }) {
  return (
    <div className="w-full h-full flex items-center justify-center bg-[#030305] text-[#E8E4DC]">
      <div className="text-center">
        <div className="text-[#B84A4A] text-sm font-semibold mb-2">Error de WebGL</div>
        <div className="text-[#8A8578] text-xs mb-4">{error.message}</div>
        <div className="text-[#4D4A42] text-[11px]">Intenta recargar la pagina o usa un navegador con soporte WebGL</div>
      </div>
    </div>
  );
}

function CanvasLoader() {
  return (
    <div className="w-full h-full flex items-center justify-center bg-[#030305]">
      <div className="text-center">
        <div className="w-12 h-12 border-2 border-[#C9A84C] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <div className="text-[#8A8578] text-sm">Cargando constelacion...</div>
      </div>
    </div>
  );
}

export default function StarMap() {
  const selectedNode = useStarMapStore((s) => s.selectedNode);
  const resetSelection = useStarMapStore((s) => s.resetSelection);
  const resetView = useStarMapStore((s) => s.resetView);
  const setSelectedNode = useStarMapStore((s) => s.setSelectedNode);
  const setCameraTarget = useStarMapStore((s) => s.setCameraTarget);

  const paperCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const p of PAPERS) {
      counts[p.community] = (counts[p.community] || 0) + 1;
    }
    return counts;
  }, []);

  const selectedPaper = useMemo(() => {
    if (!selectedNode) return null;
    return PAPERS.find((p) => p.id === selectedNode) || null;
  }, [selectedNode]);

  const handleSelectPaper = useCallback((paper: typeof PAPERS[0]) => {
    setSelectedNode(paper.id);
    setCameraTarget(paper.position);
  }, [setSelectedNode, setCameraTarget]);

  const handleDeselect = useCallback(() => {
    resetSelection();
  }, [resetSelection]);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] relative flex flex-col overflow-hidden">
      <ErrorBoundary fallback={CanvasErrorFallback}>
        <Suspense fallback={<CanvasLoader />}>
          <div className="flex-1 relative">
            <Canvas
              camera={{ position: [0, 0, 80], fov: 60, near: 0.1, far: 1000 }}
              onPointerMissed={handleDeselect}
              gl={{ antialias: true, alpha: false }}
              style={{ background: '#030305' }}
            >
              <Scene />
            </Canvas>

            <Controls
              papers={PAPERS}
              onSelectPaper={handleSelectPaper}
              onResetView={resetView}
            />

            <Legend paperCounts={paperCounts} />

            {selectedPaper && (
              <DetailCard
                paper={selectedPaper}
                edges={EDGES}
                allPapers={PAPERS}
                onClose={handleDeselect}
                onSelectNeighbor={handleSelectPaper}
              />
            )}

            <div className="absolute bottom-12 right-3 text-[10px] text-[#4D4A42] pointer-events-none select-none">
              <div className="flex items-center gap-1 mb-0.5">
                <span className="text-[#8A8578]">Arrastrar:</span> Rotar / Pan
              </div>
              <div className="flex items-center gap-1 mb-0.5">
                <span className="text-[#8A8578]">Scroll:</span> Zoom
              </div>
              <div className="flex items-center gap-1">
                <span className="text-[#8A8578]">Click:</span> Seleccionar nodo
              </div>
            </div>
          </div>
        </Suspense>
      </ErrorBoundary>
    </div>
  );
}
