// =============================================================================
// 3D Citation Star-Map — Neuroscience Paper Corpus (~50 papers)
// =============================================================================

export interface PaperNode {
  id: string;
  title: string;
  authors: string[];
  year: number;
  abstract: string;
  keywords: string[];
  community: string;
  url: string;
  citationCount: number;
  position: [number, number, number];
}

export interface CitationEdge {
  source: string;
  target: string;
}

export const COMMUNITIES: Record<string, { color: string; label: string }> = {
  'motor-control': { color: '#C9A84C', label: 'Motor Control' },
  'visual-cortex': { color: '#7B6FB8', label: 'Visual Cortex' },
  'memory-learning': { color: '#5A9E6F', label: 'Memory & Learning' },
  'decision-making': { color: '#5A8AB8', label: 'Decision Making' },
  'neural-oscillations': { color: '#D4953A', label: 'Neural Oscillations' },
  'computational': { color: '#9E6F8A', label: 'Computational Models' },
  'clinical': { color: '#6F9E9E', label: 'Clinical Neuroscience' },
};

// Fibonacci ellipsoid distribution for positions
function distributePositions(count: number, communityIndex: number, totalCommunities: number): [number, number, number][] {
  const rx = 55;
  const ry = 40;
  const rz = 30;
  const positions: [number, number, number][] = [];
  
  // Offset each community to a different region of the ellipsoid
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));
  const communityOffset = (communityIndex / totalCommunities) * Math.PI * 2;
  
  for (let i = 0; i < count; i++) {
    const y = 1 - (i / (count - 1)) * 2;
    const radius = Math.sqrt(1 - y * y);
    const theta = goldenAngle * i + communityOffset;
    
    const x = Math.cos(theta) * radius * rx;
    const z = Math.sin(theta) * radius * rz;
    const yPos = y * ry;
    
    // Add some jitter
    const jitter = 3;
    positions.push([
      x + (Math.random() - 0.5) * jitter,
      yPos + (Math.random() - 0.5) * jitter,
      z + (Math.random() - 0.5) * jitter,
    ]);
  }
  return positions;
}

function generatePapers(): PaperNode[] {
  const paperData: Omit<PaperNode, 'position'>[][] = [
    // ==== MOTOR CONTROL (7) ====
    [
      {
        id: 'motor-1',
        title: 'Cortical Control of Arm Movements: A Dynamical Systems Perspective',
        authors: ['Shenoy KV', 'Sahani M', 'Churchland MM'],
        year: 2013,
        abstract: 'We review evidence that motor cortex generates muscle activity through a dynamical system, where neural population activity evolves as a dynamical process that generates outputs driving muscle activity.',
        keywords: ['motor cortex', 'dynamical systems', 'arm movements', 'population activity'],
        community: 'motor-control',
        url: 'https://doi.org/10.1146/annurev-neuro-062111-150509',
        citationCount: 1842,
      },
      {
        id: 'motor-2',
        title: 'Neural Population Dynamics During Reaching',
        authors: ['Churchland MM', 'Cunningham JP', 'Kaufman MT', 'Foster JD', 'Nuyujukian P', 'Ryu SI', 'Shenoy KV'],
        year: 2012,
        abstract: 'Neural activity in motor cortex is dominated by a strong, low-dimensional rhythm that generates a consistent pattern of activity across the neural population during reaching.',
        keywords: ['motor cortex', 'neural dynamics', 'reaching', 'population coding'],
        community: 'motor-control',
        url: 'https://doi.org/10.1038/nature11129',
        citationCount: 2105,
      },
      {
        id: 'motor-3',
        title: 'The Müller-Lyer Illusion and the Principles of Vector Encoding',
        authors: ['Georgopoulos AP', 'Lurito JT', 'Petrides M', 'Schwartz AB', 'Massey JT'],
        year: 1989,
        abstract: 'Neuronal population vectors in motor cortex code the direction of arm movements. The vector average of activated cells predicts movement direction accurately.',
        keywords: ['population vector', 'motor cortex', 'directional coding', 'arm movement'],
        community: 'motor-control',
        url: 'https://doi.org/10.1002/neu.480200302',
        citationCount: 1650,
      },
      {
        id: 'motor-4',
        title: 'Cerebellar Contributions to Motor Control: Evidence from Lesion Studies',
        authors: ['Thach WT', 'Goodkin HP', 'Keating JG'],
        year: 1992,
        abstract: 'Cerebellar lesions produce specific deficits in the coordination and timing of multijoint movements, supporting a role for the cerebellum in motor learning and coordination.',
        keywords: ['cerebellum', 'motor coordination', 'lesion studies', 'timing'],
        community: 'motor-control',
        url: 'https://doi.org/10.1016/S0301-0082(05)80003-3',
        citationCount: 1420,
      },
      {
        id: 'motor-5',
        title: 'Basal Ganglia Circuits for Motor Control: An Integrated View',
        authors: ['Grillner S', 'Robertson B', 'Stephenson-Jones M'],
        year: 2013,
        abstract: 'The basal ganglia form a key part of the motor control hierarchy, integrating cortical and subcortical inputs to select and initiate appropriate actions.',
        keywords: ['basal ganglia', 'motor control', 'action selection', 'circuits'],
        community: 'motor-control',
        url: 'https://doi.org/10.1016/j.cub.2013.08.040',
        citationCount: 890,
      },
      {
        id: 'motor-6',
        title: 'Motor Learning in the Vestibulo-Ocular Reflex: Computational Models',
        authors: ['Lisberger SG'],
        year: 1988,
        abstract: 'The vestibulo-ocular reflex undergoes adaptive changes in gain through cerebellar-dependent learning mechanisms, providing a model system for understanding motor learning.',
        keywords: ['VOR', 'motor learning', 'cerebellum', 'vestibular'],
        community: 'motor-control',
        url: 'https://doi.org/10.1146/annurev.ne.11.030188.002401',
        citationCount: 1105,
      },
      {
        id: 'motor-7',
        title: 'Interneuron Types in the Spinal Cord and Their Role in Movement',
        authors: ['Goulding M'],
        year: 2009,
        abstract: 'Spinal interneurons form diverse functional classes that participate in the patterning and coordination of movement through specific connectivity patterns.',
        keywords: ['spinal cord', 'interneurons', 'locomotion', 'motor circuits'],
        community: 'motor-control',
        url: 'https://doi.org/10.1016/j.neuron.2009.09.010',
        citationCount: 975,
      },
    ],
    // ==== VISUAL CORTEX (7) ====
    [
      {
        id: 'visual-1',
        title: 'The Columnar Organization of the Neocortex',
        authors: ['Mountcastle VB'],
        year: 1997,
        abstract: 'The cerebral cortex is organized into vertical columns of neurons that form the fundamental computational units, processing specific features of sensory input.',
        keywords: ['cortical columns', 'neocortex', 'organization', 'sensory processing'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1093/brain/120.4.701',
        citationCount: 3200,
      },
      {
        id: 'visual-2',
        title: 'Receptive Fields, Binocular Interaction and Functional Architecture in the Cat Visual Cortex',
        authors: ['Hubel DH', 'Wiesel TN'],
        year: 1962,
        abstract: 'Neurons in cat visual cortex have binocular receptive fields with specific orientational preferences. The cortex contains a functional architecture of orientation columns and ocular dominance columns.',
        keywords: ['visual cortex', 'receptive fields', 'orientation columns', 'Hubel-Wiesel'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1113/jphysiol.1962.sp006837',
        citationCount: 5800,
      },
      {
        id: 'visual-3',
        title: 'A Feature-Integration Theory of Attention',
        authors: ['Treisman AM', 'Gelade G'],
        year: 1980,
        abstract: 'Visual perception of features occurs in parallel across the visual field, but attention is required to conjoin features into unified object representations.',
        keywords: ['attention', 'feature integration', 'visual perception', 'binding problem'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1016/0010-0285(80)90005-5',
        citationCount: 8900,
      },
      {
        id: 'visual-4',
        title: 'The Ventral Visual Pathway: An Expanded Neural Framework for Object Recognition',
        authors: ['DiCarlo JJ', 'Zoccolan D', 'Rust NC'],
        year: 2012,
        abstract: 'The ventral visual stream transforms retinal images into increasingly complex and tolerant representations, ultimately supporting object recognition behavior.',
        keywords: ['ventral stream', 'object recognition', 'visual cortex', 'hierarchy'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1016/j.neuron.2012.09.010',
        citationCount: 2450,
      },
      {
        id: 'visual-5',
        title: 'Divisive Normalization in Olfactory Population Codes',
        authors: ['Olsen SR', 'Bhandawat V', 'Wilson RI'],
        year: 2010,
        abstract: 'Gain control mechanisms in sensory systems implement divisive normalization, enabling efficient population coding across diverse stimulus intensities.',
        keywords: ['normalization', 'population coding', 'sensory processing', 'gain control'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1016/j.neuron.2010.01.008',
        citationCount: 760,
      },
      {
        id: 'visual-6',
        title: 'Predictive Coding in the Visual Cortex: A Functional Interpretation of Extra-Classical Receptive-Field Effects',
        authors: ['Rao RP', 'Ballard DH'],
        year: 1999,
        abstract: 'Feedback connections in visual cortex carry predictions of neural activity, while feedforward connections carry prediction errors, implementing a hierarchical predictive coding architecture.',
        keywords: ['predictive coding', 'visual cortex', 'feedback', 'receptive fields'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1038/4580',
        citationCount: 4320,
      },
      {
        id: 'visual-7',
        title: 'Sparseness of the Neuronal Representation of Stimuli in the Primate Temporal Visual Cortex',
        authors: ['Rolls ET', 'Tovee MJ'],
        year: 1995,
        abstract: 'Neurons in the inferior temporal visual cortex respond sparsely and selectively to complex visual stimuli, with only a small fraction of neurons active for any given stimulus.',
        keywords: ['sparse coding', 'temporal cortex', 'visual recognition', 'neuronal selectivity'],
        community: 'visual-cortex',
        url: 'https://doi.org/10.1002/cne.903460103',
        citationCount: 1580,
      },
    ],
    // ==== MEMORY & LEARNING (7) ====
    [
      {
        id: 'memory-1',
        title: 'The Hippocampus as a Cognitive Map',
        authors: ['O\'Keefe J', 'Nadel L'],
        year: 1978,
        abstract: 'Hippocampal place cells encode the animal\'s position in space, forming a neural representation of the environment that supports spatial navigation and memory.',
        keywords: ['hippocampus', 'place cells', 'spatial memory', 'cognitive map'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1007/978-3-642-36570-4',
        citationCount: 6700,
      },
      {
        id: 'memory-2',
        title: 'Long-Term Potentiation: A Mechanism for Memory Storage in the Brain',
        authors: ['Bliss TVP', 'Collingridge GL'],
        year: 1993,
        abstract: 'Long-term potentiation (LTP) at synapses in the hippocampus and other brain regions provides a cellular mechanism for activity-dependent synaptic plasticity that may underlie learning and memory.',
        keywords: ['LTP', 'synaptic plasticity', 'hippocampus', 'learning', 'memory'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1038/361031a0',
        citationCount: 5200,
      },
      {
        id: 'memory-3',
        title: 'Synaptic Tagging and Long-Term Potentiation',
        authors: ['Frey U', 'Morris RG'],
        year: 1997,
        abstract: 'Protein synthesis-dependent late LTP can capture and stabilize synaptic changes initiated by prior protein synthesis-independent early LTP at nearby synapses, providing a synaptic tagging mechanism.',
        keywords: ['synaptic tagging', 'LTP', 'protein synthesis', 'memory consolidation'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1038/385533a0',
        citationCount: 2100,
      },
      {
        id: 'memory-4',
        title: 'Pattern Separation in the Dentate Gyrus and CA3 of the Hippocampus',
        authors: ['Leutgeb JK', 'Leutgeb S', 'Moser MB', 'Moser EI'],
        year: 2007,
        abstract: 'Hippocampal CA3 neurons perform pattern completion while dentate gyrus granule cells perform pattern separation, enabling the brain to distinguish similar memories.',
        keywords: ['pattern separation', 'hippocampus', 'dentate gyrus', 'CA3', 'memory'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1126/science.1145803',
        citationCount: 1850,
      },
      {
        id: 'memory-5',
        title: 'Consolidation and Reconsolidation: Two Lives of Memories?',
        authors: ['Nader K', 'Hardt O'],
        year: 2009,
        abstract: 'Memories become labile and susceptible to modification upon reactivation, requiring reconsolidation to restabilize. This process provides a window for memory updating and therapeutic intervention.',
        keywords: ['reconsolidation', 'memory', 'hippocampus', 'amnesia', 'fear conditioning'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1016/j.neuron.2009.07.031',
        citationCount: 1450,
      },
      {
        id: 'memory-6',
        title: 'Sleep-Dependent Memory Consolidation and Reconsolidation',
        authors: ['Rasch B', 'Born J'],
        year: 2013,
        abstract: 'Sleep actively contributes to the consolidation of newly acquired memories through systems consolidation involving hippocampal-neocortical dialogue and synaptic homeostasis.',
        keywords: ['sleep', 'memory consolidation', 'hippocampus', 'replay', 'spindles'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1016/j.physbeh.2013.02.001',
        citationCount: 1320,
      },
      {
        id: 'memory-7',
        title: 'Dopamine Neurons and Their Role in Reward-Motivated Learning',
        authors: ['Schultz W'],
        year: 2015,
        abstract: 'Midbrain dopamine neurons signal reward prediction errors, providing a teaching signal that drives reinforcement learning and shapes motivated behavior.',
        keywords: ['dopamine', 'reward', 'reinforcement learning', 'VTA', 'prediction error'],
        community: 'memory-learning',
        url: 'https://doi.org/10.1016/j.neuron.2015.05.014',
        citationCount: 1680,
      },
    ],
    // ==== DECISION MAKING (7) ====
    [
      {
        id: 'decision-1',
        title: 'A Framework for Studying the Neurobiology of Value-Based Decision Making',
        authors: ['Rangel A', 'Camerer C', 'Montague PR'],
        year: 2008,
        abstract: 'Value-based decision making involves five basic processes: representation of the decision problem, valuation of options, selection, outcome evaluation, and learning.',
        keywords: ['decision making', 'neuroeconomics', 'value', 'prefrontal cortex', 'reward'],
        community: 'decision-making',
        url: 'https://doi.org/10.1038/nn2068',
        citationCount: 3100,
      },
      {
        id: 'decision-2',
        title: 'Neural Correlates of Decision Variables in Parietal Cortex',
        authors: ['Platt ML', 'Glimcher PW'],
        year: 1999,
        abstract: 'Parietal cortex neurons encode the expected gain of eye movements, providing evidence that sensory-motor structures represent the subjective value of actions.',
        keywords: ['parietal cortex', 'decision making', 'expected value', 'saccade', 'LIP'],
        community: 'decision-making',
        url: 'https://doi.org/10.1038/22268',
        citationCount: 2800,
      },
      {
        id: 'decision-3',
        title: 'Emotion, Decision Making and the Orbitofrontal Cortex',
        authors: ['Bechara A', 'Damasio H', 'Damasio AR'],
        year: 2000,
        abstract: 'The orbitofrontal cortex is critical for integrating emotional signals into decision-making processes. Patients with OFC lesions show impaired real-life decisions despite preserved intellectual abilities.',
        keywords: ['orbitofrontal cortex', 'emotion', 'decision making', 'somatic marker', 'gambling task'],
        community: 'decision-making',
        url: 'https://doi.org/10.1093/cercor/10.3.295',
        citationCount: 3900,
      },
      {
        id: 'decision-4',
        title: 'Neural Computations Underlying Causal Learning',
        authors: ['Gershman SJ', 'Blei DM', 'Niv Y'],
        year: 2010,
        abstract: 'Causal learning can be understood as Bayesian structure learning over a hypothesis space of causal graphical models, with neural correlates in prefrontal cortex and striatum.',
        keywords: ['causal learning', 'Bayesian inference', 'prefrontal cortex', 'striatum', 'structure learning'],
        community: 'decision-making',
        url: 'https://doi.org/10.1016/j.conb.2010.05.001',
        citationCount: 920,
      },
      {
        id: 'decision-5',
        title: 'The Role of the Ventromedial Prefrontal Cortex in Abstract State-Based Inference',
        authors: ['Schuck NW', 'Cai MB', 'Wilson RC', 'Niv Y'],
        year: 2016,
        abstract: 'The ventromedial prefrontal cortex represents the structure of the task environment, enabling model-based decision making and state inference.',
        keywords: ['vmPFC', 'model-based', 'reinforcement learning', 'state inference', 'structure'],
        community: 'decision-making',
        url: 'https://doi.org/10.1038/nn.4390',
        citationCount: 680,
      },
      {
        id: 'decision-6',
        title: 'A Model of Neural Control of Reward-Seeking Behavior',
        authors: ['McClure SM', 'Daw ND', 'Montague PR'],
        year: 2003,
        abstract: 'Temporal difference learning models explain how the brain assigns value to future rewards and makes intertemporal choices, with distinct neural systems for immediate and delayed rewards.',
        keywords: ['temporal difference', 'reward', 'striatum', 'prefrontal cortex', 'intertemporal choice'],
        community: 'decision-making',
        url: 'https://doi.org/10.1016/S0896-6273(03)00188-4',
        citationCount: 1750,
      },
      {
        id: 'decision-7',
        title: 'Uncertainty-Based Competition Between Prefrontal and Dorsolateral Striatal Systems',
        authors: ['Daw ND', 'Niv Y', 'Dayan P'],
        year: 2005,
        abstract: 'The brain arbitrates between model-based and model-free reinforcement learning systems based on their relative uncertainty, with model-based control dominating when uncertainty is low.',
        keywords: ['model-based', 'model-free', 'uncertainty', 'arbitration', 'striatum', 'PFC'],
        community: 'decision-making',
        url: 'https://doi.org/10.1038/nn1560',
        citationCount: 2100,
      },
    ],
    // ==== NEURAL OSCILLATIONS (7) ====
    [
      {
        id: 'osc-1',
        title: 'Gamma Oscillations and Functional Coupling of Brain Regions',
        authors: ['Singer W'],
        year: 1993,
        abstract: 'Gamma oscillations (30-80 Hz) synchronize distributed neuronal assemblies, providing a mechanism for feature binding and communication between brain regions.',
        keywords: ['gamma oscillations', 'synchrony', 'binding', 'feature integration', 'EEG'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1016/0166-2236(93)90156-7',
        citationCount: 3400,
      },
      {
        id: 'osc-2',
        title: 'Cross-Frequency Coupling Between Neuronal Oscillations',
        authors: ['Canolty RT', 'Knight RT'],
        year: 2010,
        abstract: 'Cross-frequency coupling, particularly theta-gamma coupling, provides a mechanism for multi-scale temporal coordination in neural systems and may support working memory and cognitive control.',
        keywords: ['cross-frequency coupling', 'theta', 'gamma', 'working memory', 'LFP'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1016/j.tics.2010.09.004',
        citationCount: 2150,
      },
      {
        id: 'osc-3',
        title: 'Hippocampal Sharp Wave-Ripples: A Cognitive Biomarker for Episodic Memory and Planning',
        authors: ['Buzsáki G'],
        year: 2015,
        abstract: 'Sharp wave-ripple complexes in the hippocampus represent compressed replay of recent experiences, supporting memory consolidation, planning, and imagination.',
        keywords: ['sharp wave-ripples', 'hippocampus', 'replay', 'memory consolidation', 'planning'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1002/hipo.22488',
        citationCount: 1450,
      },
      {
        id: 'osc-4',
        title: 'Alpha-Beta Oscillations as Inhibitory Mechanisms in Cortical Processing',
        authors: ['Klimesch W', 'Sauseng P', 'Hanslmayr S'],
        year: 2007,
        abstract: 'Alpha and beta band oscillations (8-30 Hz) reflect top-down inhibitory control over cortical processing, with alpha associated with suppression and beta with maintenance of the status quo.',
        keywords: ['alpha oscillations', 'beta oscillations', 'inhibition', 'cortical processing', 'EEG'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1016/j.tics.2007.07.007',
        citationCount: 1680,
      },
      {
        id: 'osc-5',
        title: 'Theta Phase Precession in Hippocampal Neuronal Populations',
        authors: ['O\'Keefe J', 'Recce ML'],
        year: 1993,
        abstract: 'Hippocampal place cells spike at progressively earlier phases of the theta rhythm as the animal passes through the place field, a phenomenon called theta phase precession.',
        keywords: ['theta rhythm', 'phase precession', 'hippocampus', 'place cells', 'oscillations'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1002/neu.480240402',
        citationCount: 2200,
      },
      {
        id: 'osc-6',
        title: 'Neuronal Oscillations in Cortical Networks',
        authors: ['Buzsáki G', 'Draguhn A'],
        year: 2004,
        abstract: 'Oscillatory synchrony in neural networks provides a flexible mechanism for routing information, binding features, and coordinating activity across distributed brain circuits.',
        keywords: ['oscillations', 'synchrony', 'cortical networks', 'LFP', 'EEG'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1126/science.1099745',
        citationCount: 4100,
      },
      {
        id: 'osc-7',
        title: 'Oscillatory Dynamics of Prefrontal Cognitive Control',
        authors: ['Cavanagh JF', 'Frank MJ'],
        year: 2014,
        abstract: 'Theta band activity in frontal midline cortex signals cognitive control demands and conflict monitoring, providing a neural marker for adaptive decision-making processes.',
        keywords: ['theta oscillations', 'prefrontal cortex', 'cognitive control', 'conflict monitoring', 'EEG'],
        community: 'neural-oscillations',
        url: 'https://doi.org/10.1016/j.tics.2014.04.012',
        citationCount: 980,
      },
    ],
    // ==== COMPUTATIONAL MODELS (7) ====
    [
      {
        id: 'comp-1',
        title: 'A Computational Model of Prefrontal Cortex Function',
        authors: ['Cohen JD', 'Servan-Schreiber D', 'McClelland JL'],
        year: 1992,
        abstract: 'The prefrontal cortex implements active memory and context processing through sustained neural activity, modeled as a recurrent neural network with dopamine-modulated gain.',
        keywords: ['prefrontal cortex', 'working memory', 'computational model', 'dopamine', 'context'],
        community: 'computational',
        url: 'https://doi.org/10.1126/science.256.5056.905',
        citationCount: 2400,
      },
      {
        id: 'comp-2',
        title: 'Deep Learning: A Neuroscientific Perspective',
        authors: ['Yamins DLK', 'DiCarlo JJ'],
        year: 2016,
        abstract: 'Deep neural networks trained for object recognition develop internal representations that closely match those in primate ventral visual stream, suggesting convergent optimization principles.',
        keywords: ['deep learning', 'neural networks', 'object recognition', 'ventral stream', 'CNN'],
        community: 'computational',
        url: 'https://doi.org/10.1038/nn.4244',
        citationCount: 1850,
      },
      {
        id: 'comp-3',
        title: 'The Free-Energy Principle: A Unified Brain Theory?',
        authors: ['Friston K'],
        year: 2010,
        abstract: 'The free-energy principle posits that all adaptive brain processes minimize variational free energy, unifying perception, action, and learning under a single Bayesian framework.',
        keywords: ['free energy', 'Bayesian brain', 'predictive coding', 'active inference', 'variational inference'],
        community: 'computational',
        url: 'https://doi.org/10.1038/nn.2787',
        citationCount: 6200,
      },
      {
        id: 'comp-4',
        title: 'Reinforcement Learning: The Good, The Bad and The Ugly',
        authors: ['Dayan P', 'Niv Y'],
        year: 2008,
        abstract: 'Reinforcement learning theory provides a normative framework for understanding reward-based learning and decision making in biological and artificial agents.',
        keywords: ['reinforcement learning', 'TD learning', 'dopamine', 'striatum', 'reward'],
        community: 'computational',
        url: 'https://doi.org/10.1016/j.conb.2008.08.003',
        citationCount: 1350,
      },
      {
        id: 'comp-5',
        title: 'Probabilistic Models of Cognition: Conceptual Foundations',
        authors: ['Tenenbaum JB', 'Kemp C', 'Griffiths TL', 'Goodman ND'],
        year: 2011,
        abstract: 'Probabilistic models provide a framework for understanding human cognition as approximate Bayesian inference over structured representations.',
        keywords: ['Bayesian cognition', 'probabilistic models', 'concept learning', 'inductive inference'],
        community: 'computational',
        url: 'https://doi.org/10.1016/j.tics.2011.07.004',
        citationCount: 1650,
      },
      {
        id: 'comp-6',
        title: 'Neural Network Models of Hippocampal Function',
        authors: ['Rolls ET', 'Kesner RP'],
        year: 2006,
        abstract: 'Attractor network models of the hippocampus account for episodic memory, pattern completion, and pattern separation through sparse, distributed representations.',
        keywords: ['hippocampus', 'attractor networks', 'episodic memory', 'pattern completion', 'CA3'],
        community: 'computational',
        url: 'https://doi.org/10.1016/j.pneurobio.2006.05.005',
        citationCount: 880,
      },
      {
        id: 'comp-7',
        title: 'Reservoir Computing Approaches to Recurrent Neural Network Training',
        authors: ['Jaeger H', 'Haas H'],
        year: 2004,
        abstract: 'Echo state networks and liquid state machines enable efficient training of recurrent neural networks by fixing reservoir weights and training only readout connections.',
        keywords: ['reservoir computing', 'echo state networks', 'RNN', 'liquid state machine', 'recurrent networks'],
        community: 'computational',
        url: 'https://doi.org/10.1126/science.1091277',
        citationCount: 2100,
      },
    ],
    // ==== CLINICAL NEUROSCIENCE (8) ====
    [
      {
        id: 'clinical-1',
        title: "Neurodegeneration and Alzheimer's Disease: From Molecular Mechanisms to Therapies",
        authors: ['Hardy J', 'Selkoe DJ'],
        year: 2002,
        abstract: 'Alzheimer\'s disease involves amyloid-beta aggregation, tau pathology, synaptic dysfunction, and neuroinflammation. Disease-modifying therapies target these molecular mechanisms.',
        keywords: ['Alzheimer', 'amyloid', 'tau', 'neurodegeneration', 'dementia'],
        community: 'clinical',
        url: 'https://doi.org/10.1126/science.1073994',
        citationCount: 5100,
      },
      {
        id: 'clinical-2',
        title: 'Deep Brain Stimulation for Parkinson\'s Disease: Mechanisms and Clinical Outcomes',
        authors: ['DeLong MR', 'Wichmann T'],
        year: 2008,
        abstract: 'Deep brain stimulation of the subthalamic nucleus alleviates motor symptoms in Parkinson\'s disease through modulation of pathological basal ganglia oscillations.',
        keywords: ['deep brain stimulation', 'Parkinson', 'basal ganglia', 'subthalamic nucleus', 'movement disorder'],
        community: 'clinical',
        url: 'https://doi.org/10.1016/j.neuron.2008.03.029',
        citationCount: 1950,
      },
      {
        id: 'clinical-3',
        title: 'The Neurobiology of Depression: A Circuit Perspective',
        authors: ['Duman RS', 'Aghajanian GK'],
        year: 2012,
        abstract: 'Depression involves alterations in prefrontal-limbic circuits, reduced neuroplasticity, and impaired glutamatergic transmission. Novel rapid-acting antidepressants target these mechanisms.',
        keywords: ['depression', 'neuroplasticity', 'prefrontal cortex', 'ketamine', 'hippocampus'],
        community: 'clinical',
        url: 'https://doi.org/10.1126/science.1224939',
        citationCount: 2200,
      },
      {
        id: 'clinical-4',
        title: 'Autism Spectrum Disorders: Developmental Disconnection Syndromes',
        authors: ['Geschwind DH', 'Levitt P'],
        year: 2007,
        abstract: 'Autism involves atypical development of long-range connectivity between brain regions, with altered patterns of functional and structural connectivity evident early in development.',
        keywords: ['autism', 'connectivity', 'development', 'cortex', 'ASD'],
        community: 'clinical',
        url: 'https://doi.org/10.1016/j.conb.2007.03.009',
        citationCount: 1650,
      },
      {
        id: 'clinical-5',
        title: 'Stroke Recovery: Cellular and Molecular Mechanisms of Neural Repair',
        authors: ['Carmichael ST'],
        year: 2006,
        abstract: 'Recovery after stroke involves axonal sprouting, dendritic remodeling, neurogenesis, and formation of new functional connections in perilesional and contralesional cortex.',
        keywords: ['stroke', 'recovery', 'plasticity', 'neurogenesis', 'rehabilitation'],
        community: 'clinical',
        url: 'https://doi.org/10.1016/j.neuron.2006.10.040',
        citationCount: 1320,
      },
      {
        id: 'clinical-6',
        title: 'The Neurobiology of Addiction: A Neuroadaptational View',
        authors: ['Koob GF', 'Le Moal M'],
        year: 2001,
        abstract: 'Addiction involves neuroadaptations in reward and stress circuits that drive compulsive drug seeking. The transition from voluntary to compulsive use reflects allostatic changes in brain function.',
        keywords: ['addiction', 'reward', 'dopamine', 'stress', 'allostasis'],
        community: 'clinical',
        url: 'https://doi.org/10.1016/S0301-0082(00)00064-5',
        citationCount: 3800,
      },
      {
        id: 'clinical-7',
        title: 'Brain-Computer Interfaces for Communication and Control',
        authors: ['Wolpaw JR', 'Birbaumer N', 'McFarland DJ', 'Pfurtscheller G', 'Vaughan TM'],
        year: 2002,
        abstract: 'Brain-computer interfaces translate neural activity into commands for external devices, enabling communication and control for individuals with severe motor disabilities.',
        keywords: ['brain-computer interface', 'BCI', 'neuroprosthetics', 'EEG', 'communication'],
        community: 'clinical',
        url: 'https://doi.org/10.1126/science.1076903',
        citationCount: 3400,
      },
      {
        id: 'clinical-8',
        title: 'Neuroimaging Biomarkers for Neurodegenerative Diseases: From Research to Clinic',
        authors: ['Frisoni GB', 'Fox NC', 'Jack CR', 'Scheltens P', 'Thompson PM'],
        year: 2010,
        abstract: 'Structural and functional neuroimaging provides biomarkers for early detection, differential diagnosis, and tracking progression of neurodegenerative diseases.',
        keywords: ['neuroimaging', 'biomarkers', 'MRI', 'PET', 'neurodegeneration'],
        community: 'clinical',
        url: 'https://doi.org/10.1016/S1474-4422(10)70082-1',
        citationCount: 1200,
      },
    ],
  ];

  const allPapers: PaperNode[] = [];
  const communityKeys = Object.keys(COMMUNITIES);
  
  communityKeys.forEach((_key, communityIdx) => {
    const papers = paperData[communityIdx];
    const positions = distributePositions(papers.length, communityIdx, communityKeys.length);
    
    papers.forEach((paper, paperIdx) => {
      allPapers.push({
        ...paper,
        position: positions[paperIdx],
      });
    });
  });

  return allPapers;
}

function generateEdges(papers: PaperNode[]): CitationEdge[] {
  const edges: CitationEdge[] = [];
  
  for (let i = 0; i < papers.length; i++) {
    const source = papers[i];
    // Connect to 1-4 other papers based on shared community/keywords
    const targets = new Set<number>();
    
    // Prefer same community
    const sameCommunity = papers.filter((p, j) => j !== i && p.community === source.community);
    const otherCommunity = papers.filter((p, j) => j !== i && p.community !== source.community);
    
    // Add 1-2 same-community citations
    const sameCount = 1 + Math.floor(Math.random() * 2);
    for (let s = 0; s < sameCount && s < sameCommunity.length; s++) {
      const idx = papers.indexOf(sameCommunity[s]);
      if (idx !== -1) targets.add(idx);
    }
    
    // Add 0-2 cross-community citations (shared keywords)
    const crossCount = Math.floor(Math.random() * 3);
    for (let c = 0; c < crossCount && c < otherCommunity.length; c++) {
      const candidate = otherCommunity[c];
      const hasSharedKeyword = source.keywords.some((k) => candidate.keywords.includes(k));
      if (hasSharedKeyword) {
        const idx = papers.indexOf(candidate);
        if (idx !== -1) targets.add(idx);
      }
    }
    
    targets.forEach((targetIdx) => {
      if (source.citationCount > papers[targetIdx].citationCount) {
        edges.push({ source: source.id, target: papers[targetIdx].id });
      } else {
        edges.push({ source: papers[targetIdx].id, target: source.id });
      }
    });
  }
  
  return edges;
}

export const PAPERS: PaperNode[] = generatePapers();
export const EDGES: CitationEdge[] = generateEdges(PAPERS);
