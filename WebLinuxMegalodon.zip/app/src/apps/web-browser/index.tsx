import { useState, useRef, useCallback } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Star,
  Plus,
  X,
  Globe,
  Lock,
  Loader2,
  AlertTriangle,
} from 'lucide-react';

interface Tab {
  id: string;
  url: string;
  title: string;
  isLoading: boolean;
}

interface Bookmark {
  id: string;
  title: string;
  url: string;
}

const DEFAULT_BOOKMARKS: Bookmark[] = [
  { id: '1', title: 'Google', url: 'https://www.google.com' },
  { id: '2', title: 'GitHub', url: 'https://github.com' },
  { id: '3', title: 'Wikipedia', url: 'https://en.wikipedia.org' },
  { id: '4', title: 'React Docs', url: 'https://react.dev' },
];

const HOME_PAGE = `
<!DOCTYPE html>
<html>
<head>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  background: #0A0A0F;
  color: #E8E4DC;
  font-family: 'Inter', system-ui, sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 40px;
}
.logo {
  font-family: 'Cinzel', Georgia, serif;
  font-size: 48px;
  color: #C9A84C;
  margin-bottom: 8px;
  letter-spacing: 0.08em;
}
.tagline { color: #8A8578; font-size: 14px; margin-bottom: 40px; }
.search-box {
  width: 100%;
  max-width: 560px;
  padding: 14px 24px;
  border-radius: 8px;
  border: 1px solid #2A2A3E;
  background: #12121A;
  color: #E8E4DC;
  font-size: 16px;
  outline: none;
  transition: border-color 0.2s;
}
.search-box:focus { border-color: #C9A84C; }
.search-btn {
  margin-top: 16px;
  padding: 10px 32px;
  border-radius: 6px;
  border: none;
  background: #C9A84C;
  color: #030305;
  font-weight: 600;
  cursor: pointer;
  font-size: 14px;
}
.search-btn:hover { background: #D4B85A; }
.links { margin-top: 48px; display: flex; gap: 32px; flex-wrap: wrap; justify-content: center; }
.link {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #8A8578;
  text-decoration: none;
  font-size: 12px;
  transition: color 0.2s;
}
.link:hover { color: #C9A84C; }
.link-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: #12121A;
  border: 1px solid #2A2A3E;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
}
</style>
</head>
<body>
<div class="logo">Cornstone</div>
<div class="tagline">Search the web</div>
<form onsubmit="event.preventDefault(); const q=document.getElementById('q').value; if(q) location.href='https://duckduckgo.com/?q='+encodeURIComponent(q);">
<input id="q" class="search-box" placeholder="Search DuckDuckGo..." autofocus />
<button type="submit" class="search-btn">Search</button>
</form>
<div class="links">
  <a class="link" href="https://www.google.com"><div class="link-icon">🔍</div>Google</a>
  <a class="link" href="https://github.com"><div class="link-icon">⚡</div>GitHub</a>
  <a class="link" href="https://en.wikipedia.org"><div class="link-icon">📚</div>Wikipedia</a>
  <a class="link" href="https://react.dev"><div class="link-icon">⚛</div>React</a>
</div>
</body>
</html>
`;

export default function WebBrowser() {
  const [tabs, setTabs] = useState<Tab[]>([
    { id: 't1', url: 'home', title: 'New Tab', isLoading: false },
  ]);
  const [activeTabId, setActiveTabId] = useState('t1');
  const [urlInput, setUrlInput] = useState('');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    try {
      const saved = localStorage.getItem('cs-browser-bookmarks');
      return saved ? JSON.parse(saved) : DEFAULT_BOOKMARKS;
    } catch {
      return DEFAULT_BOOKMARKS;
    }
  });
  const [history, setHistory] = useState<Record<string, string[]>>({ t1: [] });
  const [historyIndex, setHistoryIndex] = useState<Record<string, number>>({});
  const [showBookmarkBar, setShowBookmarkBar] = useState(true);
  const [iframeError, setIframeError] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  const updateTab = useCallback(
    (id: string, updates: Partial<Tab>) => {
      setTabs((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
    },
    []
  );

  const navigateTo = useCallback(
    (tabId: string, url: string) => {
      if (!url || url === 'home') {
        updateTab(tabId, { url: 'home', title: 'New Tab', isLoading: false });
        setUrlInput('');
        setIframeError(false);
        return;
      }
      let fullUrl = url;
      if (!url.startsWith('http://') && !url.startsWith('https://') && url !== 'home') {
        fullUrl = 'https://' + url;
      }
      setIframeError(false);
      updateTab(tabId, { url: fullUrl, isLoading: true });
      setUrlInput(fullUrl);
      setHistory((prev) => {
        const hist = prev[tabId] || [];
        const idx = historyIndex[tabId] ?? -1;
        const newHist = hist.slice(0, idx + 1);
        newHist.push(fullUrl);
        return { ...prev, [tabId]: newHist };
      });
      setHistoryIndex((prev) => {
        const idx = prev[tabId] ?? -1;
        return { ...prev, [tabId]: idx + 1 };
      });
    },
    [updateTab, historyIndex]
  );

  const addTab = useCallback(() => {
    const id = 't' + Date.now();
    setTabs((prev) => [...prev, { id, url: 'home', title: 'New Tab', isLoading: false }]);
    setActiveTabId(id);
    setUrlInput('');
    setHistory((prev) => ({ ...prev, [id]: [] }));
    setHistoryIndex((prev) => ({ ...prev, [id]: -1 }));
  }, []);

  const closeTab = useCallback(
    (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      setTabs((prev) => {
        if (prev.length <= 1) return prev;
        const filtered = prev.filter((t) => t.id !== id);
        if (activeTabId === id) {
          setActiveTabId(filtered[filtered.length - 1].id);
        }
        return filtered;
      });
    },
    [activeTabId]
  );

  const goBack = useCallback(() => {
    const idx = historyIndex[activeTabId] ?? 0;
    if (idx > 0) {
      const newIdx = idx - 1;
      const hist = history[activeTabId] || [];
      const url = hist[newIdx];
      setHistoryIndex((prev) => ({ ...prev, [activeTabId]: newIdx }));
      updateTab(activeTabId, { url, isLoading: true });
      setUrlInput(url || '');
      setIframeError(false);
    }
  }, [activeTabId, history, historyIndex, updateTab]);

  const goForward = useCallback(() => {
    const idx = historyIndex[activeTabId] ?? 0;
    const hist = history[activeTabId] || [];
    if (idx < hist.length - 1) {
      const newIdx = idx + 1;
      const url = hist[newIdx];
      setHistoryIndex((prev) => ({ ...prev, [activeTabId]: newIdx }));
      updateTab(activeTabId, { url, isLoading: true });
      setUrlInput(url || '');
      setIframeError(false);
    }
  }, [activeTabId, history, historyIndex, updateTab]);

  const refresh = useCallback(() => {
    if (activeTab.url && activeTab.url !== 'home') {
      updateTab(activeTabId, { isLoading: true });
      setIframeError(false);
      if (iframeRef.current) {
        try {
          iframeRef.current.src = activeTab.url;
        } catch {
          setIframeError(true);
          updateTab(activeTabId, { isLoading: false });
        }
      }
    }
  }, [activeTab, activeTabId, updateTab]);

  const goHome = useCallback(() => {
    navigateTo(activeTabId, 'home');
  }, [activeTabId, navigateTo]);

  const toggleBookmark = useCallback(() => {
    const url = activeTab.url;
    if (!url || url === 'home') return;
    const exists = bookmarks.find((b) => b.url === url);
    let newBookmarks: Bookmark[];
    if (exists) {
      newBookmarks = bookmarks.filter((b) => b.url !== url);
    } else {
      newBookmarks = [...bookmarks, { id: Date.now().toString(), title: activeTab.title || url, url }];
    }
    setBookmarks(newBookmarks);
    localStorage.setItem('cs-browser-bookmarks', JSON.stringify(newBookmarks));
  }, [activeTab, bookmarks]);

  const isBookmarked = bookmarks.some((b) => b.url === activeTab.url && activeTab.url !== 'home');
  const canGoBack = (historyIndex[activeTabId] ?? 0) > 0;
  const canGoForward =
    (historyIndex[activeTabId] ?? 0) < (history[activeTabId]?.length ?? 0) - 1;

  return (
    <div className="w-full h-full flex flex-col" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Toolbar */}
      <div className="flex items-center gap-1.5 px-2 py-1.5" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <button onClick={goBack} disabled={!canGoBack} className="p-1.5 rounded hover:bg-[#222235] disabled:opacity-30 transition-colors">
          <ArrowLeft size={16} />
        </button>
        <button onClick={goForward} disabled={!canGoForward} className="p-1.5 rounded hover:bg-[#222235] disabled:opacity-30 transition-colors">
          <ArrowRight size={16} />
        </button>
        <button onClick={refresh} className="p-1.5 rounded hover:bg-[#222235] transition-colors">
          <RotateCw size={16} />
        </button>
        <button onClick={goHome} className="p-1.5 rounded hover:bg-[#222235] transition-colors">
          <Home size={16} />
        </button>

        {/* Address bar */}
        <div className="flex-1 flex items-center gap-1.5 mx-1.5 px-3 py-1 rounded-md" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
          {activeTab.url === 'home' ? (
            <Globe size={13} className="opacity-50 shrink-0" />
          ) : (
            <Lock size={13} style={{ color: 'var(--success)' }} className="shrink-0" />
          )}
          <form
            className="flex-1"
            onSubmit={(e) => {
              e.preventDefault();
              navigateTo(activeTabId, urlInput);
            }}
          >
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onFocus={() => {
                if (activeTab.url === 'home') setUrlInput('');
              }}
              placeholder="Search or enter address"
              className="w-full bg-transparent text-xs outline-none font-mono"
              style={{ color: 'var(--text-primary)' }}
            />
          </form>
          {activeTab.isLoading && <Loader2 size={14} className="animate-spin shrink-0" style={{ color: 'var(--accent-gold)' }} />}
          <button onClick={toggleBookmark} className="shrink-0 transition-transform active:scale-90">
            <Star size={14} fill={isBookmarked ? 'var(--accent-gold)' : 'none'} style={{ color: isBookmarked ? 'var(--accent-gold)' : 'var(--text-muted)' }} />
          </button>
        </div>

        <button onClick={() => setShowBookmarkBar((v) => !v)} className="p-1.5 rounded hover:bg-[#222235] transition-colors text-xs" style={{ color: 'var(--text-muted)' }}>
          ⋮
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-0.5 px-2 overflow-x-auto" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setActiveTabId(tab.id);
              setUrlInput(tab.url === 'home' ? '' : tab.url);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-t-md min-w-[100px] max-w-[180px] transition-colors relative"
            style={{
              background: tab.id === activeTabId ? 'var(--abyss)' : 'transparent',
              color: tab.id === activeTabId ? 'var(--text-primary)' : 'var(--text-muted)',
              borderBottom: tab.id === activeTabId ? '2px solid var(--accent-gold)' : '2px solid transparent',
            }}
          >
            <Globe size={12} />
            <span className="truncate flex-1 text-left">{tab.title}</span>
            {tabs.length > 1 && (
              <span
                onClick={(e) => closeTab(tab.id, e)}
                className="p-0.5 rounded hover:bg-[#222235] opacity-50 hover:opacity-100"
              >
                <X size={12} />
              </span>
            )}
          </button>
        ))}
        <button onClick={addTab} className="p-1.5 rounded hover:bg-[#222235] transition-colors" style={{ color: 'var(--text-muted)' }}>
          <Plus size={14} />
        </button>
      </div>

      {/* Bookmark bar */}
      {showBookmarkBar && bookmarks.length > 0 && (
        <div className="flex items-center gap-3 px-3 py-1 text-xs overflow-x-auto" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
          {bookmarks.map((bm) => (
            <button
              key={bm.id}
              onClick={() => navigateTo(activeTabId, bm.url)}
              className="flex items-center gap-1.5 hover:underline transition-colors"
              style={{ color: 'var(--text-secondary)' }}
            >
              <Star size={10} style={{ color: 'var(--accent-gold)' }} />
              {bm.title}
            </button>
          ))}
        </div>
      )}

      {/* Content area */}
      <div className="flex-1 relative overflow-hidden" style={{ background: 'var(--abyss)' }}>
        {activeTab.url === 'home' || !activeTab.url ? (
          <iframe
            ref={iframeRef}
            srcDoc={HOME_PAGE}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-forms allow-popups"
            title="Browser Home"
          />
        ) : iframeError ? (
          <div className="w-full h-full flex flex-col items-center justify-center gap-4 p-8">
            <AlertTriangle size={48} style={{ color: 'var(--amber)' }} className="opacity-60" />
            <h3 className="text-lg font-semibold">This site cannot be displayed</h3>
            <p className="text-sm text-center max-w-md" style={{ color: 'var(--text-secondary)' }}>
              The website <code className="px-1 py-0.5 rounded" style={{ background: 'var(--surface)' }}>{activeTab.url}</code> blocked embedding in iframes.
            </p>
            <a
              href={activeTab.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-md text-sm font-medium transition-colors"
              style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
            >
              Open in New Tab
            </a>
          </div>
        ) : (
          <iframe
            ref={iframeRef}
            src={activeTab.url}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            title="Browser Content"
            onLoad={() => {
              updateTab(activeTabId, { isLoading: false });
              setIframeError(false);
            }}
            onError={() => {
              updateTab(activeTabId, { isLoading: false });
              setIframeError(true);
            }}
          />
        )}
      </div>
    </div>
  );
}
