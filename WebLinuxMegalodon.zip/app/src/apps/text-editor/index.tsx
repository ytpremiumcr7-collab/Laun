import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import {
  FileText, Plus, X, Save, FolderOpen,
  Search, WrapText
} from 'lucide-react';
import { useFileSystem } from '@/stores/useFileSystem';

interface Tab {
  id: string;
  name: string;
  content: string;
  language: string;
  isDirty: boolean;
  fileNodeId?: string;
}

const LANGUAGE_MAP: Record<string, string> = {
  js: 'javascript', jsx: 'javascript', ts: 'typescript', tsx: 'typescript',
  py: 'python', html: 'html', htm: 'html', css: 'css', json: 'json',
  md: 'markdown', txt: 'text', svg: 'xml', xml: 'xml', sql: 'sql',
  sh: 'bash', bash: 'bash', yml: 'yaml', yaml: 'yaml',
};

function detectLanguage(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  return LANGUAGE_MAP[ext] || 'text';
}

// Basic regex-based syntax highlighting
function highlightCode(code: string, language: string): string {
  if (language === 'text' || language === 'markdown') {
    return escapeHtml(code);
  }

  let result = escapeHtml(code);

  // Comments
  if (['javascript', 'typescript', 'java', 'c', 'cpp', 'rust', 'go'].includes(language)) {
    result = result.replace(/(\/\/.*$)/gm, '<span style="color:#4D4A42">$1</span>');
    result = result.replace(/(\/\*[\s\S]*?\*\/)/g, '<span style="color:#4D4A42">$1</span>');
  }
  if (language === 'python') {
    result = result.replace(/(#.*$)/gm, '<span style="color:#4D4A42">$1</span>');
    result = result.replace(/("""[\s\S]*?""")/g, '<span style="color:#4D4A42">$1</span>');
  }
  if (['html', 'xml', 'svg'].includes(language)) {
    result = result.replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span style="color:#4D4A42">$1</span>');
  }
  if (language === 'css') {
    result = result.replace(/(\/\*[\s\S]*?\*\/)/g, '<span style="color:#4D4A42">$1</span>');
  }

  // Strings
  result = result.replace(/("(?:[^"\\]|\\.)*")/g, '<span style="color:#5A9E6F">$1</span>');
  result = result.replace(/('(?:[^'\\]|\\.)*')/g, '<span style="color:#5A9E6F">$1</span>');
  result = result.replace(/(`(?:[^`\\]|\\.)*`)/g, '<span style="color:#5A9E6F">$1</span>');

  // Numbers
  result = result.replace(/\b(\d+\.?\d*)\b/g, '<span style="color:#4A9E9E">$1</span>');

  // Keywords (language-specific)
  const keywords: Record<string, string> = {
    javascript: 'const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|class|extends|import|export|from|default|async|await|try|catch|throw|typeof|instanceof|void|delete|in|of|yield|debugger|with',
    typescript: 'const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|this|class|extends|import|export|from|default|async|await|try|catch|throw|typeof|instanceof|void|delete|in|of|yield|debugger|with|interface|type|enum|implements|declare|namespace|module|abstract|readonly|public|private|protected|static|as|satisfies',
    python: 'def|class|return|if|elif|else|for|while|in|not|and|or|try|except|finally|raise|import|from|as|with|pass|break|continue|lambda|yield|assert|del|global|nonlocal|True|False|None|is',
    html: '!DOCTYPE|html|head|body|div|span|p|a|img|script|style|link|meta|title|h1|h2|h3|h4|h5|h6|ul|ol|li|table|tr|td|th|form|input|button|select|option|textarea|label|nav|header|footer|main|section|article|aside|figure|figcaption|canvas|video|audio|source|iframe|embed|object|param',
    css: '@media|@import|@keyframes|@font-face|display|position|width|height|margin|padding|border|background|color|font|text|flex|grid|align|justify|content|overflow|float|clear|opacity|transform|transition|animation|z-index|top|left|right|bottom|min|max|cursor|pointer|visible|hidden|none|block|inline|absolute|relative|fixed|sticky',
    json: 'true|false|null',
  };

  const kw = keywords[language];
  if (kw) {
    const kwRegex = new RegExp(`\\b(${kw})\\b`, 'g');
    result = result.replace(kwRegex, '<span style="color:#7B6FB8">$1</span>');
  }

  // Functions (word followed by opening paren)
  if (['javascript', 'typescript', 'python'].includes(language)) {
    result = result.replace(/(\w+)(\()/g, '<span style="color:#C9A84C">$1</span>$2');
  }

  // HTML tags
  if (['html', 'xml', 'svg'].includes(language)) {
    result = result.replace(/(&lt;\/?)([\w-]+)/g, '$1<span style="color:#5A8AB8">$2</span>');
    result = result.replace(/(\s)([\w-]+)(=)/g, '$1<span style="color:#D4953A">$2</span>$3');
  }

  // CSS properties and values
  if (language === 'css') {
    result = result.replace(/([\w-]+)(\s*:)/g, '<span style="color:#D4953A">$1</span>$2');
    result = result.replace(/(:\s*)([^;{}]+)/g, '$1<span style="color:#5A9E6F">$2</span>');
  }

  return result;
}

function escapeHtml(text: string): string {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

let tabCounter = 1;

export default function TextEditor() {
  const { nodes, addNode, renameNode } = useFileSystem();
  const [tabs, setTabs] = useState<Tab[]>([
    { id: 'tab-1', name: 'untitled.txt', content: '', language: 'text', isDirty: false }
  ]);
  const [activeTabId, setActiveTabId] = useState('tab-1');
  const [wordWrap, setWordWrap] = useState(true);
  const [searchVisible, setSearchVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchReplace, setSearchReplace] = useState('');
  const [lineCount, setLineCount] = useState(1);
  const [charCount, setCharCount] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  const activeTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  const lines = useMemo(() => activeTab.content.split('\n'), [activeTab.content]);

  useEffect(() => {
    setLineCount(Math.max(1, lines.length));
    setCharCount(activeTab.content.length);
  }, [lines.length, activeTab.content]);

  const updateActiveTab = useCallback((updates: Partial<Tab>) => {
    setTabs(prev => prev.map(t => t.id === activeTabId ? { ...t, ...updates } : t));
  }, [activeTabId]);

  const handleNew = useCallback(() => {
    tabCounter++;
    const newTab: Tab = { id: `tab-${tabCounter}`, name: `untitled-${tabCounter}.txt`, content: '', language: 'text', isDirty: false };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
  }, []);

  const handleOpen = useCallback(() => {
    const fileNodes = nodes.filter(n => n.type === 'file');
    if (fileNodes.length === 0) return;
    const file = fileNodes[0];
    const lang = detectLanguage(file.name);
    tabCounter++;
    const newTab: Tab = {
      id: `tab-${tabCounter}`,
      name: file.name,
      content: file.content || '',
      language: lang,
      isDirty: false,
      fileNodeId: file.id,
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTab.id);
  }, [nodes]);

  const handleSave = useCallback(() => {
    if (activeTab.fileNodeId) {
      renameNode(activeTab.fileNodeId, activeTab.name);
    }
    updateActiveTab({ isDirty: false });
  }, [activeTab, updateActiveTab, renameNode]);

  const handleSaveAs = useCallback(() => {
    const id = addNode({
      name: activeTab.name,
      type: 'file',
      parentId: null,
      content: activeTab.content,
      size: activeTab.content.length,
    });
    updateActiveTab({ fileNodeId: id, isDirty: false });
  }, [activeTab, addNode, updateActiveTab]);

  const handleCloseTab = useCallback((tabId: string) => {
    setTabs(prev => {
      const filtered = prev.filter(t => t.id !== tabId);
      if (filtered.length === 0) {
        tabCounter++;
        return [{ id: `tab-${tabCounter}`, name: 'untitled.txt', content: '', language: 'text', isDirty: false }];
      }
      return filtered;
    });
    if (activeTabId === tabId) {
      setActiveTabId(prev => {
        const idx = tabs.findIndex(t => t.id === prev);
        const remaining = tabs.filter(t => t.id !== tabId);
        return remaining[Math.max(0, Math.min(idx, remaining.length - 1))]?.id || '';
      });
    }
  }, [activeTabId, tabs]);

  const handleContentChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    updateActiveTab({ content: e.target.value, isDirty: true });
  }, [updateActiveTab]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      handleSave();
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
      e.preventDefault();
      setSearchVisible(v => !v);
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
      e.preventDefault();
      handleNew();
    }
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = textareaRef.current;
      if (!ta) return;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const newContent = activeTab.content.substring(0, start) + '  ' + activeTab.content.substring(end);
      updateActiveTab({ content: newContent, isDirty: true });
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 2;
      });
    }
  }, [handleSave, handleNew, activeTab.content, updateActiveTab]);

  // Sync scroll between textarea and line numbers
  const handleScroll = useCallback(() => {
    if (textareaRef.current && lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  }, []);

  const highlighted = useMemo(() => highlightCode(activeTab.content, activeTab.language), [activeTab.content, activeTab.language]);

  const handleFind = useCallback(() => {
    if (!searchQuery || !textareaRef.current) return;
    const content = activeTab.content;
    const idx = content.indexOf(searchQuery, textareaRef.current.selectionStart + 1);
    if (idx !== -1) {
      textareaRef.current.setSelectionRange(idx, idx + searchQuery.length);
      textareaRef.current.focus();
    }
  }, [searchQuery, activeTab.content]);

  const handleReplace = useCallback(() => {
    if (!searchQuery || !textareaRef.current) return;
    const ta = textareaRef.current;
    const content = activeTab.content;
    const idx = content.indexOf(searchQuery, ta.selectionStart);
    if (idx !== -1) {
      const newContent = content.substring(0, idx) + searchReplace + content.substring(idx + searchQuery.length);
      updateActiveTab({ content: newContent, isDirty: true });
      requestAnimationFrame(() => {
        ta.setSelectionRange(idx, idx + searchReplace.length);
        ta.focus();
      });
    }
  }, [searchQuery, searchReplace, activeTab.content, updateActiveTab]);

  const handleReplaceAll = useCallback(() => {
    if (!searchQuery) return;
    const newContent = activeTab.content.split(searchQuery).join(searchReplace);
    updateActiveTab({ content: newContent, isDirty: true });
  }, [searchQuery, searchReplace, activeTab.content, updateActiveTab]);

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col overflow-hidden">
      {/* Menu bar */}
      <div className="flex items-center gap-1 px-2 py-1 bg-[#0A0A0F] border-b border-[#2A2A3E] text-xs shrink-0">
        <button onClick={handleNew} className="flex items-center gap-1 px-2 py-1 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
          <Plus className="w-3 h-3" /> New
        </button>
        <button onClick={handleOpen} className="flex items-center gap-1 px-2 py-1 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
          <FolderOpen className="w-3 h-3" /> Open
        </button>
        <button onClick={handleSave} className="flex items-center gap-1 px-2 py-1 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
          <Save className="w-3 h-3" /> Save
        </button>
        <button onClick={handleSaveAs} className="flex items-center gap-1 px-2 py-1 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
          Save As
        </button>
        <div className="w-px h-4 bg-[#2A2A3E] mx-1" />
        <button onClick={() => setSearchVisible(v => !v)} className="flex items-center gap-1 px-2 py-1 rounded hover:bg-[#222235] text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
          <Search className="w-3 h-3" /> Find
        </button>
        <button onClick={() => setWordWrap(v => !v)} className={`flex items-center gap-1 px-2 py-1 rounded transition-colors ${wordWrap ? 'text-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'} hover:bg-[#222235]`}>
          <WrapText className="w-3 h-3" /> Wrap
        </button>
      </div>

      {/* Search bar */}
      {searchVisible && (
        <div className="flex items-center gap-2 px-3 py-2 bg-[#0A0A0F] border-b border-[#2A2A3E] text-xs shrink-0">
          <input
            type="text"
            placeholder="Find..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleFind()}
            className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C] font-mono w-40"
            autoFocus
          />
          <input
            type="text"
            placeholder="Replace..."
            value={searchReplace}
            onChange={e => setSearchReplace(e.target.value)}
            className="bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs text-[#E8E4DC] outline-none focus:border-[#C9A84C] font-mono w-40"
          />
          <button onClick={handleFind} className="px-2 py-1 bg-[#222235] hover:bg-[#2A2A3E] rounded text-[#C9A84C] transition-colors">Find</button>
          <button onClick={handleReplace} className="px-2 py-1 bg-[#222235] hover:bg-[#2A2A3E] rounded text-[#C9A84C] transition-colors">Replace</button>
          <button onClick={handleReplaceAll} className="px-2 py-1 bg-[#222235] hover:bg-[#2A2A3E] rounded text-[#C9A84C] transition-colors">Replace All</button>
          <button onClick={() => setSearchVisible(false)} className="ml-auto text-[#8A8578] hover:text-[#B84A4A]"><X className="w-3.5 h-3.5" /></button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-0 bg-[#0A0A0F] border-b border-[#2A2A3E] overflow-x-auto shrink-0">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTabId(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs transition-colors border-r border-[#2A2A3E] whitespace-nowrap ${
              activeTabId === tab.id
                ? 'bg-[#12121A] text-[#E8E4DC] border-b-2 border-b-[#C9A84C]'
                : 'text-[#8A8578] hover:text-[#E8E4DC] hover:bg-[#1A1A26]'
            }`}
          >
            <FileText className="w-3 h-3" />
            <span>{tab.name}{tab.isDirty ? ' •' : ''}</span>
            <span
              onClick={e => { e.stopPropagation(); handleCloseTab(tab.id); }}
              className="ml-1 p-0.5 rounded hover:bg-[#2A2A3E] text-[#4D4A42] hover:text-[#B84A4A]"
            >
              <X className="w-3 h-3" />
            </span>
          </button>
        ))}
        <button onClick={handleNew} className="p-1.5 text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Editor area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Line numbers */}
        <div
          ref={lineNumbersRef}
          className="w-12 bg-[#0A0A0F] border-r border-[#2A2A3E] text-right pr-2 py-3 text-[#4D4A42] font-mono text-xs leading-[1.6] overflow-hidden shrink-0 select-none"
        >
          {lines.map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>

        {/* Textarea with syntax highlighting overlay */}
        <div className="flex-1 relative overflow-auto">
          {/* Highlighted code background */}
          <div
            className="absolute inset-0 p-3 font-mono text-xs leading-[1.6] whitespace-pre pointer-events-none"
            style={{ fontFamily: 'JetBrains Mono, Fira Code, monospace' }}
            dangerouslySetInnerHTML={{ __html: highlighted + '<br/>' }}
          />
          <textarea
            ref={textareaRef}
            value={activeTab.content}
            onChange={handleContentChange}
            onKeyDown={handleKeyDown}
            onScroll={handleScroll}
            spellCheck={false}
            autoFocus
            className="absolute inset-0 w-full h-full p-3 bg-transparent text-[#E8E4DC] font-mono text-xs leading-[1.6] outline-none resize-none caret-[#C9A84C]"
            style={{
              fontFamily: 'JetBrains Mono, Fira Code, monospace',
              whiteSpace: wordWrap ? 'pre-wrap' : 'pre',
              overflowWrap: wordWrap ? 'break-word' : 'normal',
              color: 'transparent',
              zIndex: 1,
            }}
          />
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1 bg-[#0A0A0F] border-t border-[#2A2A3E] text-[10px] text-[#8A8578] shrink-0">
        <div className="flex items-center gap-3">
          <span>Ln {lineCount}, Col {activeTab.content.length > 0 ? (activeTab.content.lastIndexOf('\n') >= 0 ? activeTab.content.length - activeTab.content.lastIndexOf('\n') : activeTab.content.length) : 0}</span>
          <span>{charCount} chars</span>
        </div>
        <div className="flex items-center gap-3">
          <span>UTF-8</span>
          <span className="text-[#C9A84C] capitalize">{activeTab.language}</span>
          <span>{wordWrap ? 'Wrap' : 'No Wrap'}</span>
        </div>
      </div>
    </div>
  );
}
