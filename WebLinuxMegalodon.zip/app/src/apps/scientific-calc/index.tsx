import { FlaskConical } from 'lucide-react'

export default function ScientificCalc() {
  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col items-center justify-center p-6">
      <FlaskConical className="w-12 h-12 text-[#8A8578] mb-3 opacity-40" />
      <p className="text-sm text-[#8A8578]">Scientific Calc — Coming Soon</p>
    </div>
  )
}
