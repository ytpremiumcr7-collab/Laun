import { useState, useRef, useCallback } from 'react';
import { Dice5, Play, RotateCcw } from 'lucide-react';

interface Variable {
  id: string;
  name: string;
  distribution: 'normal' | 'uniform' | 'triangular';
  params: { mu?: number; sigma?: number; min?: number; max?: number; mode?: number };
}

interface SimulationResult {
  values: number[];
  mean: number;
  median: number;
  stdDev: number;
  min: number;
  max: number;
  p10: number;
  p90: number;
}

function percentile(sorted: number[], p: number): number {
  const idx = Math.floor((p / 100) * (sorted.length - 1));
  return sorted[Math.min(idx, sorted.length - 1)];
}

function randomNormal(mu: number, sigma: number): number {
  const u1 = Math.random();
  const u2 = Math.random();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return mu + z * sigma;
}

function randomUniform(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

function randomTriangular(min: number, max: number, mode: number): number {
  const u = Math.random();
  const f = (mode - min) / (max - min);
  if (u <= f) return min + Math.sqrt(u * f * (max - min) * (mode - min));
  return max - Math.sqrt((1 - u) * (1 - f) * (max - min) * (max - mode));
}

function sampleVariable(v: Variable): number {
  switch (v.distribution) {
    case 'normal':
      return randomNormal(v.params.mu ?? 0, v.params.sigma ?? 1);
    case 'uniform':
      return randomUniform(v.params.min ?? 0, v.params.max ?? 1);
    case 'triangular':
      return randomTriangular(v.params.min ?? 0, v.params.max ?? 1, v.params.mode ?? 0.5);
    default:
      return 0;
  }
}

function evaluateFormula(formula: string, values: Record<string, number>): number {
  let expr = formula;
  for (const [key, val] of Object.entries(values)) {
    expr = expr.replace(new RegExp(`\\b${key}\\b`, 'g'), val.toString());
  }
  try {
    return Function(`"use strict"; return (${expr})`)();
  } catch {
    return 0;
  }
}

function computeHistogram(data: number[], bins: number): { x: number; count: number }[] {
  if (data.length === 0) return [];
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const bucketSize = range / bins;
  const buckets = Array.from({ length: bins }, (_, i) => ({
    x: min + i * bucketSize + bucketSize / 2,
    count: 0,
  }));
  for (const val of data) {
    const idx = Math.min(Math.floor((val - min) / bucketSize), bins - 1);
    buckets[idx].count++;
  }
  return buckets;
}

const DEFAULT_VARIABLES: Variable[] = [
  { id: 'cost', name: 'cost', distribution: 'normal', params: { mu: 1000000, sigma: 150000 } },
  { id: 'material', name: 'material_factor', distribution: 'uniform', params: { min: 0.9, max: 1.2 } },
  { id: 'labor', name: 'labor_factor', distribution: 'triangular', params: { min: 0.85, max: 1.15, mode: 1.0 } },
];

export default function MonteCarlo() {
  const [variables, setVariables] = useState<Variable[]>(DEFAULT_VARIABLES);
  const [formula, setFormula] = useState('cost * material_factor * labor_factor');
  const [iterations, setIterations] = useState(5000);
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [histogramData, setHistogramData] = useState<{ x: number; count: number }[]>([]);
  const [tornadoData, setTornadoData] = useState<{ name: string; impact: number }[]>([]);
  const abortRef = useRef(false);

  const runSimulation = useCallback(async () => {
    setRunning(true);
    setResult(null);
    setProgress(0);
    setHistogramData([]);
    setTornadoData([]);
    abortRef.current = false;

    const values: number[] = [];
    const batchSize = 100;
    const numBatches = Math.ceil(iterations / batchSize);

    for (let b = 0; b < numBatches; b++) {
      if (abortRef.current) break;
      for (let i = 0; i < batchSize && b * batchSize + i < iterations; i++) {
        const sample: Record<string, number> = {};
        for (const v of variables) {
          sample[v.name] = sampleVariable(v);
        }
        values.push(evaluateFormula(formula, sample));
      }
      setProgress(Math.round(((b + 1) / numBatches) * 100));
      if (b % 10 === 0) await new Promise((r) => setTimeout(r, 0));
    }

    if (!abortRef.current && values.length > 0) {
      const sorted = [...values].sort((a, b) => a - b);
      const sum = sorted.reduce((a, b) => a + b, 0);
      const mean = sum / sorted.length;
      const median = sorted.length % 2 === 0
        ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
        : sorted[Math.floor(sorted.length / 2)];
      const variance = sorted.reduce((a, v) => a + (v - mean) ** 2, 0) / sorted.length;
      const stdDev = Math.sqrt(variance);

      setResult({
        values: sorted,
        mean,
        median,
        stdDev,
        min: sorted[0],
        max: sorted[sorted.length - 1],
        p10: percentile(sorted, 10),
        p90: percentile(sorted, 90),
      });

      setHistogramData(computeHistogram(sorted, 30));

      // Tornado chart data: run one-at-a-time sensitivity
      const impacts = variables.map((v) => {
        let high = 0, low = 0;
        switch (v.distribution) {
          case 'normal':
            high = evaluateFormula(formula, { ...Object.fromEntries(variables.map((x) => [x.name, sampleVariable(x)])), [v.name]: (v.params.mu ?? 0) + (v.params.sigma ?? 1) });
            low = evaluateFormula(formula, { ...Object.fromEntries(variables.map((x) => [x.name, sampleVariable(x)])), [v.name]: (v.params.mu ?? 0) - (v.params.sigma ?? 1) });
            break;
          case 'uniform':
            high = evaluateFormula(formula, { ...Object.fromEntries(variables.map((x) => [x.name, sampleVariable(x)])), [v.name]: v.params.max ?? 1 });
            low = evaluateFormula(formula, { ...Object.fromEntries(variables.map((x) => [x.name, sampleVariable(x)])), [v.name]: v.params.min ?? 0 });
            break;
          case 'triangular':
            high = evaluateFormula(formula, { ...Object.fromEntries(variables.map((x) => [x.name, sampleVariable(x)])), [v.name]: v.params.max ?? 1 });
            low = evaluateFormula(formula, { ...Object.fromEntries(variables.map((x) => [x.name, sampleVariable(x)])), [v.name]: v.params.min ?? 0 });
            break;
        }
        return { name: v.name, impact: Math.abs(high - low) };
      });
      setTornadoData(impacts.sort((a, b) => b.impact - a.impact));
    }

    setRunning(false);
    setProgress(100);
  }, [variables, formula, iterations]);

  const cancelSimulation = () => {
    abortRef.current = true;
    setRunning(false);
  };

  const addVariable = () => {
    const id = Date.now().toString();
    setVariables((prev) => [...prev, { id, name: `var${prev.length + 1}`, distribution: 'uniform', params: { min: 0, max: 1 } }]);
  };

  const removeVariable = (id: string) => {
    setVariables((prev) => prev.filter((v) => v.id !== id));
  };

  const updateVariable = (id: string, updates: Partial<Variable>) => {
    setVariables((prev) => prev.map((v) => (v.id === id ? { ...v, ...updates } : v)));
  };

  const maxCount = Math.max(...histogramData.map((d) => d.count), 1);
  const maxTornadoImpact = Math.max(...tornadoData.map((d) => d.impact), 1);

  return (
    <div className="w-full h-full flex flex-col overflow-hidden" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      <div className="flex items-center justify-between px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Dice5 size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Monte Carlo Simulator</span>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            value={iterations}
            onChange={(e) => setIterations(Math.max(100, Math.min(100000, Number(e.target.value))))}
            className="w-20 px-2 py-1 rounded text-xs font-mono outline-none"
            style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
          />
          <button
            onClick={running ? cancelSimulation : runSimulation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
            style={{ background: running ? 'var(--danger)' : 'var(--accent-gold)', color: 'var(--void)' }}
          >
            {running ? <><RotateCcw size={12} /> Cancel</> : <><Play size={12} /> Run Simulation</>}
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left panel - variables */}
        <div className="w-64 flex flex-col gap-2 p-3 overflow-y-auto shrink-0" style={{ background: 'var(--surface)', borderRight: '1px solid var(--border-subtle)' }}>
          <div className="text-[11px] font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Variables</div>
          {variables.map((v) => (
            <div key={v.id} className="p-2 rounded-md" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)' }}>
              <div className="flex items-center justify-between mb-1">
                <input
                  value={v.name}
                  onChange={(e) => updateVariable(v.id, { name: e.target.value })}
                  className="bg-transparent text-xs font-mono outline-none w-20"
                  style={{ color: 'var(--accent-gold)' }}
                />
                <select
                  value={v.distribution}
                  onChange={(e) => updateVariable(v.id, { distribution: e.target.value as Variable['distribution'] })}
                  className="bg-transparent text-[10px] outline-none cursor-pointer"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  <option value="normal">Normal</option>
                  <option value="uniform">Uniform</option>
                  <option value="triangular">Triangular</option>
                </select>
                <button onClick={() => removeVariable(v.id)} className="text-[10px] hover:text-red-400" style={{ color: 'var(--text-muted)' }}>×</button>
              </div>
              {v.distribution === 'normal' && (
                <div className="flex gap-1">
                  <input type="number" value={v.params.mu ?? 0} onChange={(e) => updateVariable(v.id, { params: { ...v.params, mu: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="μ" />
                  <input type="number" value={v.params.sigma ?? 1} onChange={(e) => updateVariable(v.id, { params: { ...v.params, sigma: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="σ" />
                </div>
              )}
              {v.distribution === 'uniform' && (
                <div className="flex gap-1">
                  <input type="number" value={v.params.min ?? 0} onChange={(e) => updateVariable(v.id, { params: { ...v.params, min: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="min" />
                  <input type="number" value={v.params.max ?? 1} onChange={(e) => updateVariable(v.id, { params: { ...v.params, max: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="max" />
                </div>
              )}
              {v.distribution === 'triangular' && (
                <div className="flex gap-1">
                  <input type="number" value={v.params.min ?? 0} onChange={(e) => updateVariable(v.id, { params: { ...v.params, min: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="min" />
                  <input type="number" value={v.params.max ?? 1} onChange={(e) => updateVariable(v.id, { params: { ...v.params, max: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="max" />
                  <input type="number" value={v.params.mode ?? 0.5} onChange={(e) => updateVariable(v.id, { params: { ...v.params, mode: Number(e.target.value) } })} className="w-full px-1.5 py-0.5 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} placeholder="mode" />
                </div>
              )}
            </div>
          ))}
          <button onClick={addVariable} className="w-full py-1.5 rounded-md text-[11px] font-medium transition-colors hover:bg-[#222235]" style={{ border: '1px dashed var(--border-subtle)', color: 'var(--text-muted)' }}>
            + Add Variable
          </button>

          <div className="mt-2">
            <div className="text-[11px] font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Formula</div>
            <input
              value={formula}
              onChange={(e) => setFormula(e.target.value)}
              className="w-full px-2 py-1.5 rounded text-xs font-mono outline-none"
              style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }}
            />
          </div>
        </div>

        {/* Right panel - results */}
        <div className="flex-1 flex flex-col overflow-y-auto p-3 gap-3">
          {/* Progress */}
          {running && (
            <div>
              <div className="flex justify-between text-[10px] mb-1" style={{ color: 'var(--text-muted)' }}>
                <span>Running simulation...</span>
                <span>{progress}%</span>
              </div>
              <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--surface-elevated)' }}>
                <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: 'var(--accent-gold)' }} />
              </div>
            </div>
          )}

          {result && (
            <>
              {/* Statistics */}
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: 'Mean', value: result.mean.toLocaleString('en', { maximumFractionDigits: 0 }), color: 'var(--accent-gold)' },
                  { label: 'Median', value: result.median.toLocaleString('en', { maximumFractionDigits: 0 }), color: 'var(--info)' },
                  { label: 'Std Dev', value: result.stdDev.toLocaleString('en', { maximumFractionDigits: 0 }), color: 'var(--amber)' },
                  { label: 'P10-P90', value: `${result.p10.toLocaleString('en', { maximumFractionDigits: 0 })} - ${result.p90.toLocaleString('en', { maximumFractionDigits: 0 })}`, color: 'var(--success)' },
                  { label: 'Min', value: result.min.toLocaleString('en', { maximumFractionDigits: 0 }), color: 'var(--text-secondary)' },
                  { label: 'Max', value: result.max.toLocaleString('en', { maximumFractionDigits: 0 }), color: 'var(--text-secondary)' },
                  { label: 'Iterations', value: iterations.toLocaleString(), color: 'var(--text-secondary)' },
                  { label: 'P90/P10 Ratio', value: (result.p90 / result.p10).toFixed(2), color: 'var(--text-secondary)' },
                ].map((s) => (
                  <div key={s.label} className="flex flex-col px-3 py-2 rounded-md" style={{ background: 'var(--surface)' }}>
                    <span className="text-[9px]" style={{ color: 'var(--text-muted)' }}>{s.label}</span>
                    <span className="text-sm font-bold font-mono" style={{ color: s.color }}>{s.value}</span>
                  </div>
                ))}
              </div>

              {/* Histogram */}
              <div>
                <div className="text-[11px] font-medium mb-2" style={{ color: 'var(--text-muted)' }}>Distribution Histogram</div>
                <div className="flex items-end gap-[2px] h-32 px-2 py-2 rounded-md" style={{ background: 'var(--surface)' }}>
                  {histogramData.map((d, i) => (
                    <div
                      key={i}
                      className="flex-1 rounded-t-sm transition-all"
                      style={{
                        height: `${(d.count / maxCount) * 100}%`,
                        background: 'var(--accent-gold)',
                        opacity: 0.6 + (i / histogramData.length) * 0.4,
                      }}
                      title={`${d.x.toLocaleString('en', { maximumFractionDigits: 0 })}: ${d.count}`}
                    />
                  ))}
                </div>
                <div className="flex justify-between text-[8px] mt-1 px-2" style={{ color: 'var(--text-muted)' }}>
                  <span>{result.min.toLocaleString('en', { notation: 'compact' })}</span>
                  <span>{result.max.toLocaleString('en', { notation: 'compact' })}</span>
                </div>
              </div>

              {/* Tornado chart */}
              {tornadoData.length > 0 && (
                <div>
                  <div className="text-[11px] font-medium mb-2" style={{ color: 'var(--text-muted)' }}>Sensitivity Analysis (Tornado)</div>
                  <div className="flex flex-col gap-1.5 p-2 rounded-md" style={{ background: 'var(--surface)' }}>
                    {tornadoData.map((t) => (
                      <div key={t.name} className="flex items-center gap-2">
                        <span className="text-[10px] w-20 truncate text-right font-mono" style={{ color: 'var(--text-secondary)' }}>{t.name}</span>
                        <div className="flex-1 h-4 rounded-sm overflow-hidden" style={{ background: 'var(--abyss)' }}>
                          <div
                            className="h-full rounded-sm transition-all"
                            style={{
                              width: `${(t.impact / maxTornadoImpact) * 100}%`,
                              background: 'var(--accent-gold)',
                            }}
                          />
                        </div>
                        <span className="text-[10px] font-mono w-16 text-right" style={{ color: 'var(--text-muted)' }}>
                          {t.impact.toLocaleString('en', { notation: 'compact', maximumFractionDigits: 1 })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {!result && !running && (
            <div className="flex-1 flex flex-col items-center justify-center gap-3" style={{ color: 'var(--text-muted)' }}>
              <Dice5 size={40} className="opacity-30" />
              <span className="text-sm">Configure variables and click Run Simulation</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
