import { useState, useEffect, useRef } from 'react';
import { Layers, Play, RotateCcw, Clock } from 'lucide-react';

type Suit = '♠' | '♥' | '♦' | '♣';
type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

interface Card {
  id: string;
  suit: Suit;
  rank: Rank;
  faceUp: boolean;
  color: 'red' | 'black';
}

interface GameState {
  stock: Card[];
  waste: Card[];
  foundations: Card[][];
  tableau: Card[][];
  score: number;
  moves: number;
  drawCount: 1 | 3;
}

const SUITS: Suit[] = ['♠', '♥', '♦', '♣'];
const RANKS: Rank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const RANK_VALUES: Record<Rank, number> = { A: 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, J: 11, Q: 12, K: 13 };

function createDeck(): Card[] {
  const cards: Card[] = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      cards.push({
        id: `${rank}${suit}`,
        suit,
        rank,
        faceUp: false,
        color: suit === '♥' || suit === '♦' ? 'red' : 'black',
      });
    }
  }
  // Shuffle
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}

function deal(): GameState {
  const deck = createDeck();
  const tableau: Card[][] = [];
  let idx = 0;
  for (let col = 0; col < 7; col++) {
    tableau[col] = [];
    for (let row = 0; row <= col; row++) {
      tableau[col].push({ ...deck[idx], faceUp: row === col });
      idx++;
    }
  }
  return {
    stock: deck.slice(idx),
    waste: [],
    foundations: [[], [], [], []],
    tableau,
    score: 0,
    moves: 0,
    drawCount: 1,
  };
}

function canPlaceOnTableau(card: Card, target: Card | null): boolean {
  if (!target) return card.rank === 'K';
  return RANK_VALUES[card.rank] === RANK_VALUES[target.rank] - 1 && card.color !== target.color;
}

function canPlaceOnFoundation(card: Card, foundation: Card[]): boolean {
  if (foundation.length === 0) return card.rank === 'A';
  const top = foundation[foundation.length - 1];
  return card.suit === top.suit && RANK_VALUES[card.rank] === RANK_VALUES[top.rank] + 1;
}

function rankSymbol(rank: Rank): string {
  if (rank === '10') return '10';
  return rank;
}

export default function Solitaire() {
  const [game, setGame] = useState<GameState>(deal);
  const [gameState, setGameState] = useState<'playing' | 'menu' | 'won'>('menu');
  const [elapsed, setElapsed] = useState(0);
  const [selectedCard, setSelectedCard] = useState<{ source: string; index: number; cardIndex?: number } | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (gameState === 'playing') {
      timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [gameState]);

  const startGame = () => {
    setGame(deal());
    setGameState('playing');
    setElapsed(0);
  };

  const drawFromStock = () => {
    if (game.stock.length === 0) {
      if (game.waste.length === 0) return;
      setGame((g) => ({ ...g, stock: [...g.waste].reverse().map((c) => ({ ...c, faceUp: false })), waste: [], score: Math.max(0, g.score - 2) }));
      return;
    }
    setGame((g) => {
      const count = Math.min(g.drawCount, g.stock.length);
      const drawn = g.stock.slice(0, count).map((c) => ({ ...c, faceUp: true }));
      return { ...g, stock: g.stock.slice(count), waste: [...drawn, ...g.waste], moves: g.moves + 1 };
    });
  };

  const handleCardClick = (source: string, colIndex: number, cardIndex?: number) => {
    if (gameState !== 'playing') return;

    // Handle stock click
    if (source === 'stock') {
      drawFromStock();
      return;
    }

    // If clicking waste card
    if (source === 'waste' && game.waste.length > 0) {
      if (selectedCard?.source === 'waste') {
        setSelectedCard(null);
        return;
      }
      setSelectedCard({ source: 'waste', index: 0 });
      return;
    }

    // If clicking foundation
    if (source === 'foundation') {
      const foundation = game.foundations[colIndex];
      if (foundation.length === 0) return;
      if (selectedCard?.source === 'foundation' && selectedCard.index === colIndex) {
        setSelectedCard(null);
        return;
      }
      setSelectedCard({ source: 'foundation', index: colIndex });
      return;
    }

    // Tableau click
    if (source === 'tableau') {
      const col = game.tableau[colIndex];
      if (col.length === 0) {
        // Empty column - try to move selected here
        if (selectedCard) {
          attemptMove(selectedCard, 'tableau', colIndex);
          setSelectedCard(null);
        }
        return;
      }

      const clickedCard = cardIndex !== undefined ? col[cardIndex] : col[col.length - 1];
      if (!clickedCard.faceUp) {
        // Flip the top face-down card
        if (cardIndex === undefined || cardIndex === col.length - 1) {
          setGame((g) => {
            const newTableau = g.tableau.map((c, i) => {
              if (i !== colIndex) return c;
              const lastFaceDown = c.findIndex((card) => !card.faceUp);
              if (lastFaceDown === -1) return c;
              return c.map((card, idx) => idx === lastFaceDown ? { ...card, faceUp: true } : card);
            });
            return { ...g, tableau: newTableau, score: g.score + 5, moves: g.moves + 1 };
          });
        }
        return;
      }

      if (selectedCard) {
        // Try to move
        if (selectedCard.source === source && selectedCard.index === colIndex && selectedCard.cardIndex === cardIndex) {
          setSelectedCard(null);
          return;
        }
        attemptMove(selectedCard, 'tableau', colIndex, cardIndex);
        setSelectedCard(null);
      } else {
        setSelectedCard({ source, index: colIndex, cardIndex });
      }
    }
  };

  const attemptMove = (from: { source: string; index: number; cardIndex?: number }, toSource: string, toIndex: number, toCardIndex?: number) => {
    setGame((g) => {
      let card: Card | null = null;
      let movingStack: Card[] = [];
      const newGame = { ...g, tableau: g.tableau.map((c) => [...c]), foundations: g.foundations.map((f) => [...f]), waste: [...g.waste], stock: [...g.stock] };

      // Get card(s) from source
      if (from.source === 'waste' && newGame.waste.length > 0) {
        card = newGame.waste[0];
        movingStack = [card];
      } else if (from.source === 'foundation' && newGame.foundations[from.index].length > 0) {
        card = newGame.foundations[from.index][newGame.foundations[from.index].length - 1];
        movingStack = [card];
      } else if (from.source === 'tableau') {
        const col = newGame.tableau[from.index];
        const idx = from.cardIndex !== undefined ? from.cardIndex : col.length - 1;
        if (idx >= 0 && col[idx].faceUp) {
          movingStack = col.slice(idx);
          card = movingStack[0];
        }
      }

      if (!card || movingStack.length === 0) return g;

      // Try to place
      if (toSource === 'foundation' && movingStack.length === 1) {
        if (canPlaceOnFoundation(card, newGame.foundations[toIndex])) {
          // Remove from source
          if (from.source === 'waste') newGame.waste.shift();
          else if (from.source === 'foundation') newGame.foundations[from.index].pop();
          else if (from.source === 'tableau') {
            newGame.tableau[from.index] = newGame.tableau[from.index].slice(0, from.cardIndex || newGame.tableau[from.index].length - 1);
          }
          newGame.foundations[toIndex].push(card);
          newGame.score += from.source === 'waste' ? 10 : 10;
          newGame.moves++;
          return newGame;
        }
      }

      if (toSource === 'tableau') {
        const targetCol = newGame.tableau[toIndex];
        const targetCard = toCardIndex !== undefined ? targetCol[toCardIndex] : (targetCol.length > 0 ? targetCol[targetCol.length - 1] : null);
        if (canPlaceOnTableau(card, targetCard)) {
          // Remove from source
          if (from.source === 'waste') newGame.waste.shift();
          else if (from.source === 'foundation') newGame.foundations[from.index].pop();
          else if (from.source === 'tableau') {
            newGame.tableau[from.index] = newGame.tableau[from.index].slice(0, from.cardIndex !== undefined ? from.cardIndex : newGame.tableau[from.index].length - 1);
          }
          newGame.tableau[toIndex] = [...newGame.tableau[toIndex], ...movingStack];
          if (from.source === 'waste') newGame.score += 5;
          newGame.moves++;
          return newGame;
        }
      }

      return g;
    });
  };

  // Check win
  useEffect(() => {
    if (gameState === 'playing' && game.foundations.every((f) => f.length === 13)) {
      setGameState('won');
    }
  }, [game.foundations, gameState]);

  const isSelected = (source: string, index: number, cardIndex?: number) => {
    if (!selectedCard) return false;
    return selectedCard.source === source && selectedCard.index === index &&
      (cardIndex === undefined || selectedCard.cardIndex === cardIndex);
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div className="w-full h-full flex flex-col select-none overflow-hidden" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      <div className="flex items-center justify-between px-3 py-1.5 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Layers size={14} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-xs font-medium">Solitaire</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono" style={{ color: 'var(--accent-gold)' }}>Score: {game.score}</span>
          <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>Moves: {game.moves}</span>
          <span className="text-xs font-mono flex items-center gap-1" style={{ color: 'var(--text-muted)' }}><Clock size={10} />{formatTime(elapsed)}</span>
          <button onClick={startGame} className="p-1 rounded hover:bg-[#222235]"><RotateCcw size={12} /></button>
        </div>
      </div>

      {gameState === 'menu' && (
        <div className="flex-1 flex flex-col items-center justify-center gap-3">
          <Layers size={32} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-xl font-bold" style={{ fontFamily: 'Cinzel, Georgia, serif', color: 'var(--accent-gold)' }}>Solitaire</span>
          <button onClick={startGame} className="flex items-center gap-1.5 px-5 py-2 rounded-md text-xs font-medium" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
            <Play size={14} /> New Game
          </button>
        </div>
      )}

      {gameState === 'won' && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3" style={{ background: 'rgba(3,3,5,0.85)' }}>
          <span className="text-2xl font-bold" style={{ fontFamily: 'Cinzel, Georgia, serif', color: 'var(--accent-gold)' }}>You Win!</span>
          <span className="text-sm font-mono" style={{ color: 'var(--text-secondary)' }}>Score: {game.score} | Moves: {game.moves} | Time: {formatTime(elapsed)}</span>
          <button onClick={startGame} className="flex items-center gap-1.5 px-5 py-2 rounded-md text-xs font-medium" style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}>
            <RotateCcw size={14} /> Play Again
          </button>
        </div>
      )}

      {gameState === 'playing' && (
        <div className="flex-1 flex flex-col p-2 overflow-hidden">
          {/* Top row: Stock, Waste, Foundations */}
          <div className="flex items-start justify-between mb-2">
            <div className="flex gap-2">
              {/* Stock */}
              <button
                onClick={() => handleCardClick('stock', 0)}
                className="w-12 h-16 rounded-md flex items-center justify-center text-lg"
                style={{ background: game.stock.length > 0 ? 'var(--surface-elevated)' : 'var(--surface)', border: '1px solid var(--border-subtle)' }}
              >
                {game.stock.length > 0 ? '🂠' : <RotateCcw size={14} style={{ color: 'var(--text-muted)' }} />}
              </button>
              {/* Waste */}
              <button
                onClick={() => handleCardClick('waste', 0)}
                className="w-12 h-16 rounded-md flex items-center justify-center relative"
                style={{ border: isSelected('waste', 0) ? '2px solid var(--accent-gold)' : '1px solid var(--border-subtle)', background: 'var(--surface)' }}
              >
                {game.waste.length > 0 ? (
                  <CardDisplay card={game.waste[0]} />
                ) : null}
              </button>
            </div>

            {/* Foundations */}
            <div className="flex gap-1.5">
              {game.foundations.map((foundation, i) => (
                <button
                  key={i}
                  onClick={() => handleCardClick('foundation', i)}
                  className="w-12 h-16 rounded-md flex items-center justify-center relative"
                  style={{ border: isSelected('foundation', i) ? '2px solid var(--accent-gold)' : '1px solid var(--border-subtle)', background: 'var(--surface)' }}
                >
                  {foundation.length > 0 ? (
                    <CardDisplay card={foundation[foundation.length - 1]} />
                  ) : (
                    <span className="text-lg opacity-30">{SUITS[i]}</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Tableau */}
          <div className="flex-1 flex gap-1 overflow-y-auto">
            {game.tableau.map((col, colIdx) => (
              <div key={colIdx} className="flex-1 flex flex-col items-center">
                {col.length === 0 ? (
                  <button
                    onClick={() => handleCardClick('tableau', colIdx)}
                    className="w-12 h-16 rounded-md"
                    style={{ border: '1px dashed var(--border-subtle)', background: 'rgba(18,18,26,0.5)' }}
                  />
                ) : (
                  col.map((card, cardIdx) => (
                    <button
                      key={card.id}
                      onClick={() => handleCardClick('tableau', colIdx, cardIdx)}
                      className="w-12 rounded-sm flex items-center justify-center relative -mt-8 first:mt-0"
                      style={{
                        height: cardIdx === col.length - 1 ? '4rem' : '1.5rem',
                        border: isSelected('tableau', colIdx, cardIdx) ? '2px solid var(--accent-gold)' : '1px solid var(--border-subtle)',
                        background: card.faceUp ? '#E8E4DC' : 'var(--surface-elevated)',
                      }}
                    >
                      {card.faceUp ? (
                        <span className={`text-sm font-bold ${cardIdx === col.length - 1 ? '' : 'hidden'}`} style={{ color: card.color === 'red' ? '#B84A4A' : '#1A1A2E' }}>
                          {rankSymbol(card.rank)}{card.suit}
                        </span>
                      ) : (
                        <span className="text-[8px]" style={{ color: 'var(--accent-gold-dim)' }}>★</span>
                      )}
                    </button>
                  ))
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function CardDisplay({ card }: { card: Card }) {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center rounded-sm" style={{ background: '#E8E4DC' }}>
      <span className="text-[9px] self-start ml-0.5 leading-none font-bold" style={{ color: card.color === 'red' ? '#B84A4A' : '#1A1A2E' }}>
        {rankSymbol(card.rank)}
      </span>
      <span className="text-lg leading-none" style={{ color: card.color === 'red' ? '#B84A4A' : '#1A1A2E' }}>{card.suit}</span>
      <span className="text-[9px] self-end mr-0.5 leading-none font-bold rotate-180" style={{ color: card.color === 'red' ? '#B84A4A' : '#1A1A2E' }}>
        {rankSymbol(card.rank)}
      </span>
    </div>
  );
}
