import { useState } from 'react';
import { Building2, Plus, Trash2, Calculator, Download, HardHat } from 'lucide-react';

type ElementType = 'Wall' | 'Column' | 'Beam' | 'Slab' | 'Foundation' | 'Stair' | 'Window' | 'Door';
type Material = 'Concrete' | 'Steel' | 'Brick' | 'Wood' | 'Glass';

interface BuildingElement {
  id: string;
  type: ElementType;
  length: number;
  width: number;
  height: number;
  quantity: number;
  material: Material;
}

const MATERIAL_DENSITY: Record<Material, number> = {
  Concrete: 2400,
  Steel: 7850,
  Brick: 1900,
  Wood: 600,
  Glass: 2500,
};

const MATERIAL_COST: Record<Material, number> = {
  Concrete: 120,
  Steel: 800,
  Brick: 85,
  Wood: 200,
  Glass: 300,
};

const ELEMENT_TYPES: ElementType[] = ['Wall', 'Column', 'Beam', 'Slab', 'Foundation', 'Stair', 'Window', 'Door'];
const MATERIALS: Material[] = ['Concrete', 'Steel', 'Brick', 'Wood', 'Glass'];

function calcVolume(el: BuildingElement): number {
  return el.length * el.width * el.height * el.quantity;
}

function calcArea(el: BuildingElement): number {
  switch (el.type) {
    case 'Wall': return el.length * el.height * el.quantity;
    case 'Slab': return el.length * el.width * el.quantity;
    case 'Window':
    case 'Door': return el.length * el.height * el.quantity;
    default: return el.length * el.height * el.quantity;
  }
}

function calcWeight(el: BuildingElement): number {
  return calcVolume(el) * MATERIAL_DENSITY[el.material];
}

function calcCost(el: BuildingElement): number {
  return calcVolume(el) * MATERIAL_COST[el.material];
}

export default function BIMCalculator() {
  const [elements, setElements] = useState<BuildingElement[]>([
    { id: '1', type: 'Wall', length: 10, width: 0.2, height: 3, quantity: 4, material: 'Brick' },
    { id: '2', type: 'Column', length: 0.4, width: 0.4, height: 3, quantity: 8, material: 'Concrete' },
    { id: '3', type: 'Slab', length: 10, width: 8, height: 0.15, quantity: 1, material: 'Concrete' },
    { id: '4', type: 'Foundation', length: 10, width: 0.6, height: 0.5, quantity: 4, material: 'Concrete' },
    { id: '5', type: 'Window', length: 1.5, width: 0.1, height: 1.2, quantity: 6, material: 'Glass' },
    { id: '6', type: 'Door', length: 0.9, width: 0.05, height: 2.1, quantity: 3, material: 'Wood' },
  ]);

  const addElement = () => {
    const id = Date.now().toString();
    setElements((prev) => [...prev, { id, type: 'Wall', length: 1, width: 0.2, height: 1, quantity: 1, material: 'Concrete' }]);
  };

  const removeElement = (id: string) => {
    setElements((prev) => prev.filter((e) => e.id !== id));
  };

  const updateElement = (id: string, updates: Partial<BuildingElement>) => {
    setElements((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates } : e)));
  };

  const totalVolume = elements.reduce((sum, e) => sum + calcVolume(e), 0);
  const totalArea = elements.reduce((sum, e) => sum + calcArea(e), 0);
  const totalWeight = elements.reduce((sum, e) => sum + calcWeight(e), 0);
  const totalCost = elements.reduce((sum, e) => sum + calcCost(e), 0);

  const exportBOQ = () => {
    let csv = 'Type,Material,Length(m),Width(m),Height(m),Quantity,Volume(m³),Area(m²),Weight(kg),Cost($)\n';
    for (const el of elements) {
      csv += `${el.type},${el.material},${el.length},${el.width},${el.height},${el.quantity},${calcVolume(el).toFixed(3)},${calcArea(el).toFixed(2)},${calcWeight(el).toFixed(1)},${calcCost(el).toFixed(2)}\n`;
    }
    csv += `TOTAL,,,,,,${totalVolume.toFixed(3)},${totalArea.toFixed(2)},${totalWeight.toFixed(1)},${totalCost.toFixed(2)}\n`;
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bill-of-quantities.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      <div className="flex items-center justify-between px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Building2 size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">BIM Calculator</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={exportBOQ}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
            style={{ background: 'var(--surface-elevated)', color: 'var(--text-secondary)', border: '1px solid var(--border-subtle)' }}
          >
            <Download size={12} /> Export BOQ
          </button>
          <button
            onClick={addElement}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
            style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
          >
            <Plus size={12} /> Add Element
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {/* Summary */}
        <div className="grid grid-cols-4 gap-2 p-3">
          {[
            { label: 'Total Volume', value: `${totalVolume.toFixed(2)} m³`, icon: <Calculator size={14} />, color: 'var(--accent-gold)' },
            { label: 'Total Area', value: `${totalArea.toFixed(2)} m²`, icon: <Building2 size={14} />, color: 'var(--info)' },
            { label: 'Total Weight', value: `${(totalWeight / 1000).toFixed(2)} t`, icon: <HardHat size={14} />, color: 'var(--amber)' },
            { label: 'Total Cost', value: `$${totalCost.toLocaleString('en', { maximumFractionDigits: 0 })}`, icon: <Building2 size={14} />, color: 'var(--success)' },
          ].map((s) => (
            <div key={s.label} className="flex flex-col px-3 py-2 rounded-md" style={{ background: 'var(--surface)' }}>
              <div className="flex items-center gap-1.5 mb-1" style={{ color: 'var(--text-muted)' }}>
                {s.icon}
                <span className="text-[10px]">{s.label}</span>
              </div>
              <span className="text-lg font-bold font-mono" style={{ color: s.color }}>{s.value}</span>
            </div>
          ))}
        </div>

        {/* Elements table */}
        <div className="px-3 pb-3">
          <div className="rounded-lg overflow-hidden" style={{ border: '1px solid var(--border-subtle)' }}>
            {/* Header */}
            <div className="grid grid-cols-12 gap-1 px-3 py-2 text-[9px] font-medium uppercase tracking-wider" style={{ background: 'var(--surface)', color: 'var(--text-muted)' }}>
              <div className="col-span-2">Type</div>
              <div className="col-span-1">Material</div>
              <div className="col-span-1">Length</div>
              <div className="col-span-1">Width</div>
              <div className="col-span-1">Height</div>
              <div className="col-span-1">Qty</div>
              <div className="col-span-1">Vol m³</div>
              <div className="col-span-1">Area m²</div>
              <div className="col-span-1">Wt kg</div>
              <div className="col-span-1">Cost $</div>
              <div className="col-span-1" />
            </div>

            {elements.map((el) => (
              <div
                key={el.id}
                className="grid grid-cols-12 gap-1 px-3 py-1.5 text-[10px] items-center"
                style={{ borderTop: '1px solid var(--border-subtle)', background: 'var(--surface)' }}
              >
                <div className="col-span-2">
                  <select
                    value={el.type}
                    onChange={(e) => updateElement(el.id, { type: e.target.value as ElementType })}
                    className="w-full bg-transparent outline-none font-medium"
                    style={{ color: 'var(--text-primary)' }}
                  >
                    {ELEMENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div className="col-span-1">
                  <select
                    value={el.material}
                    onChange={(e) => updateElement(el.id, { material: e.target.value as Material })}
                    className="w-full bg-transparent outline-none"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    {MATERIALS.map((m) => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                {(['length', 'width', 'height', 'quantity'] as const).map((field) => (
                  <div key={field} className="col-span-1">
                    <input
                      type="number"
                      value={el[field]}
                      onChange={(e) => updateElement(el.id, { [field]: Number(e.target.value) })}
                      className="w-full bg-transparent font-mono outline-none"
                      style={{ color: 'var(--text-primary)' }}
                      step={field === 'quantity' ? 1 : 0.01}
                    />
                  </div>
                ))}
                <div className="col-span-1 font-mono" style={{ color: 'var(--accent-gold)' }}>{calcVolume(el).toFixed(2)}</div>
                <div className="col-span-1 font-mono" style={{ color: 'var(--info)' }}>{calcArea(el).toFixed(1)}</div>
                <div className="col-span-1 font-mono" style={{ color: 'var(--amber)' }}>{calcWeight(el).toFixed(0)}</div>
                <div className="col-span-1 font-mono" style={{ color: 'var(--success)' }}>${calcCost(el).toFixed(0)}</div>
                <div className="col-span-1 text-right">
                  <button onClick={() => removeElement(el.id)} className="p-1 rounded hover:bg-[#222235] transition-colors" style={{ color: 'var(--danger)' }}>
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}

            {elements.length === 0 && (
              <div className="px-3 py-6 text-center text-xs" style={{ color: 'var(--text-muted)' }}>
                No elements. Click &quot;Add Element&quot; to start building your project.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
