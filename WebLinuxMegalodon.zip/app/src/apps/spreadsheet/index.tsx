import { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import {
  Download,
  Plus,
  Trash2,
  Bold,
  Italic,
  Hash,
  Calculator,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface CellData {
  value: string;
  formula: string;
  bold?: boolean;
  italic?: boolean;
  color?: string;
  numberFormat?: 'number' | 'currency' | 'percent';
  _allCells?: Record<string, CellData>;
}

interface SpreadsheetState {
  cells: Record<string, CellData>;
  colCount: number;
  rowCount: number;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const COL_LABELS = Array.from({ length: 20 }, (_, i) => {
  let s = '';
  let n = i;
  do {
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  } while (n > 0);
  return s;
});

const STORAGE_KEY = 'cornstone-spreadsheet';

const COLOR_OPTIONS = [
  '#E8E4DC', '#B84A4A', '#5A9E6F', '#5A8AB8', '#C9A84C',
  '#7B6FB8', '#D4953A', '#4A9E9E', '#E8E4DC', '#8A8578',
];

/* ------------------------------------------------------------------ */
/*  Formula Engine                                                     */
/* ------------------------------------------------------------------ */
function colToIndex(col: string): number {
  let idx = 0;
  for (const ch of col.toUpperCase()) {
    idx = idx * 26 + (ch.charCodeAt(0) - 64);
  }
  return idx - 1;
}

function parseCellRef(ref: string): { col: number; row: number } | null {
  const m = ref.match(/^([A-Z]+)(\d+)$/i);
  if (!m) return null;
  return { col: colToIndex(m[1]), row: parseInt(m[2]) - 1 };
}

function parseRange(range: string): { col: number; row: number }[] | null {
  const m = range.match(/^([A-Z]+\d+):([A-Z]+\d+)$/i);
  if (!m) return null;
  const start = parseCellRef(m[1]);
  const end = parseCellRef(m[2]);
  if (!start || !end) return null;
  const cells: { col: number; row: number }[] = [];
  for (let r = Math.min(start.row, end.row); r <= Math.max(start.row, end.row); r++) {
    for (let c = Math.min(start.col, end.col); c <= Math.max(start.col, end.col); c++) {
      cells.push({ col: c, row: r });
    }
  }
  return cells;
}

function getCellValue(cells: Record<string, CellData>, ref: string): number {
  const data = cells[ref];
  if (!data) return 0;
  if (data.formula) {
    const evaluated = evaluateFormula(cells, data.formula);
    const n = parseFloat(evaluated);
    return isNaN(n) ? 0 : n;
  }
  const n = parseFloat(data.value);
  return isNaN(n) ? 0 : n;
}

function getCellRawValue(cells: Record<string, CellData>, ref: string): string {
  const data = cells[ref];
  if (!data) return '';
  if (data.formula) return evaluateFormula(cells, data.formula);
  return data.value;
}

function evaluateFormula(cells: Record<string, CellData>, formula: string): string {
  if (!formula.startsWith('=')) return formula;
  const expr = formula.slice(1).trim();

  // Function patterns
  const funcMatch = expr.match(/^(\w+)\s*\((.*)\)$/i);
  if (funcMatch) {
    const [, funcName, args] = funcMatch;
    const fn = funcName.toUpperCase();

    // Range reference
    const rangeCells = parseRange(args.trim());
    const singleRef = !rangeCells ? parseCellRef(args.trim()) : null;

    if (rangeCells) {
      const values = rangeCells.map((c) =>
        getCellValue(cells, `${COL_LABELS[c.col]}${c.row + 1}`)
      );
      switch (fn) {
        case 'SUM': return values.reduce((a, b) => a + b, 0).toString();
        case 'AVG':
        case 'AVERAGE':
          return values.length ? (values.reduce((a, b) => a + b, 0) / values.length).toString() : '0';
        case 'MIN': return values.length ? Math.min(...values).toString() : '0';
        case 'MAX': return values.length ? Math.max(...values).toString() : '0';
        case 'COUNT': return values.filter((v) => v !== 0).length.toString();
      }
    }

    if (singleRef) {
      const ref = `${COL_LABELS[singleRef.col]}${singleRef.row + 1}`;
      switch (fn) {
        case 'SUM': return getCellValue(cells, ref).toString();
        case 'AVG':
        case 'AVERAGE': return getCellValue(cells, ref).toString();
        case 'MIN': return getCellValue(cells, ref).toString();
        case 'MAX': return getCellValue(cells, ref).toString();
        case 'COUNT': return getCellValue(cells, ref) !== 0 ? '1' : '0';
        case 'ABS': return Math.abs(getCellValue(cells, ref)).toString();
        case 'ROUND': return Math.round(getCellValue(cells, ref)).toString();
        case 'SQRT': return Math.sqrt(getCellValue(cells, ref)).toString();
        case 'LEN': return getCellRawValue(cells, ref).length.toString();
        case 'UPPER': return getCellRawValue(cells, ref).toUpperCase();
        case 'LOWER': return getCellRawValue(cells, ref).toLowerCase();
        case 'TRIM': return getCellRawValue(cells, ref).trim();
      }
    }

    // IF function
    if (fn === 'IF') {
      const parts = splitArgs(args);
      if (parts.length >= 2) {
        const cond = evaluateComparison(cells, parts[0]);
        return cond ? evaluateArg(cells, parts[1]) : evaluateArg(cells, parts[2] ?? '');
      }
    }
  }

  // Arithmetic expression with cell references
  try {
    let evalExpr = expr;
    // Replace cell references with values
    evalExpr = evalExpr.replace(/([A-Z]+\d+)/gi, (match) => {
      const val = getCellValue(cells, match.toUpperCase());
      return val.toString();
    });
    // eslint-disable-next-line no-new-func
    const result = new Function('return (' + evalExpr + ')')();
    return typeof result === 'number' ? result.toString() : result;
  } catch {
    return '#VALUE!';
  }
}

function splitArgs(args: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let current = '';
  for (const ch of args) {
    if (ch === '(') { depth++; current += ch; }
    else if (ch === ')') { depth--; current += ch; }
    else if (ch === ',' && depth === 0) { parts.push(current.trim()); current = ''; }
    else { current += ch; }
  }
  if (current.trim()) parts.push(current.trim());
  return parts;
}

function evaluateArg(cells: Record<string, CellData>, arg: string): string {
  arg = arg.trim();
  if (arg.startsWith('"') && arg.endsWith('"')) return arg.slice(1, -1);
  const cellRef = parseCellRef(arg);
  if (cellRef) return getCellRawValue(cells, `${COL_LABELS[cellRef.col]}${cellRef.row + 1}`);
  try {
    // eslint-disable-next-line no-new-func
    return new Function('return (' + arg + ')')()?.toString() ?? '';
  } catch { return arg; }
}

function evaluateComparison(cells: Record<string, CellData>, expr: string): boolean {
  const evalExpr = expr.replace(/([A-Z]+\d+)/gi, (match) => {
    const val = getCellValue(cells, match.toUpperCase());
    return val.toString();
  });
  try {
    // eslint-disable-next-line no-new-func
    return !!new Function('return (' + evalExpr + ')')();
  } catch { return false; }
}

/* ------------------------------------------------------------------ */
/*  Format Helpers                                                     */
/* ------------------------------------------------------------------ */
function formatCellDisplay(value: string, data?: CellData): string {
  if (!data) return value;
  if (data.formula) {
    const result = evaluateFormula(data._allCells || {}, data.formula);
    if (result.startsWith('#')) return result;
    if (data.numberFormat === 'currency') {
      const n = parseFloat(result);
      if (!isNaN(n)) return '$' + n.toFixed(2);
    }
    if (data.numberFormat === 'percent') {
      const n = parseFloat(result);
      if (!isNaN(n)) return (n * 100).toFixed(1) + '%';
    }
    return result;
  }
  if (data.numberFormat === 'currency') {
    const n = parseFloat(value);
    if (!isNaN(n)) return '$' + n.toFixed(2);
  }
  if (data.numberFormat === 'percent') {
    const n = parseFloat(value);
    if (!isNaN(n)) return (n * 100).toFixed(1) + '%';
  }
  return value;
}

/* ------------------------------------------------------------------ */
/*  Persistence                                                        */
/* ------------------------------------------------------------------ */
function loadState(): SpreadsheetState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { cells: {}, colCount: 20, rowCount: 50 };
}

function saveState(state: SpreadsheetState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

/* ------------------------------------------------------------------ */
/*  Main Spreadsheet                                                   */
/* ------------------------------------------------------------------ */
export default function SpreadsheetApp() {
  const [state, setState] = useState<SpreadsheetState>(loadState);
  const [selectedCell, setSelectedCell] = useState<string>('A1');
  const [editCell, setEditCell] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { saveState(state); }, [state]);

  const getCell = useCallback((ref: string): CellData | undefined => state.cells[ref], [state.cells]);

  const setCell = useCallback((ref: string, data: Partial<CellData>) => {
    setState((s) => ({
      ...s,
      cells: {
        ...s.cells,
        [ref]: { ...s.cells[ref], value: s.cells[ref]?.value ?? '', formula: s.cells[ref]?.formula ?? '', ...data },
      },
    }));
  }, []);

  const handleCellClick = useCallback((ref: string) => {
    setSelectedCell(ref);
    setEditCell(null);
  }, []);

  const handleCellDoubleClick = useCallback((ref: string) => {
    const data = getCell(ref);
    setEditValue(data?.formula || data?.value || '');
    setEditCell(ref);
    setTimeout(() => inputRef.current?.focus(), 0);
  }, [getCell]);

  const commitEdit = useCallback(() => {
    if (!editCell) return;
    const isFormula = editValue.trim().startsWith('=');
    setCell(editCell, {
      value: editValue.trim(),
      formula: isFormula ? editValue.trim() : '',
    });
    setEditCell(null);
    setEditValue('');
  }, [editCell, editValue, setCell]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (editCell) {
        if (e.key === 'Enter') { e.preventDefault(); commitEdit(); }
        if (e.key === 'Escape') { setEditCell(null); setEditValue(''); }
        return;
      }

      const ref = parseCellRef(selectedCell);
      if (!ref) return;
      const { col, row } = ref;

      switch (e.key) {
        case 'ArrowRight':
          e.preventDefault();
          if (col < state.colCount - 1) setSelectedCell(`${COL_LABELS[col + 1]}${row + 1}`);
          break;
        case 'ArrowLeft':
          e.preventDefault();
          if (col > 0) setSelectedCell(`${COL_LABELS[col - 1]}${row + 1}`);
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (row < state.rowCount - 1) setSelectedCell(`${COL_LABELS[col]}${row + 2}`);
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (row > 0) setSelectedCell(`${COL_LABELS[col]}${row}`);
          break;
        case 'Enter':
          e.preventDefault();
          handleCellDoubleClick(selectedCell);
          break;
        default:
          if (e.key.length === 1 && !e.ctrlKey && !e.metaKey) {
            setEditValue(e.key);
            setEditCell(selectedCell);
            setTimeout(() => inputRef.current?.focus(), 0);
          }
      }
    },
    [selectedCell, editCell, state.colCount, state.rowCount, handleCellDoubleClick, commitEdit]
  );

  const addRow = () => {
    setState((s) => ({ ...s, rowCount: Math.min(s.rowCount + 1, 100) }));
  };

  const addCol = () => {
    setState((s) => ({ ...s, colCount: Math.min(s.colCount + 1, 26) }));
  };

  const deleteRow = () => {
    const ref = parseCellRef(selectedCell);
    if (!ref) return;
    const row = ref.row;
    setState((s) => {
      const newCells = { ...s.cells };
      Object.keys(newCells).forEach((key) => {
        const r = parseCellRef(key);
        if (r && r.row === row) delete newCells[key];
      });
      // Shift rows up
      const shifted: Record<string, CellData> = {};
      Object.entries(newCells).forEach(([key, val]) => {
        const r = parseCellRef(key);
        if (!r) { shifted[key] = val; return; }
        if (r.row > row) {
          shifted[`${COL_LABELS[r.col]}${r.row}`] = val;
        } else {
          shifted[key] = val;
        }
      });
      return { ...s, cells: shifted, rowCount: Math.max(s.rowCount - 1, 10) };
    });
  };

  const toggleBold = () => {
    const data = getCell(selectedCell);
    setCell(selectedCell, { bold: !data?.bold });
  };

  const toggleItalic = () => {
    const data = getCell(selectedCell);
    setCell(selectedCell, { italic: !data?.italic });
  };

  const setCellColor = (color: string) => {
    setCell(selectedCell, { color });
  };

  const setNumberFormat = (fmt: CellData['numberFormat']) => {
    setCell(selectedCell, { numberFormat: fmt });
  };

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'spreadsheet.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportCSV = () => {
    let csv = '';
    for (let r = 0; r < state.rowCount; r++) {
      const row: string[] = [];
      for (let c = 0; c < state.colCount; c++) {
        const ref = `${COL_LABELS[c]}${r + 1}`;
        const data = state.cells[ref];
        let val = data ? (data.formula ? evaluateFormula(state.cells, data.formula) : data.value) : '';
        if (val.includes(',') || val.includes('"')) val = '"' + val.replace(/"/g, '""') + '"';
        row.push(val);
      }
      csv += row.join(',') + '\n';
    }
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'spreadsheet.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const currentCellData = getCell(selectedCell);
  const formulaBarValue = editCell
    ? editValue
    : currentCellData?.formula || currentCellData?.value || '';

  // Augment cells with _allCells reference for formula evaluation display
  const displayCells = useMemo(() => state.cells, [state.cells]);

  const currentDisplayValue = currentCellData
    ? formatCellDisplay(currentCellData.value, { ...currentCellData, _allCells: displayCells } as CellData & { _allCells: Record<string, CellData> })
    : '';

  return (
    <div
      className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex flex-col outline-none"
      tabIndex={0}
      onKeyDown={handleKeyDown}
    >
      {/* Toolbar */}
      <div className="flex items-center gap-1.5 px-3 py-2 border-b border-[#2A2A3E] bg-[#1A1A26]">
        <div className="flex items-center gap-1">
          <button
            onClick={toggleBold}
            className={`p-1.5 rounded transition-colors ${currentCellData?.bold ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235] text-[#8A8578]'}`}
            title="Bold"
          >
            <Bold className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={toggleItalic}
            className={`p-1.5 rounded transition-colors ${currentCellData?.italic ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235] text-[#8A8578]'}`}
            title="Italic"
          >
            <Italic className="w-3.5 h-3.5" />
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
          <button onClick={() => setNumberFormat('number')} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Number">
            <Hash className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => setNumberFormat('currency')} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Currency">
            <span className="text-xs font-bold">$</span>
          </button>
          <button onClick={() => setNumberFormat('percent')} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Percent">
            <span className="text-xs font-bold">%</span>
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
          <div className="flex gap-0.5">
            {COLOR_OPTIONS.map((c) => (
              <button
                key={c}
                onClick={() => setCellColor(c)}
                className="w-4 h-4 rounded-sm border border-[#2A2A3E] hover:scale-110 transition-transform"
                style={{ backgroundColor: c }}
                title={c}
              />
            ))}
          </div>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
          <button onClick={addRow} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578] flex items-center gap-1" title="Add Row">
            <Plus className="w-3.5 h-3.5" /> Row
          </button>
          <button onClick={addCol} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578] flex items-center gap-1" title="Add Column">
            <Plus className="w-3.5 h-3.5" /> Col
          </button>
          <button onClick={deleteRow} className="p-1.5 hover:bg-[#B84A4A]/20 rounded transition-colors text-[#8A8578] hover:text-[#B84A4A]" title="Delete Row">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <div className="w-px h-5 bg-[#2A2A3E] mx-1" />
          <button onClick={exportJSON} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578]" title="Export JSON">
            <Download className="w-3.5 h-3.5" />
          </button>
          <button onClick={exportCSV} className="p-1.5 hover:bg-[#222235] rounded transition-colors text-[#8A8578] text-xs font-medium" title="Export CSV">
            CSV
          </button>
        </div>
      </div>

      {/* Formula bar */}
      <div className="flex items-center gap-2 px-3 py-1.5 border-b border-[#2A2A3E] bg-[#0A0A0F]">
        <div className="text-xs text-[#C9A84C] font-mono w-[50px] text-center bg-[#1A1A26] rounded px-1.5 py-0.5 border border-[#2A2A3E]">
          {selectedCell}
        </div>
        <Calculator className="w-3.5 h-3.5 text-[#4D4A42]" />
        <input
          value={formulaBarValue}
          onChange={(e) => {
            setEditValue(e.target.value);
            if (!editCell) setEditCell(selectedCell);
          }}
          onFocus={() => { setEditValue(formulaBarValue); setEditCell(selectedCell); }}
          onBlur={() => commitEdit()}
          onKeyDown={(e) => { if (e.key === 'Enter') commitEdit(); if (e.key === 'Escape') { setEditCell(null); setEditValue(''); } }}
          className="flex-1 bg-transparent text-sm text-[#E8E4DC] outline-none font-mono"
          spellCheck={false}
        />
        <div className="text-xs text-[#4D4A42]">{currentDisplayValue}</div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-auto">
        <div className="inline-block min-w-full">
          {/* Column headers */}
          <div className="flex sticky top-0 z-10">
            <div className="w-[50px] h-[26px] bg-[#1A1A26] border-b border-r border-[#2A2A3E] flex-shrink-0 sticky left-0 z-20" />
            {COL_LABELS.slice(0, state.colCount).map((col) => (
              <div
                key={col}
                className="w-[100px] h-[26px] bg-[#1A1A26] border-b border-r border-[#2A2A3E] flex items-center justify-center text-[10px] text-[#8A8578] font-mono flex-shrink-0 select-none"
              >
                {col}
              </div>
            ))}
          </div>

          {/* Rows */}
          {Array.from({ length: state.rowCount }, (_, row) => (
            <div key={row} className="flex">
              <div className="w-[50px] h-[26px] bg-[#1A1A26] border-b border-r border-[#2A2A3E] flex items-center justify-center text-[10px] text-[#8A8578] font-mono flex-shrink-0 sticky left-0 z-10 select-none">
                {row + 1}
              </div>
              {COL_LABELS.slice(0, state.colCount).map((col) => {
                const ref = `${col}${row + 1}`;
                const data = state.cells[ref];
                const isSelected = selectedCell === ref;
                const isEditing = editCell === ref;
                const displayValue = formatCellDisplay(data?.value ?? '', data
                  ? { ...data, _allCells: displayCells } as CellData & { _allCells: Record<string, CellData> }
                  : undefined);

                return (
                  <div
                    key={ref}
                    className={`w-[100px] h-[26px] border-b border-r border-[#2A2A3E] flex-shrink-0 relative cursor-cell ${
                      isSelected ? 'ring-1 ring-[#C9A84C] ring-inset z-[1]' : ''
                    }`}
                    onClick={() => handleCellClick(ref)}
                    onDoubleClick={() => handleCellDoubleClick(ref)}
                  >
                    {isEditing ? (
                      <input
                        ref={inputRef}
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={commitEdit}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') commitEdit();
                          if (e.key === 'Escape') { setEditCell(null); setEditValue(''); }
                          e.stopPropagation();
                        }}
                        className="absolute inset-0 w-full h-full px-1 bg-[#12121A] text-[11px] font-mono text-[#E8E4DC] outline-none border border-[#C9A84C] z-20"
                      />
                    ) : (
                      <div
                        className={`w-full h-full px-1 flex items-center text-[11px] font-mono truncate ${
                          data?.bold ? 'font-bold' : ''
                        } ${data?.italic ? 'italic' : ''} ${
                          data?.formula ? 'text-[#5A9E6F]' : 'text-[#E8E4DC]'
                        }`}
                        style={{ color: data?.color || (data?.formula ? '#5A9E6F' : undefined) }}
                        title={data?.formula || data?.value}
                      >
                        {displayValue}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-3 py-1 border-t border-[#2A2A3E] bg-[#0A0A0F] text-[10px] text-[#4D4A42]">
        <div className="flex items-center gap-3">
          <span>{selectedCell}</span>
          <span>{state.rowCount} rows × {state.colCount} cols</span>
        </div>
        <span>Enter to edit · Arrows navigate · = for formulas</span>
      </div>
    </div>
  );
}
