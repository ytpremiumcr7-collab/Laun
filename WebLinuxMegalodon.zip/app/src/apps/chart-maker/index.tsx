import { useState, useCallback, useRef } from 'react';
import {
  BarChart3, Plus, Trash2, Download, Type,
  LineChart as LineChartIcon
} from 'lucide-react';

type ChartType = 'bar' | 'line' | 'pie' | 'doughnut' | 'area' | 'radar';

interface DataRow {
  id: string;
  label: string;
  value: number;
}

interface ChartOptions {
  showGrid: boolean;
  showValues: boolean;
  showLegend: boolean;
  animate: boolean;
}

const SAMPLE_DATA: DataRow[] = [
  { id: '1', label: 'Jan', value: 45 },
  { id: '2', label: 'Feb', value: 72 },
  { id: '3', label: 'Mar', value: 38 },
  { id: '4', label: 'Apr', value: 91 },
  { id: '5', label: 'May', value: 56 },
  { id: '6', label: 'Jun', value: 67 },
  { id: '7', label: 'Jul', value: 84 },
  { id: '8', label: 'Aug', value: 52 },
  { id: '9', label: 'Sep', value: 73 },
  { id: '10', label: 'Oct', value: 88 },
  { id: '11', label: 'Nov', value: 61 },
  { id: '12', label: 'Dec', value: 95 },
];

const COLOR_SCHEMES: Record<string, string[]> = {
  gold: ['#C9A84C', '#D4B85A', '#E8D088', '#8B7340', '#A68B4B', '#B89E50', '#D9C97A', '#F0E0A0'],
  cool: ['#5A8AB8', '#4A9E9E', '#7B6FB8', '#5A9E6F', '#4A7EB8', '#6B5FB8', '#3D8E8E', '#8A7BC8'],
  warm: ['#D4953A', '#C9A84C', '#B84A4A', '#D4A04A', '#E8B060', '#C07040', '#A86050', '#E0C050'],
  neon: ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'],
  mono: ['#E8E4DC', '#8A8578', '#4D4A42', '#2A2A3E', '#3D3D5C', '#555580', '#6A6A9A', '#8080B0'],
};

export default function ChartMaker() {
  const [data, setData] = useState<DataRow[]>(SAMPLE_DATA);
  const [chartType, setChartType] = useState<ChartType>('bar');
  const [chartTitle, setChartTitle] = useState('2025 Monthly Sales');
  const [colorScheme, setColorScheme] = useState('gold');
  const [options, setOptions] = useState<ChartOptions>({ showGrid: true, showValues: true, showLegend: true, animate: true });
  const chartRef = useRef<HTMLDivElement>(null);

  const colors = COLOR_SCHEMES[colorScheme] || COLOR_SCHEMES.gold;
  const maxValue = Math.max(...data.map(d => d.value), 1);
  const totalValue = data.reduce((s, d) => s + d.value, 0);

  const addRow = useCallback(() => {
    setData(prev => [...prev, { id: Date.now().toString(), label: `Item ${prev.length + 1}`, value: 0 }]);
  }, []);

  const removeRow = useCallback((id: string) => {
    setData(prev => prev.filter(d => d.id !== id));
  }, []);

  const updateRow = useCallback((id: string, field: 'label' | 'value', value: string) => {
    setData(prev => prev.map(d => d.id === id ? { ...d, [field]: field === 'value' ? parseFloat(value) || 0 : value } : d));
  }, []);

  const downloadChart = useCallback(() => {
    if (!chartRef.current) return;
    const svg = chartRef.current.querySelector('svg');
    if (!svg) return;
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.fillStyle = '#030305';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      const link = document.createElement('a');
      link.download = 'chart.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
    };
    img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
  }, []);

  const renderChart = () => {
    const w = 600;
    const h = 350;
    const padding = { top: 40, right: 30, bottom: 50, left: 50 };
    const chartW = w - padding.left - padding.right;
    const chartH = h - padding.top - padding.bottom;

    const barWidth = chartW / data.length * 0.6;
    const barGap = chartW / data.length * 0.4;

    if (chartType === 'pie' || chartType === 'doughnut') {
      const cx = w / 2;
      const cy = h / 2 + 10;
      const radius = Math.min(chartW, chartH) / 2 - 10;
      const innerRadius = chartType === 'doughnut' ? radius * 0.5 : 0;

      let currentAngle = -Math.PI / 2;
      const slices = data.map((d, i) => {
        const angle = (d.value / totalValue) * Math.PI * 2;
        const startAngle = currentAngle;
        const endAngle = currentAngle + angle;
        currentAngle = endAngle;

        const largeArc = angle > Math.PI ? 1 : 0;
        const x1 = cx + radius * Math.cos(startAngle);
        const y1 = cy + radius * Math.sin(startAngle);
        const x2 = cx + radius * Math.cos(endAngle);
        const y2 = cy + radius * Math.sin(endAngle);
        const ix1 = cx + innerRadius * Math.cos(startAngle);
        const iy1 = cy + innerRadius * Math.sin(startAngle);
        const ix2 = cx + innerRadius * Math.cos(endAngle);
        const iy2 = cy + innerRadius * Math.sin(endAngle);

        const path = chartType === 'doughnut'
          ? `M ${ix1} ${iy1} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} L ${ix2} ${iy2} A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${ix1} ${iy1}`
          : `M ${cx} ${cy} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;

        const midAngle = startAngle + angle / 2;
        const labelRadius = radius * 0.7;
        const lx = cx + labelRadius * Math.cos(midAngle);
        const ly = cy + labelRadius * Math.sin(midAngle);

        return { path, color: colors[i % colors.length], label: d.label, value: d.value, lx, ly };
      });

      return (
        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full">
          {slices.map((s, i) => (
            <g key={i}>
              <path d={s.path} fill={s.color} stroke="#030305" strokeWidth="2"
                opacity={options.animate ? undefined : 1}
                style={options.animate ? { animation: `pieIn 0.6s ease-out ${i * 0.05}s both` } : undefined}
              />
              {options.showValues && s.value > totalValue * 0.05 && (
                <text x={s.lx} y={s.ly} textAnchor="middle" dominantBaseline="middle" fill="#E8E4DC" fontSize="11" fontWeight="500">
                  {Math.round((s.value / totalValue) * 100)}%
                </text>
              )}
            </g>
          ))}
          {options.showLegend && (
            <g transform={`translate(${w - 100}, 20)`}>
              {data.slice(0, 8).map((d, i) => (
                <g key={i} transform={`translate(0, ${i * 18})`}>
                  <rect x="0" y="0" width="10" height="10" rx="2" fill={colors[i % colors.length]} />
                  <text x="14" y="9" fill="#8A8578" fontSize="9">{d.label}</text>
                </g>
              ))}
            </g>
          )}
        </svg>
      );
    }

    if (chartType === 'radar') {
      const cx = w / 2;
      const cy = h / 2 + 10;
      const radius = Math.min(chartW, chartH) / 2 - 20;
      const angleStep = (Math.PI * 2) / data.length;

      return (
        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full">
          {/* Grid circles */}
          {[0.25, 0.5, 0.75, 1].map((scale, i) => (
            <polygon
              key={i}
              points={data.map((_, j) => {
                const angle = j * angleStep - Math.PI / 2;
                const r = radius * scale;
                return `${cx + r * Math.cos(angle)},${cy + r * Math.sin(angle)}`;
              }).join(' ')}
              fill="none"
              stroke="#2A2A3E"
              strokeWidth="1"
            />
          ))}
          {/* Axis lines */}
          {data.map((_, i) => {
            const angle = i * angleStep - Math.PI / 2;
            return (
              <line key={i} x1={cx} y1={cy} x2={cx + radius * Math.cos(angle)} y2={cy + radius * Math.sin(angle)}
                stroke="#2A2A3E" strokeWidth="1" />
            );
          })}
          {/* Data polygon */}
          <polygon
            points={data.map((d, i) => {
              const angle = i * angleStep - Math.PI / 2;
              const r = (d.value / maxValue) * radius;
              return `${cx + r * Math.cos(angle)},${cy + r * Math.sin(angle)}`;
            }).join(' ')}
            fill={`${colors[0]}30`}
            stroke={colors[0]}
            strokeWidth="2"
          />
          {/* Data points */}
          {data.map((d, i) => {
            const angle = i * angleStep - Math.PI / 2;
            const r = (d.value / maxValue) * radius;
            return (
              <circle key={i} cx={cx + r * Math.cos(angle)} cy={cy + r * Math.sin(angle)} r="4"
                fill={colors[i % colors.length]} stroke="#030305" strokeWidth="1" />
            );
          })}
          {/* Labels */}
          {data.map((d, i) => {
            const angle = i * angleStep - Math.PI / 2;
            const labelR = radius + 18;
            return (
              <text key={i} x={cx + labelR * Math.cos(angle)} y={cy + labelR * Math.sin(angle)}
                textAnchor="middle" dominantBaseline="middle" fill="#8A8578" fontSize="9">{d.label}</text>
            );
          })}
        </svg>
      );
    }

    /* Bar / Line / Area */
    return (
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full">
        {/* Grid lines */}
        {options.showGrid && Array.from({ length: 6 }, (_, i) => {
          const y = padding.top + (chartH / 5) * i;
          const val = Math.round(maxValue * (1 - i / 5));
          return (
            <g key={i}>
              <line x1={padding.left} y1={y} x2={w - padding.right} y2={y} stroke="#2A2A3E" strokeWidth="1" strokeDasharray="4" />
              <text x={padding.left - 8} y={y + 3} textAnchor="end" fill="#4D4A42" fontSize="9">{val}</text>
            </g>
          );
        })}

        {chartType === 'bar' && data.map((d, i) => {
          const x = padding.left + i * (chartW / data.length) + barGap / 2;
          const barH = (d.value / maxValue) * chartH;
          const y = padding.top + chartH - barH;
          return (
            <g key={i}>
              <rect
                x={x} y={options.animate ? padding.top + chartH : y}
                width={barWidth} height={options.animate ? 0 : barH}
                rx="3" fill={colors[i % colors.length]}
                style={options.animate ? { animation: `barGrow 0.6s ease-out ${i * 0.05}s forwards` } : undefined}
              >
                {options.animate && <animate attributeName="y" from={padding.top + chartH} to={y} dur="0.6s" begin={`${i * 0.05}s`} fill="freeze" />}
                {options.animate && <animate attributeName="height" from="0" to={barH} dur="0.6s" begin={`${i * 0.05}s`} fill="freeze" />}
              </rect>
              {options.showValues && (
                <text x={x + barWidth / 2} y={y - 5} textAnchor="middle" fill="#E8E4DC" fontSize="9">{d.value}</text>
              )}
              <text x={x + barWidth / 2} y={h - padding.bottom + 15} textAnchor="middle" fill="#8A8578" fontSize="9">{d.label}</text>
            </g>
          );
        })}

        {(chartType === 'line' || chartType === 'area') && (
          <>
            {chartType === 'area' && (
              <polygon
                points={`${padding.left},${padding.top + chartH} ` +
                  data.map((d, i) => {
                    const x = padding.left + i * (chartW / (data.length - 1));
                    const y = padding.top + chartH - (d.value / maxValue) * chartH;
                    return `${x},${y}`;
                  }).join(' ') +
                  ` ${w - padding.right},${padding.top + chartH}`}
                fill={`${colors[0]}20`}
              />
            )}
            <polyline
              points={data.map((d, i) => {
                const x = padding.left + i * (chartW / (data.length - 1));
                const y = padding.top + chartH - (d.value / maxValue) * chartH;
                return `${x},${y}`;
              }).join(' ')}
              fill="none" stroke={colors[0]} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round"
              strokeDasharray={options.animate ? `${chartW + chartH}` : undefined}
              strokeDashoffset={options.animate ? 0 : undefined}
              style={options.animate ? { animation: 'drawLine 1s ease-out forwards' } : undefined}
            />
            {data.map((d, i) => {
              const x = padding.left + i * (chartW / (data.length - 1));
              const y = padding.top + chartH - (d.value / maxValue) * chartH;
              return (
                <g key={i}>
                  <circle cx={x} cy={y} r="4" fill={colors[i % colors.length]} stroke="#030305" strokeWidth="1.5" />
                  {options.showValues && (
                    <text x={x} y={y - 8} textAnchor="middle" fill="#E8E4DC" fontSize="9">{d.value}</text>
                  )}
                  <text x={x} y={h - padding.bottom + 15} textAnchor="middle" fill="#8A8578" fontSize="9">{d.label}</text>
                </g>
              );
            })}
          </>
        )}
      </svg>
    );
  };

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Toolbar */}
      <div className="flex items-center gap-1 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        {/* Chart type selector */}
        {([
          { key: 'bar' as ChartType, label: 'Bar', icon: BarChart3 },
          { key: 'line' as ChartType, label: 'Line', icon: LineChartIcon },
          { key: 'pie' as ChartType, label: 'Pie', icon: BarChart3 },
          { key: 'doughnut' as ChartType, label: 'Doughnut', icon: BarChart3 },
          { key: 'area' as ChartType, label: 'Area', icon: LineChartIcon },
          { key: 'radar' as ChartType, label: 'Radar', icon: BarChart3 },
        ]).map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded border transition-colors ${
              chartType === key ? 'bg-[#C9A84C]/20 border-[#C9A84C] text-[#C9A84C]' : 'border-[#2A2A3E] hover:bg-[#222235]'
            }`}
            onClick={() => setChartType(key)}
          >
            <Icon className="w-3.5 h-3.5" /> {label}
          </button>
        ))}

        <div className="w-px h-5 bg-[#2A2A3E] mx-1" />

        {/* Title */}
        <div className="flex items-center gap-1">
          <Type className="w-3.5 h-3.5 text-[#8A8578]" />
          <input
            type="text"
            className="bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1 text-xs outline-none focus:border-[#C9A84C] w-32"
            value={chartTitle}
            onChange={e => setChartTitle(e.target.value)}
            placeholder="Chart title..."
          />
        </div>

        {/* Color scheme */}
        <div className="relative">
          <select
            className="appearance-none bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1 pr-6 text-xs outline-none focus:border-[#C9A84C]"
            value={colorScheme}
            onChange={e => setColorScheme(e.target.value)}
          >
            {Object.keys(COLOR_SCHEMES).map(s => (
              <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
            ))}
          </select>
        </div>

        <div className="flex-1" />

        {/* Options */}
        <div className="flex items-center gap-2">
          {([
            { key: 'showGrid' as keyof ChartOptions, label: 'Grid' },
            { key: 'showValues' as keyof ChartOptions, label: 'Values' },
            { key: 'showLegend' as keyof ChartOptions, label: 'Legend' },
            { key: 'animate' as keyof ChartOptions, label: 'Animate' },
          ]).map(({ key, label }) => (
            <label key={key} className="flex items-center gap-1 cursor-pointer">
              <input type="checkbox" checked={options[key]} onChange={e => setOptions(prev => ({ ...prev, [key]: e.target.checked }))} className="accent-[#C9A84C] w-3 h-3" />
              <span className="text-[10px] text-[#8A8578]">{label}</span>
            </label>
          ))}
        </div>

        <button className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#5A9E6F] text-white hover:bg-[#6AAF7F] transition-colors" onClick={downloadChart}>
          <Download className="w-3.5 h-3.5" /> Export
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Data editor */}
        <div className="w-48 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col shrink-0 overflow-hidden">
          <div className="px-3 py-2 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E]">
            Data
          </div>
          <div className="flex-1 overflow-y-auto p-2">
            {/* Header */}
            <div className="flex items-center gap-1 mb-1">
              <span className="text-[10px] text-[#8A8578] w-12">Label</span>
              <span className="text-[10px] text-[#8A8578] flex-1">Value</span>
            </div>
            {data.map((row) => (
              <div key={row.id} className="flex items-center gap-1 mb-1">
                <input
                  type="text"
                  className="w-12 bg-[#12121A] border border-[#2A2A3E] rounded px-1 py-0.5 text-[10px] outline-none focus:border-[#C9A84C]"
                  value={row.label}
                  onChange={e => updateRow(row.id, 'label', e.target.value)}
                />
                <input
                  type="number"
                  className="flex-1 min-w-0 bg-[#12121A] border border-[#2A2A3E] rounded px-1 py-0.5 text-[10px] outline-none focus:border-[#C9A84C] font-mono"
                  value={row.value}
                  onChange={e => updateRow(row.id, 'value', e.target.value)}
                />
                <button
                  className="p-0.5 rounded hover:bg-[#B84A4A]/20 shrink-0"
                  onClick={() => removeRow(row.id)}
                >
                  <Trash2 className="w-3 h-3 text-[#B84A4A]" />
                </button>
              </div>
            ))}
            <button
              className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] text-[10px] mt-1 w-full justify-center"
              onClick={addRow}
            >
              <Plus className="w-3 h-3" /> Add Row
            </button>
          </div>

          {/* Summary */}
          <div className="border-t border-[#2A2A3E] px-3 py-2">
            <div className="text-[10px] text-[#4D4A42]">Total: <span className="text-[#E8E4DC] font-mono">{totalValue}</span></div>
            <div className="text-[10px] text-[#4D4A42] mt-0.5">Avg: <span className="text-[#E8E4DC] font-mono">{(totalValue / data.length).toFixed(1)}</span></div>
            <div className="text-[10px] text-[#4D4A42] mt-0.5">Max: <span className="text-[#C9A84C] font-mono">{maxValue}</span></div>
          </div>
        </div>

        {/* Chart preview */}
        <div className="flex-1 flex flex-col items-center justify-center p-6 overflow-auto">
          <div className="w-full max-w-2xl">
            <h2 className="text-center text-sm font-medium mb-4 text-[#E8E4DC]">{chartTitle}</h2>
            <div ref={chartRef} className="w-full aspect-[16/9] bg-[#0A0A0F] rounded-lg border border-[#2A2A3E] p-2">
              {renderChart()}
            </div>
          </div>
        </div>
      </div>

      {/* CSS Animations */}
      <style>{`
        @keyframes barGrow {
          from { transform: scaleY(0); transform-origin: bottom; }
          to { transform: scaleY(1); }
        }
        @keyframes drawLine {
          from { stroke-dashoffset: ${800 + 400}; }
          to { stroke-dashoffset: 0; }
        }
        @keyframes pieIn {
          from { opacity: 0; transform: scale(0.8); transform-origin: center; }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}
