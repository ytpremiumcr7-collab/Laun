import { useState, useEffect, useCallback } from 'react';
import { Bomb, Flag, Clock, Trophy } from 'lucide-react';

interface Cell {
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  neighborMines: number;
}

type Difficulty = 'beginner' | 'intermediate' | 'expert' | 'custom';

const DIFFICULTIES: Record<Difficulty, { rows: number; cols: number; mines: number }> = {
  beginner: { rows: 9, cols: 9, mines: 10 },
  intermediate: { rows: 16, cols: 16, mines: 40 },
  expert: { rows: 16, cols: 30, mines: 99 },
  custom: { rows: 10, cols: 10, mines: 15 },
};

function createBoard(rows: number, cols: number): Cell[][] {
  return Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => ({ isMine: false, isRevealed: false, isFlagged: false, neighborMines: 0 }))
  );
}

function placeMines(board: Cell[][], rows: number, cols: number, mines: number, safeRow: number, safeCol: number): Cell[][] {
  const newBoard = board.map((r) => r.map((c) => ({ ...c })));
  let placed = 0;
  while (placed < mines) {
    const r = Math.floor(Math.random() * rows);
    const c = Math.floor(Math.random() * cols);
    // Don't place on safe cell or already mined
    if ((r === safeRow && c === safeCol) || newBoard[r][c].isMine) continue;
    // Don't place on safe cell's neighbors for first click
    if (Math.abs(r - safeRow) <= 1 && Math.abs(c - safeCol) <= 1) continue;
    newBoard[r][c].isMine = true;
    placed++;
  }
  // Calculate neighbor counts
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (newBoard[r][c].isMine) continue;
      let count = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && newBoard[nr][nc].isMine) count++;
        }
      }
      newBoard[r][c].neighborMines = count;
    }
  }
  return newBoard;
}

export default function Minesweeper() {
  const [difficulty, setDifficulty] = useState<Difficulty>('beginner');
  const [board, setBoard] = useState<Cell[][]>([]);
  const [gameState, setGameState] = useState<'ready' | 'playing' | 'won' | 'lost'>('ready');
  const [timer, setTimer] = useState(0);
  const [firstClick, setFirstClick] = useState(true);
  const [flags, setFlags] = useState(0);

  const [leaderboard, setLeaderboard] = useState<Record<string, number>>(() => {
    try { return JSON.parse(localStorage.getItem('cs-minesweeper-lb') || '{}'); } catch { return {}; }
  });

  const { rows, cols, mines } = DIFFICULTIES[difficulty];

  const resetGame = useCallback(() => {
    setBoard(createBoard(rows, cols));
    setGameState('ready');
    setTimer(0);
    setFirstClick(true);
    setFlags(0);
  }, [rows, cols]);

  useEffect(() => {
    resetGame();
  }, [resetGame]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (gameState === 'playing') {
      interval = setInterval(() => setTimer((t) => t + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [gameState]);

  const revealCell = (board: Cell[][], r: number, c: number): Cell[][] => {
    if (r < 0 || r >= rows || c < 0 || c >= cols) return board;
    const cell = board[r][c];
    if (cell.isRevealed || cell.isFlagged) return board;
    const newBoard = board.map((row) => [...row]);
    newBoard[r][c] = { ...cell, isRevealed: true };
    if (cell.neighborMines === 0 && !cell.isMine) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const result = revealCell(newBoard, r + dr, c + dc);
          for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
              newBoard[i][j] = result[i][j];
            }
          }
        }
      }
    }
    return newBoard;
  };

  const handleClick = (r: number, c: number) => {
    if (gameState === 'won' || gameState === 'lost') return;
    const cell = board[r][c];
    if (cell.isRevealed || cell.isFlagged) return;

    if (firstClick) {
      const newBoard = placeMines(createBoard(rows, cols), rows, cols, mines, r, c);
      setBoard(revealCell(newBoard, r, c));
      setFirstClick(false);
      setGameState('playing');
      return;
    }

    if (cell.isMine) {
      // Reveal all mines
      const newBoard = board.map((row) => row.map((cell) => ({ ...cell, isRevealed: cell.isRevealed || cell.isMine })));
      setBoard(newBoard);
      setGameState('lost');
      return;
    }

    const newBoard = revealCell(board, r, c);
    setBoard(newBoard);

    // Check win
    const unrevealed = newBoard.flat().filter((c) => !c.isRevealed).length;
    if (unrevealed === mines) {
      setGameState('won');
      const key = difficulty;
      if (!leaderboard[key] || timer < leaderboard[key]) {
        const newLb = { ...leaderboard, [key]: timer };
        setLeaderboard(newLb);
        localStorage.setItem('cs-minesweeper-lb', JSON.stringify(newLb));
      }
    }
  };

  const handleRightClick = (e: React.MouseEvent, r: number, c: number) => {
    e.preventDefault();
    if (gameState === 'won' || gameState === 'lost') return;
    const cell = board[r][c];
    if (cell.isRevealed) return;

    if (cell.isFlagged) {
      const newBoard = board.map((row) => [...row]);
      newBoard[r][c] = { ...cell, isFlagged: false };
      setBoard(newBoard);
      setFlags((f) => f - 1);
    } else {
      const newBoard = board.map((row) => [...row]);
      newBoard[r][c] = { ...cell, isFlagged: true };
      setBoard(newBoard);
      setFlags((f) => f + 1);
    }
  };

  const handleChord = (r: number, c: number) => {
    if (gameState === 'won' || gameState === 'lost') return;
    const cell = board[r][c];
    if (!cell.isRevealed || cell.neighborMines === 0) return;

    // Count adjacent flags
    let flagCount = 0;
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = r + dr, nc = c + dc;
        if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && board[nr][nc].isFlagged) flagCount++;
      }
    }

    if (flagCount === cell.neighborMines) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
            const neighbor = board[nr][nc];
            if (!neighbor.isFlagged && !neighbor.isRevealed) {
              if (neighbor.isMine) {
                const newBoard = board.map((row) => row.map((c) => ({ ...c, isRevealed: c.isRevealed || c.isMine })));
                setBoard(newBoard);
                setGameState('lost');
                return;
              }
              const newBoard = revealCell(board, nr, nc);
              setBoard(newBoard);
            }
          }
        }
      }
    }
  };

  const cellSize = Math.min(28, Math.floor(380 / Math.max(cols, 9)));
  const NUMBER_COLORS = ['transparent', '#5A8AB8', '#5A9E6F', '#B84A4A', '#7B6FB8', '#8B3A3A', '#4A9E9E', '#E8E4DC', '#4D4A42'];

  return (
    <div className="w-full h-full flex flex-col items-center select-none overflow-y-auto" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Header */}
      <div className="flex items-center justify-between w-full max-w-[600px] px-3 py-1.5">
        <div className="flex items-center gap-2">
          <Bomb size={14} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-xs font-medium">Minesweeper</span>
        </div>
        <div className="flex items-center gap-2">
          {(['beginner', 'intermediate', 'expert'] as Difficulty[]).map((d) => (
            <button
              key={d}
              onClick={() => { setDifficulty(d); }}
              className="px-2 py-0.5 rounded text-[10px] capitalize transition-colors"
              style={{
                background: difficulty === d ? 'var(--accent-gold)' : 'var(--surface)',
                color: difficulty === d ? 'var(--void)' : 'var(--text-secondary)',
              }}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      {/* HUD */}
      <div className="flex items-center gap-4 mb-2">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-sm" style={{ background: 'var(--surface)', color: 'var(--danger)' }}>
          <Flag size={14} /> {(mines - flags).toString().padStart(3, '0')}
        </div>
        <button
          onClick={resetGame}
          className="w-9 h-9 rounded-full flex items-center justify-center text-lg transition-colors"
          style={{ background: 'var(--surface)', border: '2px solid var(--border-subtle)' }}
        >
          {gameState === 'won' ? '😎' : gameState === 'lost' ? '💥' : '😊'}
        </button>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-md font-mono text-sm" style={{ background: 'var(--surface)', color: 'var(--danger)' }}>
          <Clock size={14} /> {timer.toString().padStart(3, '0')}
        </div>
      </div>

      {/* Leaderboard */}
      {leaderboard[difficulty] && (
        <div className="flex items-center gap-1 mb-1 text-[10px]" style={{ color: 'var(--accent-gold)' }}>
          <Trophy size={10} /> Best: {leaderboard[difficulty]}s
        </div>
      )}

      {/* Board */}
      <div
        className="rounded-md overflow-hidden"
        style={{ border: '3px solid var(--border-subtle)', background: 'var(--border-subtle)' }}
      >
        <div className="grid gap-[1px]" style={{ gridTemplateColumns: `repeat(${cols}, ${cellSize}px)` }}>
          {board.flat().map((cell, i) => {
            const r = Math.floor(i / cols);
            const c = i % cols;
            return (
              <button
                key={i}
                onClick={() => {
                  if (cell.isRevealed && cell.neighborMines > 0) handleChord(r, c);
                  else handleClick(r, c);
                }}
                onContextMenu={(e) => handleRightClick(e, r, c)}
                onMouseDown={(e) => {
                  if (e.button === 0 && !cell.isRevealed && !cell.isFlagged && gameState === 'playing') {
                    // Could show worried face
                  }
                }}
                className="flex items-center justify-center font-mono font-bold text-xs transition-colors"
                style={{
                  width: cellSize,
                  height: cellSize,
                  background: cell.isRevealed
                    ? (cell.isMine ? 'var(--danger)' : 'var(--abyss)')
                    : 'var(--surface-elevated)',
                  color: cell.isRevealed && !cell.isMine && cell.neighborMines > 0
                    ? NUMBER_COLORS[cell.neighborMines]
                    : 'var(--text-primary)',
                  borderTop: cell.isRevealed ? '1px solid var(--border-subtle)' : '2px solid var(--border-active)',
                  borderLeft: cell.isRevealed ? '1px solid var(--border-subtle)' : '2px solid var(--border-active)',
                  borderBottom: cell.isRevealed ? 'none' : '2px solid var(--border-subtle)',
                  borderRight: cell.isRevealed ? 'none' : '2px solid var(--border-subtle)',
                  cursor: cell.isRevealed ? 'default' : 'pointer',
                }}
              >
                {cell.isFlagged && !cell.isRevealed && <Flag size={Math.max(10, cellSize - 14)} style={{ color: 'var(--danger)' }} />}
                {cell.isRevealed && cell.isMine && <Bomb size={Math.max(10, cellSize - 14)} />}
                {cell.isRevealed && !cell.isMine && cell.neighborMines > 0 && cell.neighborMines}
              </button>
            );
          })}
        </div>
      </div>

      {/* Win/Lose message */}
      {gameState === 'won' && (
        <div className="mt-2 px-4 py-1.5 rounded-md text-xs font-medium" style={{ background: 'rgba(90,158,111,0.15)', color: 'var(--success)', border: '1px solid var(--success)' }}>
          You Win! Time: {timer}s
        </div>
      )}
      {gameState === 'lost' && (
        <div className="mt-2 px-4 py-1.5 rounded-md text-xs font-medium" style={{ background: 'rgba(184,74,74,0.15)', color: 'var(--danger)', border: '1px solid var(--danger)' }}>
          Game Over! Click the smiley to retry.
        </div>
      )}

      {/* Instructions */}
      <div className="mt-2 text-[9px] text-center" style={{ color: 'var(--text-muted)' }}>
        Left click: reveal · Right click: flag · Click number: chord (if flags match)
      </div>
    </div>
  );
}
