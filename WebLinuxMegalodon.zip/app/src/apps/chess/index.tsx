import { useState, useEffect, useCallback, useRef } from 'react';
import { Crown, RotateCcw, Settings } from 'lucide-react';

type PieceType = 'p' | 'r' | 'n' | 'b' | 'q' | 'k';
type PieceColor = 'w' | 'b';
interface Piece { type: PieceType; color: PieceColor }

type Square = Piece | null;
type Board = Square[][];
type Position = [number, number];

const INITIAL_BOARD: Board = [
  [{ type: 'r', color: 'b' }, { type: 'n', color: 'b' }, { type: 'b', color: 'b' }, { type: 'q', color: 'b' }, { type: 'k', color: 'b' }, { type: 'b', color: 'b' }, { type: 'n', color: 'b' }, { type: 'r', color: 'b' }],
  [{ type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [{ type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }],
  [{ type: 'r', color: 'w' }, { type: 'n', color: 'w' }, { type: 'b', color: 'w' }, { type: 'q', color: 'w' }, { type: 'k', color: 'w' }, { type: 'b', color: 'w' }, { type: 'n', color: 'w' }, { type: 'r', color: 'w' }],
];

const PIECE_SYMBOLS: Record<string, string> = {
  'pw': '♙', 'rw': '♖', 'nw': '♘', 'bw': '♗', 'qw': '♕', 'kw': '♔',
  'pb': '♟', 'rb': '♜', 'nb': '♞', 'bb': '♝', 'qb': '♛', 'kb': '♚',
};

const PIECE_VALUES: Record<PieceType, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

const POSITION_BONUS: Record<PieceType, number[][]> = {
  p: [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [50, 50, 50, 50, 50, 50, 50, 50],
    [10, 10, 20, 30, 30, 20, 10, 10],
    [5, 5, 10, 25, 25, 10, 5, 5],
    [0, 0, 0, 20, 20, 0, 0, 0],
    [5, -5, -10, 0, 0, -10, -5, 5],
    [5, 10, 10, -20, -20, 10, 10, 5],
    [0, 0, 0, 0, 0, 0, 0, 0],
  ],
  n: [
    [-50, -40, -30, -30, -30, -30, -40, -50],
    [-40, -20, 0, 0, 0, 0, -20, -40],
    [-30, 0, 10, 15, 15, 10, 0, -30],
    [-30, 5, 15, 20, 20, 15, 5, -30],
    [-30, 0, 15, 20, 20, 15, 0, -30],
    [-30, 5, 10, 15, 15, 10, 5, -30],
    [-40, -20, 0, 5, 5, 0, -20, -40],
    [-50, -40, -30, -30, -30, -30, -40, -50],
  ],
  b: [
    [-20, -10, -10, -10, -10, -10, -10, -20],
    [-10, 0, 0, 0, 0, 0, 0, -10],
    [-10, 0, 10, 10, 10, 10, 0, -10],
    [-10, 5, 5, 10, 10, 5, 5, -10],
    [-10, 0, 5, 10, 10, 5, 0, -10],
    [-10, 10, 10, 10, 10, 10, 10, -10],
    [-10, 5, 0, 0, 0, 0, 5, -10],
    [-20, -10, -10, -10, -10, -10, -10, -20],
  ],
  r: [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [5, 10, 10, 10, 10, 10, 10, 5],
    [-5, 0, 0, 0, 0, 0, 0, -5],
    [-5, 0, 0, 0, 0, 0, 0, -5],
    [-5, 0, 0, 0, 0, 0, 0, -5],
    [-5, 0, 0, 0, 0, 0, 0, -5],
    [-5, 0, 0, 0, 0, 0, 0, -5],
    [0, 0, 0, 5, 5, 0, 0, 0],
  ],
  q: [
    [-20, -10, -10, -5, -5, -10, -10, -20],
    [-10, 0, 0, 0, 0, 0, 0, -10],
    [-10, 0, 5, 5, 5, 5, 0, -10],
    [-5, 0, 5, 5, 5, 5, 0, -5],
    [0, 0, 5, 5, 5, 5, 0, -5],
    [-10, 5, 5, 5, 5, 5, 0, -10],
    [-10, 0, 5, 0, 0, 0, 0, -10],
    [-20, -10, -10, -5, -5, -10, -10, -20],
  ],
  k: [
    [-30, -40, -40, -50, -50, -40, -40, -30],
    [-30, -40, -40, -50, -50, -40, -40, -30],
    [-30, -40, -40, -50, -50, -40, -40, -30],
    [-30, -40, -40, -50, -50, -40, -40, -30],
    [-20, -30, -30, -40, -40, -30, -30, -20],
    [-10, -20, -20, -20, -20, -20, -20, -10],
    [20, 20, 0, 0, 0, 0, 20, 20],
    [20, 30, 10, 0, 0, 10, 30, 20],
  ],
};

function cloneBoard(b: Board): Board {
  return b.map((row) => row.map((cell) => (cell ? { ...cell } : null)));
}

function findKing(board: Board, color: PieceColor): Position | null {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p && p.type === 'k' && p.color === color) return [r, c];
    }
  }
  return null;
}

function isSquareAttacked(board: Board, row: number, col: number, byColor: PieceColor): boolean {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p || p.color !== byColor) continue;
      const moves = getRawMoves(board, r, c, true);
      if (moves.some(([mr, mc]) => mr === row && mc === col)) return true;
    }
  }
  return false;
}

function isInCheck(board: Board, color: PieceColor): boolean {
  const king = findKing(board, color);
  if (!king) return false;
  return isSquareAttacked(board, king[0], king[1], color === 'w' ? 'b' : 'w');
}

function getRawMoves(board: Board, row: number, col: number, skipCheck: boolean = false): Position[] {
  const piece = board[row][col];
  if (!piece) return [];
  const moves: Position[] = [];
  const { type, color } = piece;

  const addIfValid = (r: number, c: number, captureOnly = false) => {
    if (r < 0 || r >= 8 || c < 0 || c >= 8) return false;
    const target = board[r][c];
    if (!captureOnly && !target) { moves.push([r, c]); return true; }
    if (target && target.color !== color) { moves.push([r, c]); return false; }
    return false;
  };

  const rayDirections: [number, number][] = [];

  switch (type) {
    case 'p': {
      const dir = color === 'w' ? -1 : 1;
      const startRow = color === 'w' ? 6 : 1;
      if (row + dir >= 0 && row + dir < 8 && !board[row + dir][col]) {
        moves.push([row + dir, col]);
        if (row === startRow && !board[row + 2 * dir][col]) moves.push([row + 2 * dir, col]);
      }
      for (const dc of [-1, 1]) {
        const nc = col + dc;
        if (nc >= 0 && nc < 8) {
          const target = board[row + dir]?.[nc];
          if (target && target.color !== color) moves.push([row + dir, nc]);
        }
      }
      break;
    }
    case 'n': {
      const jumps: [number, number][] = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
      for (const [dr, dc] of jumps) addIfValid(row + dr, col + dc);
      break;
    }
    case 'k': {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          addIfValid(row + dr, col + dc);
        }
      }
      // Castling
      if (!skipCheck && !isInCheck(board, color)) {
        if (canCastle(board, row, col, color, 'kingside')) moves.push([row, col + 2]);
        if (canCastle(board, row, col, color, 'queenside')) moves.push([row, col - 2]);
      }
      break;
    }
    case 'r':
      rayDirections.push([-1,0],[1,0],[0,-1],[0,1]);
      break;
    case 'b':
      rayDirections.push([-1,-1],[-1,1],[1,-1],[1,1]);
      break;
    case 'q':
      rayDirections.push([-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]);
      break;
  }

  for (const [dr, dc] of rayDirections) {
    for (let i = 1; i < 8; i++) {
      const r = row + dr * i;
      const c = col + dc * i;
      if (r < 0 || r >= 8 || c < 0 || c >= 8) break;
      const target = board[r][c];
      if (!target) { moves.push([r, c]); }
      else { if (target.color !== color) moves.push([r, c]); break; }
    }
  }

  return moves;
}

function canCastle(board: Board, row: number, col: number, color: PieceColor, side: 'kingside' | 'queenside'): boolean {
  const isKingside = side === 'kingside';
  const rookCol = isKingside ? 7 : 0;
  const rook = board[row][rookCol];
  if (!rook || rook.type !== 'r' || rook.color !== color) return false;
  // Check squares between are empty
  const step = isKingside ? 1 : -1;
  for (let c = col + step; c !== rookCol; c += step) {
    if (board[row][c]) return false;
  }
  // Check king doesn't pass through check
  for (let c = col; c !== col + 2 * step + step; c += step) {
    if (c === col) continue;
    if (isSquareAttacked(board, row, c, color === 'w' ? 'b' : 'w')) return false;
  }
  return true;
}

function getLegalMoves(board: Board, row: number, col: number): Position[] {
  const piece = board[row][col];
  if (!piece) return [];
  const rawMoves = getRawMoves(board, row, col);
  return rawMoves.filter(([nr, nc]) => {
    const testBoard = cloneBoard(board);
    testBoard[nr][nc] = testBoard[row][col];
    testBoard[row][col] = null;
    // Handle castling
    if (piece.type === 'k' && Math.abs(nc - col) === 2) {
      const isKingside = nc > col;
      testBoard[nr][isKingside ? 5 : 3] = testBoard[nr][isKingside ? 7 : 0];
      testBoard[nr][isKingside ? 7 : 0] = null;
    }
    return !isInCheck(testBoard, piece.color);
  });
}

function evaluateBoard(board: Board): number {
  let score = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) continue;
      const val = PIECE_VALUES[p.type] * 100;
      const pos = p.color === 'w' ? POSITION_BONUS[p.type][r][c] : POSITION_BONUS[p.type][7 - r][c];
      score += p.color === 'w' ? val + pos : -(val + pos);
    }
  }
  return score;
}

function minimax(board: Board, depth: number, alpha: number, beta: number, isMaximizing: boolean): number {
  if (depth === 0) return evaluateBoard(board);

  const color = isMaximizing ? 'w' : 'b';
  let hasMove = false;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p || p.color !== color) continue;
      const moves = getLegalMoves(board, r, c);
      for (const [nr, nc] of moves) {
        hasMove = true;
        const testBoard = cloneBoard(board);
        testBoard[nr][nc] = testBoard[r][c];
        testBoard[r][c] = null;
        // Promotion
        if (testBoard[nr][nc]?.type === 'p' && (nr === 0 || nr === 7)) {
          testBoard[nr][nc] = { type: 'q', color };
        }
        const score = minimax(testBoard, depth - 1, alpha, beta, !isMaximizing);
        if (isMaximizing) alpha = Math.max(alpha, score);
        else beta = Math.min(beta, score);
        if (beta <= alpha) return isMaximizing ? alpha : beta;
      }
    }
  }

  if (!hasMove) {
    if (isInCheck(board, color)) return isMaximizing ? -100000 : 100000;
    return 0;
  }
  return isMaximizing ? alpha : beta;
}

function getAIMove(board: Board, depth: number): { from: Position; to: Position } | null {
  let bestMove: { from: Position; to: Position } | null = null;
  let bestScore = -Infinity;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p || p.color !== 'b') continue;
      const moves = getLegalMoves(board, r, c);
      for (const [nr, nc] of moves) {
        const testBoard = cloneBoard(board);
        testBoard[nr][nc] = testBoard[r][c];
        testBoard[r][c] = null;
        if (testBoard[nr][nc]?.type === 'p' && nr === 7) testBoard[nr][nc] = { type: 'q', color: 'b' };
        const score = minimax(testBoard, depth - 1, -Infinity, Infinity, true);
        if (score > bestScore) {
          bestScore = score;
          bestMove = { from: [r, c], to: [nr, nc] };
        }
      }
    }
  }
  return bestMove;
}

const FILES = 'abcdefgh';
const RANKS = '87654321';

function toNotation(from: Position, to: Position, piece: Piece, capture: boolean): string {
  const file1 = FILES[from[1]];
  const file2 = FILES[to[1]];
  const rank2 = RANKS[to[0]];
  let notation = '';
  if (piece.type !== 'p') notation += piece.type.toUpperCase();
  if (capture) {
    if (piece.type === 'p') notation += file1;
    notation += 'x';
  }
  notation += file2 + rank2;
  return notation;
}

export default function Chess() {
  const [board, setBoard] = useState<Board>(() => cloneBoard(INITIAL_BOARD));
  const [turn, setTurn] = useState<'w' | 'b'>('w');
  const [selected, setSelected] = useState<Position | null>(null);
  const [validMoves, setValidMoves] = useState<Position[]>([]);
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  const [captured, setCaptured] = useState<Piece[]>([]);
  const [gameStatus, setGameStatus] = useState<'playing' | 'checkmate' | 'stalemate' | 'check'>('playing');
  const [difficulty, setDifficulty] = useState(2);
  const [aiThinking, setAiThinking] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [lastMove, setLastMove] = useState<{ from: Position; to: Position } | null>(null);

  const boardRef = useRef(board);
  boardRef.current = board;

  const checkGameStatus = useCallback((b: Board, color: 'w' | 'b') => {
    let hasMoves = false;
    for (let r = 0; r < 8 && !hasMoves; r++) {
      for (let c = 0; c < 8 && !hasMoves; c++) {
        const p = b[r][c];
        if (p && p.color === color && getLegalMoves(b, r, c).length > 0) hasMoves = true;
      }
    }
    if (!hasMoves) {
      if (isInCheck(b, color)) return 'checkmate';
      return 'stalemate';
    }
    if (isInCheck(b, color)) return 'check';
    return 'playing';
  }, []);

  const makeMove = useCallback((from: Position, to: Position, currentBoard?: Board) => {
    const b = currentBoard || boardRef.current;
    const piece = b[from[0]][from[1]];
    if (!piece) return;
    const target = b[to[0]][to[1]];
    const newBoard = cloneBoard(b);

    newBoard[to[0]][to[1]] = newBoard[from[0]][from[1]];
    newBoard[from[0]][from[1]] = null;

    // Handle castling
    if (piece.type === 'k' && Math.abs(to[1] - from[1]) === 2) {
      const isKingside = to[1] > from[1];
      const rookFrom = isKingside ? 7 : 0;
      const rookTo = isKingside ? 5 : 3;
      newBoard[to[0]][rookTo] = newBoard[to[0]][rookFrom];
      newBoard[to[0]][rookFrom] = null;
    }

    // Pawn promotion
    if (piece.type === 'p' && (to[0] === 0 || to[0] === 7)) {
      newBoard[to[0]][to[1]] = { type: 'q', color: piece.color };
    }

    if (target) setCaptured((prev) => [...prev, target]);

    const notation = toNotation(from, to, piece, !!target);
    setMoveHistory((prev) => [...prev, notation]);
    setLastMove({ from, to });
    setBoard(newBoard);
    boardRef.current = newBoard;

    const nextTurn = piece.color === 'w' ? 'b' : 'w';
    setTurn(nextTurn);

    const status = checkGameStatus(newBoard, nextTurn);
    setGameStatus(status);
    return status;
  }, [checkGameStatus]);

  // AI Move
  useEffect(() => {
    if (turn !== 'b' || gameStatus !== 'playing') return;
    setAiThinking(true);
    const timer = setTimeout(() => {
      const move = getAIMove(boardRef.current, difficulty + 1);
      if (move) {
        makeMove(move.from, move.to);
      }
      setAiThinking(false);
    }, 500);
    return () => clearTimeout(timer);
  }, [turn, gameStatus, difficulty, makeMove]);

  const handleSquareClick = (row: number, col: number) => {
    if (gameStatus === 'checkmate' || gameStatus === 'stalemate') return;
    if (turn !== 'w' || aiThinking) return;

    const piece = board[row][col];

    if (selected) {
      const isValid = validMoves.some(([r, c]) => r === row && c === col);
      if (isValid) {
        const newStatus = makeMove(selected, [row, col]);
        if (newStatus !== 'playing') return;
      }
      setSelected(null);
      setValidMoves([]);
      return;
    }

    if (piece && piece.color === 'w') {
      setSelected([row, col]);
      setValidMoves(getLegalMoves(board, row, col));
    }
  };

  const resetGame = () => {
    const newBoard = cloneBoard(INITIAL_BOARD);
    setBoard(newBoard);
    boardRef.current = newBoard;
    setTurn('w');
    setSelected(null);
    setValidMoves([]);
    setMoveHistory([]);
    setCaptured([]);
    setGameStatus('playing');
    setLastMove(null);
  };



  const cellSize = 52;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center select-none" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Top bar */}
      <div className="flex items-center gap-3 mb-1">
        <div className="flex items-center gap-1.5">
          <Crown size={14} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-xs font-medium">Chess</span>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full" style={{
          background: gameStatus === 'check' ? 'rgba(184,74,74,0.15)' : gameStatus === 'checkmate' ? 'rgba(184,74,74,0.2)' : 'var(--surface-elevated)',
          color: gameStatus === 'check' || gameStatus === 'checkmate' ? 'var(--danger)' : turn === 'w' ? 'var(--text-primary)' : 'var(--text-secondary)',
        }}>
          {gameStatus === 'checkmate' ? 'Checkmate!' : gameStatus === 'stalemate' ? 'Stalemate' : gameStatus === 'check' ? 'Check!' : turn === 'w' ? 'Your Move' : aiThinking ? 'AI Thinking...' : 'AI Move'}
        </span>
        <button onClick={resetGame} className="p-1 rounded hover:bg-[#222235]" style={{ color: 'var(--text-secondary)' }}><RotateCcw size={12} /></button>
        <button onClick={() => setShowSettings((v) => !v)} className="p-1 rounded hover:bg-[#222235]" style={{ color: 'var(--text-secondary)' }}><Settings size={12} /></button>
      </div>

      {showSettings && (
        <div className="flex items-center gap-2 mb-2 px-3 py-1.5 rounded-md text-[10px]" style={{ background: 'var(--surface)' }}>
          <span style={{ color: 'var(--text-muted)' }}>AI Level:</span>
          {[{ l: 1, n: 'Easy' }, { l: 2, n: 'Medium' }, { l: 3, n: 'Hard' }].map((d) => (
            <button
              key={d.l}
              onClick={() => { setDifficulty(d.l); setShowSettings(false); resetGame(); }}
              className="px-2 py-0.5 rounded transition-colors"
              style={{ background: difficulty === d.l ? 'var(--accent-gold)' : 'var(--surface-elevated)', color: difficulty === d.l ? 'var(--void)' : 'var(--text-secondary)' }}
            >
              {d.n}
            </button>
          ))}
        </div>
      )}

      <div className="flex gap-3">
        {/* Board */}
        <div className="relative">
          {/* Rank labels */}
          <div className="absolute -left-4 top-0 flex flex-col justify-around h-full text-[9px]" style={{ color: 'var(--text-muted)' }}>
            {RANKS.split('').map((r) => <span key={r} className="leading-none">{r}</span>)}
          </div>
          {/* File labels */}
          <div className="absolute -bottom-4 left-0 flex justify-around w-full text-[9px]" style={{ color: 'var(--text-muted)' }}>
            {FILES.split('').map((f) => <span key={f}>{f}</span>)}
          </div>

          <div style={{ border: '2px solid var(--border-subtle)', borderRadius: '2px' }}>
            <div className="grid" style={{ gridTemplateColumns: `repeat(8, ${cellSize}px)`, gridTemplateRows: `repeat(8, ${cellSize}px)` }}>
              {Array.from({ length: 64 }).map((_, i) => {
                const row = Math.floor(i / 8);
                const col = i % 8;
                const isLight = (row + col) % 2 === 0;
                const piece = board[row][col];
                const isSelected = selected?.[0] === row && selected?.[1] === col;
                const isValidMove = validMoves.some(([r, c]) => r === row && c === col);
                const isLastFrom = lastMove?.from[0] === row && lastMove?.from[1] === col;
                const isLastTo = lastMove?.to[0] === row && lastMove?.to[1] === col;

                return (
                  <button
                    key={i}
                    onClick={() => handleSquareClick(row, col)}
                    className="flex items-center justify-center relative"
                    style={{
                      width: cellSize,
                      height: cellSize,
                      background: isSelected
                        ? 'rgba(201,168,76,0.5)'
                        : isLastFrom || isLastTo
                          ? 'rgba(90,138,184,0.3)'
                          : isLight ? '#B58863' : '#F0D9B5',
                    }}
                  >
                    {isValidMove && !piece && (
                      <div className="w-3 h-3 rounded-full" style={{ background: 'rgba(201,168,76,0.5)' }} />
                    )}
                    {isValidMove && piece && (
                      <div className="absolute inset-0 rounded-full" style={{ border: '3px solid rgba(201,168,76,0.5)' }} />
                    )}
                    {piece && (
                      <span
                        className="text-3xl leading-none"
                        style={{
                          color: piece.color === 'w' ? '#F0D9B5' : '#4A3728',
                          textShadow: piece.color === 'w' ? '0 1px 2px rgba(0,0,0,0.5)' : '0 1px 2px rgba(255,255,255,0.3)',
                          filter: piece.color === 'b' ? 'drop-shadow(0 0 1px rgba(255,255,255,0.3))' : 'none',
                        }}
                      >
                        {PIECE_SYMBOLS[piece.type + piece.color]}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Side panel */}
        <div className="flex flex-col gap-2 w-24">
          {/* Captured */}
          <div className="p-2 rounded-md" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)' }}>
            <div className="text-[9px] mb-1" style={{ color: 'var(--text-muted)' }}>Captured</div>
            <div className="flex flex-wrap gap-0.5">
              {captured.filter((p) => p.color === 'b').map((p, i) => (
                <span key={i} className="text-sm" style={{ color: '#F0D9B5' }}>{PIECE_SYMBOLS[p.type + p.color]}</span>
              ))}
            </div>
            <div className="flex flex-wrap gap-0.5 mt-1">
              {captured.filter((p) => p.color === 'w').map((p, i) => (
                <span key={i} className="text-sm" style={{ color: '#4A3728' }}>{PIECE_SYMBOLS[p.type + p.color]}</span>
              ))}
            </div>
          </div>

          {/* Move history */}
          <div className="flex-1 p-2 rounded-md overflow-y-auto max-h-40" style={{ background: 'var(--surface)', border: '1px solid var(--border-subtle)' }}>
            <div className="text-[9px] mb-1" style={{ color: 'var(--text-muted)' }}>Moves</div>
            {moveHistory.map((m, i) => (
              <div key={i} className="text-[10px] font-mono" style={{ color: i % 2 === 0 ? 'var(--text-primary)' : 'var(--text-secondary)' }}>
                {Math.floor(i / 2) + 1}.{i % 2 === 0 ? '' : ''} {m}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
