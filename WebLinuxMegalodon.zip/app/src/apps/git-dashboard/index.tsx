import { useState, useCallback, useMemo } from 'react';
import {
  GitBranch, GitCommit,
  FileDiff, Plus, Minus, Tag, Copy, Check, Search
} from 'lucide-react';

/* ── simulated git data ── */
interface Commit {
  hash: string;
  shortHash: string;
  message: string;
  author: string;
  avatar: string;
  date: string;
  branch?: string;
  parents: string[];
  additions: number;
  deletions: number;
  filesChanged: number;
}

const AUTHORS = [
  { name: 'Elias Cornwell', color: '#C9A84C' },
  { name: 'Sarah Mitchell', color: '#5A8AB8' },
  { name: 'David Chen', color: '#5A9E6F' },
  { name: 'Maria Santos', color: '#7B6FB8' },
  { name: 'James Wright', color: '#D4953A' },
];

const COMMITS: Commit[] = [
  { hash: 'a1b2c3d', shortHash: 'a1b2c3d', message: 'Initial commit — Cornstone OS scaffolding', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-02', parents: [], additions: 1247, deletions: 0, filesChanged: 42, branch: 'main' },
  { hash: 'e4f5g6h', shortHash: 'e4f5g6h', message: 'Add project structure and build config', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-03', parents: ['a1b2c3d'], additions: 856, deletions: 12, filesChanged: 28, branch: 'main' },
  { hash: 'i7j8k9l', shortHash: 'i7j8k9l', message: 'Implement window manager with z-index stacking', author: 'Sarah Mitchell', avatar: '#5A8AB8', date: '2025-01-05', parents: ['e4f5g6h'], additions: 1432, deletions: 89, filesChanged: 35, branch: 'main' },
  { hash: 'm0n1o2p', shortHash: 'm0n1o2p', message: 'Add desktop environment and taskbar', author: 'David Chen', avatar: '#5A9E6F', date: '2025-01-07', parents: ['i7j8k9l'], additions: 2103, deletions: 156, filesChanged: 48, branch: 'main' },
  { hash: 'q3r4s5t', shortHash: 'q3r4s5t', message: 'Create login screen with animated background', author: 'Maria Santos', avatar: '#7B6FB8', date: '2025-01-08', parents: ['m0n1o2p'], additions: 967, deletions: 34, filesChanged: 22, branch: 'main' },
  { hash: 'u6v7w8x', shortHash: 'u6v7w8x', message: 'Add boot sequence with typewriter effect', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-10', parents: ['q3r4s5t'], additions: 534, deletions: 23, filesChanged: 14, branch: 'main' },
  { hash: 'y9z0a1b', shortHash: 'y9z0a1b', message: 'Implement 3D Star-Map with Three.js', author: 'Sarah Mitchell', avatar: '#5A8AB8', date: '2025-01-12', parents: ['u6v7w8x'], additions: 3421, deletions: 0, filesChanged: 67, branch: 'feature/star-map' },
  { hash: 'c2d3e4f', shortHash: 'c2d3e4f', message: 'Add Star-Map bloom and post-processing', author: 'Sarah Mitchell', avatar: '#5A8AB8', date: '2025-01-13', parents: ['y9z0a1b'], additions: 892, deletions: 45, filesChanged: 18, branch: 'feature/star-map' },
  { hash: 'g5h6i7j', shortHash: 'g5h6i7j', message: 'Optimize Star-Map performance', author: 'David Chen', avatar: '#5A9E6F', date: '2025-01-14', parents: ['c2d3e4f'], additions: 234, deletions: 567, filesChanged: 12, branch: 'feature/star-map' },
  { hash: 'k8l9m0n', shortHash: 'k8l9m0n', message: 'Merge feature/star-map into main', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-15', parents: ['u6v7w8x', 'g5h6i7j'], additions: 0, deletions: 0, filesChanged: 0, branch: 'main' },
  { hash: 'o1p2q3r', shortHash: 'o1p2q3r', message: 'Add Megalodon CostOS engine v3.1', author: 'James Wright', avatar: '#D4953A', date: '2025-01-16', parents: ['k8l9m0n'], additions: 5432, deletions: 0, filesChanged: 89, branch: 'main' },
  { hash: 's4t5u6v', shortHash: 's4t5u6v', message: 'Implement deterministic validation engine', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-18', parents: ['o1p2q3r'], additions: 1234, deletions: 89, filesChanged: 31, branch: 'main' },
  { hash: 'w7x8y9z', shortHash: 'w7x8y9z', message: 'Add Monte Carlo risk simulation (10k iterations)', author: 'James Wright', avatar: '#D4953A', date: '2025-01-20', parents: ['s4t5u6v'], additions: 2156, deletions: 123, filesChanged: 42, branch: 'main' },
  { hash: 'a0b1c2d', shortHash: 'a0b1c2d', message: 'Create user authentication system', author: 'Maria Santos', avatar: '#7B6FB8', date: '2025-01-21', parents: ['s4t5u6v'], additions: 1876, deletions: 0, filesChanged: 34, branch: 'feature/login' },
  { hash: 'e3f4g5h', shortHash: 'e3f4g5h', message: 'Add JWT token handling and session management', author: 'David Chen', avatar: '#5A9E6F', date: '2025-01-22', parents: ['a0b1c2d'], additions: 934, deletions: 45, filesChanged: 21, branch: 'feature/login' },
  { hash: 'i6j7k8l', shortHash: 'i6j7k8l', message: 'Merge feature/login into main', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-23', parents: ['w7x8y9z', 'e3f4g5h'], additions: 0, deletions: 0, filesChanged: 0, branch: 'main' },
  { hash: 'm9n0o1p', shortHash: 'm9n0o1p', message: 'Add 50+ application suite', author: 'Sarah Mitchell', avatar: '#5A8AB8', date: '2025-01-25', parents: ['i6j7k8l'], additions: 12543, deletions: 234, filesChanged: 312, branch: 'main' },
  { hash: 'q2r3s4t', shortHash: 'q2r3s4t', message: 'Update Mexican labor calendar 2026', author: 'Maria Santos', avatar: '#7B6FB8', date: '2025-01-26', parents: ['m9n0o1p'], additions: 456, deletions: 123, filesChanged: 15, branch: 'main' },
  { hash: 'u5v6w7x', shortHash: 'u5v6w7x', message: 'Fix BIM quantification edge cases', author: 'James Wright', avatar: '#D4953A', date: '2025-01-27', parents: ['q2r3s4t'], additions: 187, deletions: 56, filesChanged: 8, branch: 'fix/validation' },
  { hash: 'y8z9a0b', shortHash: 'y8z9a0b', message: 'Add unit tests for CostOS engine', author: 'David Chen', avatar: '#5A9E6F', date: '2025-01-28', parents: ['u5v6w7x'], additions: 2345, deletions: 0, filesChanged: 45, branch: 'fix/validation' },
  { hash: 'c1d2e3f', shortHash: 'c1d2e3f', message: 'Final validation and testing', author: 'Elias Cornwell', avatar: '#C9A84C', date: '2025-01-30', parents: ['y8z9a0b', 'm9n0o1p'], additions: 567, deletions: 123, filesChanged: 23, branch: 'main' },
];

const BRANCHES = [
  { name: 'main', color: '#C9A84C' },
  { name: 'feature/star-map', color: '#5A8AB8' },
  { name: 'feature/login', color: '#7B6FB8' },
  { name: 'fix/validation', color: '#D4953A' },
];

export default function GitDashboard() {
  const [selectedCommit, setSelectedCommit] = useState<Commit | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBranch, setFilterBranch] = useState('all');
  const [copied, setCopied] = useState(false);

  const filteredCommits = useMemo(() => {
    return COMMITS.filter(c => {
      if (filterBranch !== 'all' && c.branch !== filterBranch && !c.parents.some(p => COMMITS.find(cc => cc.hash === p)?.branch === filterBranch)) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return c.message.toLowerCase().includes(q) || c.hash.includes(q) || c.author.toLowerCase().includes(q);
      }
      return true;
    });
  }, [searchQuery, filterBranch]);

  const contributors = useMemo(() => {
    const map = new Map<string, { count: number; color: string }>();
    COMMITS.forEach(c => {
      const existing = map.get(c.author);
      if (existing) existing.count++;
      else map.set(c.author, { count: 1, color: AUTHORS.find(a => a.name === c.author)?.color || '#8A8578' });
    });
    return Array.from(map.entries()).sort((a, b) => b[1].count - a[1].count);
  }, []);

  const stats = useMemo(() => {
    const totalAdditions = COMMITS.reduce((s, c) => s + c.additions, 0);
    const totalDeletions = COMMITS.reduce((s, c) => s + c.deletions, 0);
    return { commits: COMMITS.length, branches: BRANCHES.length, tags: 3, additions: totalAdditions, deletions: totalDeletions };
  }, []);

  const copyHash = useCallback(async (hash: string) => {
    try { await navigator.clipboard.writeText(hash); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* noop */ }
  }, []);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Header */}
      <div className="flex items-center gap-3 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        <GitBranch className="w-4 h-4 text-[#C9A84C]" />
        <span className="font-medium text-sm">cornstone-app</span>
        <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#C9A84C]/10 text-[#C9A84C]">
          <GitBranch className="w-3 h-3" /> main
        </div>
        <div className="flex-1" />
        <div className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A1A26] border border-[#2A2A3E]">
          <Search className="w-3 h-3 text-[#4D4A42]" />
          <input
            type="text"
            className="bg-transparent outline-none text-xs w-32 placeholder-[#4D4A42]"
            placeholder="Search commits..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Main content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Stats bar */}
          <div className="flex items-center gap-4 px-3 py-2 border-b border-[#2A2A3E] shrink-0">
            <div className="flex items-center gap-1.5">
              <GitCommit className="w-3.5 h-3.5 text-[#8A8578]" />
              <span className="text-[#8A8578]">{stats.commits} commits</span>
            </div>
            <div className="flex items-center gap-1.5">
              <GitBranch className="w-3.5 h-3.5 text-[#8A8578]" />
              <span className="text-[#8A8578]">{stats.branches} branches</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-[#8A8578]" />
              <span className="text-[#8A8578]">{stats.tags} tags</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-[#5A9E6F]" />
              <span className="text-[#5A9E6F]">{stats.additions.toLocaleString()}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Minus className="w-3.5 h-3.5 text-[#B84A4A]" />
              <span className="text-[#B84A4A]">{stats.deletions.toLocaleString()}</span>
            </div>
            <div className="flex-1" />
            <select
              className="bg-[#1A1A26] border border-[#2A2A3E] rounded px-2 py-1 text-xs outline-none"
              value={filterBranch}
              onChange={e => setFilterBranch(e.target.value)}
            >
              <option value="all">All branches</option>
              {BRANCHES.map(b => <option key={b.name} value={b.name}>{b.name}</option>)}
            </select>
          </div>

          {/* Branch visualization */}
          <div className="shrink-0 overflow-x-auto border-b border-[#2A2A3E] bg-[#0A0A0F] px-3 py-2">
            <div className="flex items-center gap-1 mb-2">
              {BRANCHES.map(b => (
                <div key={b.name} className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px]" style={{ background: `${b.color}15`, color: b.color }}>
                  <GitBranch className="w-2.5 h-2.5" /> {b.name}
                </div>
              ))}
            </div>
            {/* Simplified branch graph */}
            <svg viewBox="0 0 840 60" className="w-full min-w-[600px] h-14">
              {/* Branch lines */}
              {BRANCHES.map((b, i) => (
                <line
                  key={b.name}
                  x1="10" y1={15 + i * 12}
                  x2="830" y2={15 + i * 12}
                  stroke={b.color}
                  strokeWidth="1.5"
                  strokeOpacity="0.3"
                />
              ))}
              {/* Commit dots on main */}
              {COMMITS.filter(c => c.branch === 'main').map((c, i) => {
                const x = 20 + (i / 12) * 780;
                return (
                  <g key={c.hash}>
                    <circle cx={x} cy="15" r="5" fill="#C9A84C" stroke="#030305" strokeWidth="1.5"
                      className="cursor-pointer hover:r-6"
                      onClick={() => setSelectedCommit(c)}
                    />
                    {i > 0 && (
                      <line x1={x - 65} y1="15" x2={x - 5} y2="15" stroke="#C9A84C" strokeWidth="1.5" strokeOpacity="0.5" />
                    )}
                  </g>
                );
              })}
              {/* Feature branch dots */}
              {COMMITS.filter(c => c.branch === 'feature/star-map').map((c, i) => {
                const x = 220 + i * 70;
                return (
                  <g key={c.hash}>
                    <circle cx={x} cy="27" r="5" fill="#5A8AB8" stroke="#030305" strokeWidth="1.5"
                      className="cursor-pointer"
                      onClick={() => setSelectedCommit(c)}
                    />
                    {i === 0 && (
                      <path d={`M 130 15 Q ${x - 35} 15 ${x - 5} 27`} stroke="#C9A84C" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
                    )}
                    {i > 0 && (
                      <line x1={x - 70} y1="27" x2={x - 5} y2="27" stroke="#5A8AB8" strokeWidth="1.5" strokeOpacity="0.5" />
                    )}
                    {i === 2 && (
                      <path d={`M ${x + 5} 27 Q ${x + 35} 27 490 15`} stroke="#5A8AB8" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
                    )}
                  </g>
                );
              })}
              {/* Feature login branch */}
              {COMMITS.filter(c => c.branch === 'feature/login').map((c, i) => {
                const x = 340 + i * 70;
                return (
                  <g key={c.hash}>
                    <circle cx={x} cy="39" r="5" fill="#7B6FB8" stroke="#030305" strokeWidth="1.5"
                      className="cursor-pointer"
                      onClick={() => setSelectedCommit(c)}
                    />
                    {i === 0 && (
                      <path d={`M 260 15 Q ${x - 35} 15 ${x - 5} 39`} stroke="#C9A84C" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
                    )}
                    {i > 0 && (
                      <line x1={x - 70} y1="39" x2={x - 5} y2="39" stroke="#7B6FB8" strokeWidth="1.5" strokeOpacity="0.5" />
                    )}
                    {i === 1 && (
                      <path d={`M ${x + 5} 39 Q ${x + 35} 39 630 15`} stroke="#7B6FB8" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
                    )}
                  </g>
                );
              })}
              {/* Fix branch */}
              {COMMITS.filter(c => c.branch === 'fix/validation').map((c, i) => {
                const x = 550 + i * 70;
                return (
                  <g key={c.hash}>
                    <circle cx={x} cy="51" r="5" fill="#D4953A" stroke="#030305" strokeWidth="1.5"
                      className="cursor-pointer"
                      onClick={() => setSelectedCommit(c)}
                    />
                    {i === 0 && (
                      <path d={`M 540 15 Q ${x - 35} 15 ${x - 5} 51`} stroke="#C9A84C" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
                    )}
                    {i > 0 && (
                      <line x1={x - 70} y1="51" x2={x - 5} y2="51" stroke="#D4953A" strokeWidth="1.5" strokeOpacity="0.5" />
                    )}
                    {i === 1 && (
                      <path d={`M ${x + 5} 51 Q ${x + 40} 51 810 15`} stroke="#D4953A" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Commit list */}
          <div className="flex-1 overflow-y-auto">
            {filteredCommits.map(commit => (
              <div
                key={commit.hash}
                className={`flex items-center gap-3 px-3 py-2 border-b border-[#2A2A3E]/50 cursor-pointer transition-colors ${
                  selectedCommit?.hash === commit.hash ? 'bg-[#222235] border-l-2 border-l-[#C9A84C]' : 'hover:bg-[#1A1A26] border-l-2 border-l-transparent'
                }`}
                onClick={() => setSelectedCommit(commit)}
              >
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 font-bold text-[10px]"
                  style={{ background: `${commit.avatar}30`, color: commit.avatar }}
                >
                  {commit.author[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="truncate text-xs">{commit.message}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-[#8A8578]">{commit.author}</span>
                    <span className="text-[10px] text-[#4D4A42]">{commit.date}</span>
                    {commit.branch && (
                      <span className="text-[10px] px-1 rounded" style={{ background: `${BRANCHES.find(b => b.name === commit.branch)?.color || '#8A8578'}15`, color: BRANCHES.find(b => b.name === commit.branch)?.color || '#8A8578' }}>
                        {commit.branch}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-mono text-[10px] text-[#4D4A42]">{commit.shortHash}</span>
                  <div className="flex items-center gap-1 text-[10px]">
                    <Plus className="w-2.5 h-2.5 text-[#5A9E6F]" />
                    <span className="text-[#5A9E6F]">{commit.additions}</span>
                    <Minus className="w-2.5 h-2.5 text-[#B84A4A]" />
                    <span className="text-[#B84A4A]">{commit.deletions}</span>
                  </div>
                  <button
                    className="p-1 rounded hover:bg-[#222235]"
                    onClick={e => { e.stopPropagation(); copyHash(commit.hash); }}
                  >
                    {copied && selectedCommit?.hash === commit.hash ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3 text-[#4D4A42]" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right sidebar */}
        <div className="w-56 bg-[#0A0A0F] border-l border-[#2A2A3E] flex flex-col shrink-0 overflow-hidden">
          {/* Contributors */}
          <div className="border-b border-[#2A2A3E]">
            <div className="px-3 py-2 text-[10px] text-[#4D4A42] uppercase tracking-wider">
              Contributors
            </div>
            <div className="px-3 pb-2 flex flex-col gap-1.5">
              {contributors.map(([name, data]) => (
                <div key={name} className="flex items-center gap-2">
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold shrink-0"
                    style={{ background: `${data.color}30`, color: data.color }}
                  >
                    {name[0]}
                  </div>
                  <span className="flex-1 truncate text-[11px]">{name}</span>
                  <span className="text-[10px] text-[#8A8578]">{data.count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Selected commit detail */}
          {selectedCommit && (
            <div className="flex-1 overflow-auto">
              <div className="px-3 py-2 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E]">
                Commit Details
              </div>
              <div className="p-3 flex flex-col gap-2">
                <div>
                  <div className="text-[10px] text-[#4D4A42]">Hash</div>
                  <div className="font-mono text-[11px] text-[#C9A84C]">{selectedCommit.hash}</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#4D4A42]">Message</div>
                  <div className="text-[11px]">{selectedCommit.message}</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#4D4A42]">Author</div>
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <div
                      className="w-4 h-4 rounded-full flex items-center justify-center text-[7px] font-bold"
                      style={{ background: `${selectedCommit.avatar}30`, color: selectedCommit.avatar }}
                    >
                      {selectedCommit.author[0]}
                    </div>
                    {selectedCommit.author}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-[#4D4A42]">Date</div>
                  <div className="text-[11px] text-[#8A8578]">{selectedCommit.date}</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#4D4A42]">Branch</div>
                  <span className="text-[11px] px-1.5 py-0.5 rounded inline-block mt-0.5" style={{ background: `${BRANCHES.find(b => b.name === selectedCommit.branch)?.color || '#8A8578'}15`, color: BRANCHES.find(b => b.name === selectedCommit.branch)?.color || '#8A8578' }}>
                    {selectedCommit.branch}
                  </span>
                </div>
                <div className="border-t border-[#2A2A3E] pt-2 mt-1">
                  <div className="text-[10px] text-[#4D4A42] mb-1">Changes</div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Plus className="w-3 h-3 text-[#5A9E6F]" />
                      <span className="text-[11px] text-[#5A9E6F]">{selectedCommit.additions}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Minus className="w-3 h-3 text-[#B84A4A]" />
                      <span className="text-[11px] text-[#B84A4A]">{selectedCommit.deletions}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <FileDiff className="w-3 h-3 text-[#8A8578]" />
                      <span className="text-[11px] text-[#8A8578]">{selectedCommit.filesChanged} files</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
