import { useState, useRef, useEffect } from 'react';
import { Mountain, Plus, Trash2 } from 'lucide-react';

interface ElevationPoint {
  id: string;
  x: number;
  y: number;
  elevation: number;
}

const SAMPLE_POINTS: ElevationPoint[] = [
  { id: '1', x: 0, y: 0, elevation: 100 },
  { id: '2', x: 20, y: 0, elevation: 120 },
  { id: '3', x: 40, y: 0, elevation: 90 },
  { id: '4', x: 60, y: 0, elevation: 150 },
  { id: '5', x: 80, y: 0, elevation: 110 },
  { id: '6', x: 100, y: 0, elevation: 130 },
  { id: '7', x: 0, y: 20, elevation: 110 },
  { id: '8', x: 20, y: 20, elevation: 140 },
  { id: '9', x: 40, y: 20, elevation: 80 },
  { id: '10', x: 60, y: 20, elevation: 160 },
  { id: '11', x: 80, y: 20, elevation: 100 },
  { id: '12', x: 100, y: 20, elevation: 140 },
  { id: '13', x: 0, y: 40, elevation: 130 },
  { id: '14', x: 20, y: 40, elevation: 100 },
  { id: '15', x: 40, y: 40, elevation: 170 },
  { id: '16', x: 60, y: 40, elevation: 140 },
  { id: '17', x: 80, y: 40, elevation: 90 },
  { id: '18', x: 100, y: 40, elevation: 120 },
  { id: '19', x: 0, y: 60, elevation: 90 },
  { id: '20', x: 20, y: 60, elevation: 150 },
  { id: '21', x: 40, y: 60, elevation: 110 },
  { id: '22', x: 60, y: 60, elevation: 130 },
  { id: '23', x: 80, y: 60, elevation: 160 },
  { id: '24', x: 100, y: 60, elevation: 100 },
  { id: '25', x: 0, y: 80, elevation: 140 },
  { id: '26', x: 20, y: 80, elevation: 120 },
  { id: '27', x: 40, y: 80, elevation: 90 },
  { id: '28', x: 60, y: 80, elevation: 100 },
  { id: '29', x: 80, y: 80, elevation: 130 },
  { id: '30', x: 100, y: 80, elevation: 150 },
];

function interpolateElevation(x: number, y: number, points: ElevationPoint[]): number {
  let totalWeight = 0;
  let weightedSum = 0;
  for (const p of points) {
    const dx = x - p.x;
    const dy = y - p.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 0.01) return p.elevation;
    const w = 1 / (dist * dist);
    totalWeight += w;
    weightedSum += p.elevation * w;
  }
  return weightedSum / totalWeight;
}

function elevationToColor(elev: number, min: number, max: number): string {
  const t = Math.max(0, Math.min(1, (elev - min) / (max - min)));
  // Green (low) -> Brown (mid) -> White (high)
  if (t < 0.5) {
    const s = t * 2;
    const r = Math.round(34 + (139 - 34) * s);
    const g = Math.round(139 + (69 - 139) * s);
    const b = Math.round(34 + (19 - 34) * s);
    return `rgb(${r},${g},${b})`;
  } else {
    const s = (t - 0.5) * 2;
    const r = Math.round(139 + (232 - 139) * s);
    const g = Math.round(69 + (232 - 69) * s);
    const b = Math.round(19 + (232 - 19) * s);
    return `rgb(${r},${g},${b})`;
  }
}

export default function Topography() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const profileCanvasRef = useRef<HTMLCanvasElement>(null);
  const [points, setPoints] = useState<ElevationPoint[]>(SAMPLE_POINTS);
  const [canvasSize, setCanvasSize] = useState({ w: 0, h: 0 });
  const [profileSize, setProfileSize] = useState({ w: 0, h: 0 });
  const [newX, setNewX] = useState('');
  const [newY, setNewY] = useState('');
  const [newElev, setNewElev] = useState('');
  const [showContours, setShowContours] = useState(true);
  const [sliceY, setSliceY] = useState(40);
  const containerRef = useRef<HTMLDivElement>(null);
  const profileContainerRef = useRef<HTMLDivElement>(null);

  const minElev = useRef(60);
  const maxElev = useRef(200);

  useEffect(() => {
    const update = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setCanvasSize({ w: rect.width, h: rect.height });
      }
      if (profileContainerRef.current) {
        const rect = profileContainerRef.current.getBoundingClientRect();
        setProfileSize({ w: rect.width, h: rect.height });
      }
    };
    update();
    const ro = new ResizeObserver(update);
    if (containerRef.current) ro.observe(containerRef.current);
    if (profileContainerRef.current) ro.observe(profileContainerRef.current);
    return () => ro.disconnect();
  }, []);

  // Update min/max
  useEffect(() => {
    if (points.length > 0) {
      minElev.current = Math.min(...points.map((p) => p.elevation)) - 20;
      maxElev.current = Math.max(...points.map((p) => p.elevation)) + 20;
    }
  }, [points]);

  const addPoint = () => {
    const x = parseFloat(newX);
    const y = parseFloat(newY);
    const e = parseFloat(newElev);
    if (isNaN(x) || isNaN(y) || isNaN(e)) return;
    setPoints((prev) => [...prev, { id: Date.now().toString(), x, y, elevation: e }]);
    setNewX('');
    setNewY('');
    setNewElev('');
  };

  const removePoint = (id: string) => {
    setPoints((prev) => prev.filter((p) => p.id !== id));
  };

  // Draw elevation map
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || canvasSize.w === 0 || canvasSize.h === 0) return;
    canvas.width = canvasSize.w * window.devicePixelRatio;
    canvas.height = canvasSize.h * window.devicePixelRatio;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const scaleX = canvasSize.w / 120;
    const scaleY = canvasSize.h / 100;

    // Draw elevation heatmap
    const step = 3;
    for (let px = 0; px < canvasSize.w; px += step) {
      for (let py = 0; py < canvasSize.h; py += step) {
        const wx = px / scaleX;
        const wy = py / scaleY;
        const elev = interpolateElevation(wx, wy, points);
        ctx.fillStyle = elevationToColor(elev, minElev.current, maxElev.current);
        ctx.fillRect(px, py, step, step);
      }
    }

    // Draw contour lines
    if (showContours) {
      ctx.strokeStyle = 'rgba(0,0,0,0.3)';
      ctx.lineWidth = 0.5;
      const contourStep = 20;
      for (let level = minElev.current; level <= maxElev.current; level += contourStep) {
        for (let px = 0; px < canvasSize.w - step; px += step) {
          for (let py = 0; py < canvasSize.h - step; py += step) {
            const wx = px / scaleX;
            const wy = py / scaleY;
            const e00 = interpolateElevation(wx, wy, points);
            const e10 = interpolateElevation(wx + step / scaleX, wy, points);
            const e01 = interpolateElevation(wx, wy + step / scaleY, points);
            const e11 = interpolateElevation(wx + step / scaleX, wy + step / scaleY, points);

            const corners = [e00 >= level, e10 >= level, e11 >= level, e01 >= level];
            const count = corners.filter(Boolean).length;
            if (count > 0 && count < 4) {
              ctx.fillStyle = 'rgba(0,0,0,0.15)';
              ctx.fillRect(px, py, step, step);
            }
          }
        }
      }
    }

    // Draw slice line
    const sliceYCanvas = sliceY * scaleY;
    ctx.strokeStyle = 'var(--accent-gold)';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(0, sliceYCanvas);
    ctx.lineTo(canvasSize.w, sliceYCanvas);
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw data points
    for (const p of points) {
      const px = p.x * scaleX;
      const py = p.y * scaleY;
      ctx.beginPath();
      ctx.arc(px, py, 3, 0, Math.PI * 2);
      ctx.fillStyle = 'var(--accent-gold)';
      ctx.fill();
      ctx.fillStyle = 'var(--text-primary)';
      ctx.font = '8px monospace';
      ctx.fillText(`${p.elevation}`, px + 4, py - 4);
    }
  }, [points, canvasSize, showContours, sliceY]);

  // Draw cross-section profile
  useEffect(() => {
    const canvas = profileCanvasRef.current;
    if (!canvas || profileSize.w === 0 || profileSize.h === 0) return;
    canvas.width = profileSize.w * window.devicePixelRatio;
    canvas.height = profileSize.h * window.devicePixelRatio;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    ctx.fillStyle = '#0A0A0F';
    ctx.fillRect(0, 0, profileSize.w, profileSize.h);

    const pad = 20;
    const pw = profileSize.w - pad * 2;
    const ph = profileSize.h - pad * 2;

    // Compute profile
    const numSamples = 100;
    const profile: { x: number; elev: number }[] = [];
    for (let i = 0; i <= numSamples; i++) {
      const wx = (i / numSamples) * 120;
      const elev = interpolateElevation(wx, sliceY, points);
      profile.push({ x: wx, elev });
    }

    const range = maxElev.current - minElev.current || 1;

    // Draw grid
    ctx.strokeStyle = 'rgba(42,42,62,0.3)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const y = pad + (i / 5) * ph;
      ctx.beginPath();
      ctx.moveTo(pad, y);
      ctx.lineTo(pad + pw, y);
      ctx.stroke();
      const elev = maxElev.current - (i / 5) * range;
      ctx.fillStyle = 'var(--text-muted)';
      ctx.font = '8px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(elev.toFixed(0), pad - 4, y + 3);
    }

    ctx.textAlign = 'center';
    for (let i = 0; i <= 5; i++) {
      const x = pad + (i / 5) * pw;
      ctx.fillText(((i / 5) * 120).toFixed(0), x, profileSize.h - 4);
    }

    // Draw profile area
    ctx.beginPath();
    ctx.moveTo(pad, pad + ph);
    for (const p of profile) {
      const px = pad + (p.x / 120) * pw;
      const py = pad + (1 - (p.elev - minElev.current) / range) * ph;
      ctx.lineTo(px, py);
    }
    ctx.lineTo(pad + pw, pad + ph);
    ctx.closePath();

    const grad = ctx.createLinearGradient(0, pad, 0, pad + ph);
    grad.addColorStop(0, 'rgba(201,168,76,0.4)');
    grad.addColorStop(1, 'rgba(201,168,76,0.05)');
    ctx.fillStyle = grad;
    ctx.fill();

    // Draw profile line
    ctx.strokeStyle = 'var(--accent-gold)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < profile.length; i++) {
      const px = pad + (profile[i].x / 120) * pw;
      const py = pad + (1 - (profile[i].elev - minElev.current) / range) * ph;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();

    // Labels
    ctx.fillStyle = 'var(--text-secondary)';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`Cross-section at Y = ${sliceY}`, profileSize.w / 2, 12);
  }, [points, profileSize, sliceY]);

  const totalArea = 120 * 100;
  const avgElev = points.reduce((s, p) => s + p.elevation, 0) / (points.length || 1);
  const approxVolume = totalArea * avgElev;

  return (
    <div className="w-full h-full flex flex-col overflow-hidden" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      <div className="flex items-center justify-between px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Mountain size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Topography</span>
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1 text-[10px] cursor-pointer" style={{ color: 'var(--text-muted)' }}>
            <input type="checkbox" checked={showContours} onChange={(e) => setShowContours(e.target.checked)} className="rounded" />
            Contours
          </label>
          <div className="flex items-center gap-1 text-[10px]">
            <span style={{ color: 'var(--text-muted)' }}>Slice Y:</span>
            <input
              type="range" min="0" max="100" value={sliceY}
              onChange={(e) => setSliceY(Number(e.target.value))}
              className="w-16"
            />
            <span className="font-mono" style={{ color: 'var(--accent-gold)' }}>{sliceY}</span>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Main map */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Stats */}
          <div className="grid grid-cols-4 gap-2 p-2 shrink-0">
            {[
              { label: 'Points', value: points.length.toString() },
              { label: 'Elev Range', value: `${minElev.current.toFixed(0)}-${maxElev.current.toFixed(0)}m` },
              { label: 'Avg Elevation', value: `${avgElev.toFixed(1)}m` },
              { label: 'Approx Volume', value: `${(approxVolume / 1e6).toFixed(2)}Mm³` },
            ].map((s) => (
              <div key={s.label} className="flex flex-col px-2 py-1.5 rounded-md" style={{ background: 'var(--surface)' }}>
                <span className="text-[9px]" style={{ color: 'var(--text-muted)' }}>{s.label}</span>
                <span className="text-xs font-bold font-mono" style={{ color: 'var(--accent-gold)' }}>{s.value}</span>
              </div>
            ))}
          </div>

          {/* Map canvas */}
          <div ref={containerRef} className="flex-1 min-h-0 relative">
            <canvas ref={canvasRef} className="w-full h-full" />
          </div>

          {/* Profile */}
          <div className="h-28 shrink-0 relative" style={{ borderTop: '1px solid var(--border-subtle)' }}>
            <div ref={profileContainerRef} className="w-full h-full">
              <canvas ref={profileCanvasRef} className="w-full h-full" />
            </div>
          </div>
        </div>

        {/* Points panel */}
        <div className="w-48 flex flex-col shrink-0 overflow-hidden" style={{ background: 'var(--surface)', borderLeft: '1px solid var(--border-subtle)' }}>
          <div className="text-[11px] font-medium px-3 py-2" style={{ color: 'var(--text-muted)', borderBottom: '1px solid var(--border-subtle)' }}>
            Elevation Points
          </div>
          <div className="flex-1 overflow-y-auto">
            {points.map((p) => (
              <div key={p.id} className="flex items-center justify-between px-3 py-1.5 text-[10px]" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                <span className="font-mono" style={{ color: 'var(--text-secondary)' }}>
                  ({p.x}, {p.y})
                </span>
                <span className="font-mono" style={{ color: 'var(--accent-gold)' }}>{p.elevation}m</span>
                <button onClick={() => removePoint(p.id)} className="p-0.5 rounded hover:bg-[#222235]">
                  <Trash2 size={10} style={{ color: 'var(--danger)' }} />
                </button>
              </div>
            ))}
          </div>

          {/* Add point */}
          <div className="p-2 flex flex-col gap-1" style={{ borderTop: '1px solid var(--border-subtle)' }}>
            <div className="text-[10px] mb-0.5" style={{ color: 'var(--text-muted)' }}>Add Point</div>
            <div className="flex gap-1">
              <input type="number" value={newX} onChange={(e) => setNewX(e.target.value)} placeholder="X" className="w-full px-1.5 py-1 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} />
              <input type="number" value={newY} onChange={(e) => setNewY(e.target.value)} placeholder="Y" className="w-full px-1.5 py-1 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} />
              <input type="number" value={newElev} onChange={(e) => setNewElev(e.target.value)} placeholder="Elev" className="w-full px-1.5 py-1 rounded text-[10px] font-mono outline-none" style={{ background: 'var(--abyss)', border: '1px solid var(--border-subtle)', color: 'var(--text-primary)' }} />
            </div>
            <button
              onClick={addPoint}
              className="w-full py-1 rounded text-[10px] font-medium transition-colors"
              style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
            >
              <Plus size={10} className="inline mr-1" /> Add
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
