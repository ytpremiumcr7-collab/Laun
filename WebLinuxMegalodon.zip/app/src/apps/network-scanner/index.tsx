import { useState, useCallback } from 'react';
import {
  Wifi,
  Router,
  Laptop,
  Smartphone,
  Printer,
  RefreshCw,
  Zap,
  Globe,
  CheckCircle2,
  XCircle,
  Server,
  Signal,
  Shield,
  Play,
} from 'lucide-react';

interface Device {
  id: string;
  ip: string;
  hostname: string;
  type: 'router' | 'laptop' | 'phone' | 'printer' | 'server' | 'desktop';
  status: 'online' | 'offline';
  mac: string;
  latency: number;
  ports: { port: number; service: string; open: boolean }[];
}

interface NetworkInfo {
  ip: string;
  mac: string;
  gateway: string;
  dns: string;
  subnet: string;
}

const NETWORK_INFO: NetworkInfo = {
  ip: '192.168.1.42',
  mac: 'A4:5E:60:D2:8B:F1',
  gateway: '192.168.1.1',
  dns: '8.8.8.8',
  subnet: '255.255.255.0',
};

const INITIAL_DEVICES: Device[] = [
  { id: '1', ip: '192.168.1.1', hostname: 'Gateway Router', type: 'router', status: 'online', mac: '00:1A:2B:3C:4D:5E', latency: 1, ports: [{ port: 80, service: 'HTTP', open: true }, { port: 443, service: 'HTTPS', open: true }, { port: 22, service: 'SSH', open: false }] },
  { id: '2', ip: '192.168.1.10', hostname: 'ThinkPad-X1', type: 'laptop', status: 'online', mac: 'A4:5E:60:D2:8B:F1', latency: 3, ports: [{ port: 22, service: 'SSH', open: true }, { port: 445, service: 'SMB', open: true }] },
  { id: '3', ip: '192.168.1.15', hostname: 'iPhone-13', type: 'phone', status: 'online', mac: 'B8:27:EB:12:34:56', latency: 5, ports: [{ port: 62078, service: 'iPhone-Sync', open: false }] },
  { id: '4', ip: '192.168.1.20', hostname: 'Office-Printer', type: 'printer', status: 'online', mac: '00:16:17:AA:BB:CC', latency: 8, ports: [{ port: 80, service: 'HTTP', open: true }, { port: 443, service: 'HTTPS', open: true }, { port: 9100, service: 'JetDirect', open: true }, { port: 515, service: 'LPD', open: true }] },
  { id: '5', ip: '192.168.1.25', hostname: 'MacBook-Pro', type: 'laptop', status: 'offline', mac: 'AC:DE:48:00:11:22', latency: 0, ports: [{ port: 22, service: 'SSH', open: false }, { port: 445, service: 'SMB', open: false }] },
  { id: '6', ip: '192.168.1.30', hostname: 'Workstation-Dell', type: 'desktop', status: 'online', mac: 'D4:81:D7:EE:FF:00', latency: 2, ports: [{ port: 22, service: 'SSH', open: true }, { port: 80, service: 'HTTP', open: true }, { port: 3306, service: 'MySQL', open: false }] },
  { id: '7', ip: '192.168.1.35', hostname: 'Home-Server', type: 'server', status: 'online', mac: '00:50:56:C0:00:01', latency: 2, ports: [{ port: 22, service: 'SSH', open: true }, { port: 80, service: 'HTTP', open: true }, { port: 443, service: 'HTTPS', open: true }, { port: 3306, service: 'MySQL', open: true }, { port: 8080, service: 'HTTP-Alt', open: true }] },
  { id: '8', ip: '192.168.1.40', hostname: 'Samsung-S21', type: 'phone', status: 'online', mac: '5C:F6:DC:AB:CD:EF', latency: 4, ports: [{ port: 5555, service: 'ADB', open: false }] },
];

const DEVICE_ICONS: Record<string, React.ReactNode> = {
  router: <Router size={16} />,
  laptop: <Laptop size={16} />,
  phone: <Smartphone size={16} />,
  printer: <Printer size={16} />,
  server: <Server size={16} />,
  desktop: <Globe size={16} />,
};

export default function NetworkScanner() {
  const [devices, setDevices] = useState<Device[]>(INITIAL_DEVICES);
  const [scanning, setScanning] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [speedTestRunning, setSpeedTestRunning] = useState(false);
  const [speedResult, setSpeedResult] = useState<{ download: number; upload: number; ping: number } | null>(null);
  const [speedPhase, setSpeedPhase] = useState<'idle' | 'ping' | 'download' | 'upload'>('idle');
  const [scanProgress, setScanProgress] = useState(0);

  const scanNetwork = useCallback(() => {
    setScanning(true);
    setScanProgress(0);
    setDevices((prev) => prev.map((d) => ({ ...d, status: 'offline' as const, latency: 0 })));

    let progress = 0;
    const interval = setInterval(() => {
      progress += 12;
      setScanProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setDevices(INITIAL_DEVICES.map((d) => ({
          ...d,
          latency: d.status === 'online' ? Math.floor(Math.random() * 10) + 1 : 0,
        })));
        setScanning(false);
      }
    }, 200);
  }, []);

  const runSpeedTest = () => {
    setSpeedTestRunning(true);
    setSpeedResult(null);
    setSpeedPhase('ping');

    setTimeout(() => {
      setSpeedPhase('download');
      setTimeout(() => {
        setSpeedPhase('upload');
        setTimeout(() => {
          setSpeedResult({
            download: 250 + Math.random() * 150,
            upload: 80 + Math.random() * 40,
            ping: Math.floor(Math.random() * 10) + 5,
          });
          setSpeedPhase('idle');
          setSpeedTestRunning(false);
        }, 2000);
      }, 2500);
    }, 1500);
  };

  const pingDevice = (device: Device) => {
    setDevices((prev) =>
      prev.map((d) =>
        d.id === device.id
          ? { ...d, latency: Math.floor(Math.random() * 15) + 1, status: Math.random() > 0.1 ? ('online' as const) : ('offline' as const) }
          : d
      )
    );
  };

  const scanPorts = (device: Device) => {
    setDevices((prev) =>
      prev.map((d) =>
        d.id === device.id
          ? {
              ...d,
              ports: d.ports.map((p) => ({
                ...p,
                open: Math.random() > 0.3,
              })),
            }
          : d
      )
    );
  };

  const onlineCount = devices.filter((d) => d.status === 'online').length;

  return (
    <div className="w-full h-full flex flex-col overflow-y-auto" style={{ background: 'var(--abyss)', color: 'var(--text-primary)' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 shrink-0" style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center gap-2">
          <Wifi size={16} style={{ color: 'var(--accent-gold)' }} />
          <span className="text-sm font-semibold">Network Scanner</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={scanNetwork}
            disabled={scanning}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors disabled:opacity-50"
            style={{ background: 'var(--accent-gold)', color: 'var(--void)' }}
          >
            <RefreshCw size={12} className={scanning ? 'animate-spin' : ''} />
            {scanning ? 'Scanning...' : 'Scan Network'}
          </button>
        </div>
      </div>

      {/* Scan progress */}
      {scanning && (
        <div className="px-3 py-2 shrink-0" style={{ background: 'rgba(201,168,76,0.08)' }}>
          <div className="flex items-center justify-between text-[10px] mb-1" style={{ color: 'var(--text-muted)' }}>
            <span>Scanning network range 192.168.1.0/24...</span>
            <span>{scanProgress}%</span>
          </div>
          <div className="h-1 rounded-full overflow-hidden" style={{ background: 'var(--surface-elevated)' }}>
            <div
              className="h-full rounded-full transition-all duration-200"
              style={{ width: `${scanProgress}%`, background: 'var(--accent-gold)' }}
            />
          </div>
        </div>
      )}

      {/* Network info */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 p-3 shrink-0" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
        {Object.entries(NETWORK_INFO).map(([key, value]) => (
          <div key={key} className="flex flex-col gap-0.5 px-3 py-2 rounded-md" style={{ background: 'var(--surface)' }}>
            <span className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>{key}</span>
            <span className="text-xs font-mono" style={{ color: 'var(--text-primary)' }}>{value}</span>
          </div>
        ))}
      </div>

      {/* Speed test */}
      <div className="p-3 shrink-0" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Zap size={14} style={{ color: 'var(--accent-gold)' }} />
            <span className="text-xs font-semibold">Speed Test</span>
          </div>
          <button
            onClick={runSpeedTest}
            disabled={speedTestRunning}
            className="flex items-center gap-1 px-3 py-1 rounded-md text-xs transition-colors disabled:opacity-50"
            style={{ background: speedTestRunning ? 'var(--surface-hover)' : 'var(--success)', color: 'var(--void)' }}
          >
            <Play size={10} />
            {speedTestRunning ? 'Running...' : 'Start Test'}
          </button>
        </div>
        {speedTestRunning ? (
          <div className="flex items-center justify-center py-3">
            <div className="relative w-32 h-32">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" fill="none" stroke="var(--surface-elevated)" strokeWidth="6" />
                <circle
                  cx="50" cy="50" r="40" fill="none"
                  stroke={speedPhase === 'ping' ? 'var(--info)' : speedPhase === 'download' ? 'var(--accent-gold)' : 'var(--success)'}
                  strokeWidth="6"
                  strokeDasharray={`${speedPhase === 'ping' ? 40 : speedPhase === 'download' ? 140 : 251} 251`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-xs font-semibold" style={{ color: 'var(--accent-gold)' }}>
                  {speedPhase === 'ping' ? 'Ping' : speedPhase === 'download' ? 'Down' : 'Up'}
                </span>
                <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                  {speedPhase === 'ping' ? '...' : speedPhase === 'download' ? 'Testing' : 'Testing'}
                </span>
              </div>
            </div>
          </div>
        ) : speedResult ? (
          <div className="grid grid-cols-3 gap-2">
            <div className="flex flex-col items-center py-2 rounded-md" style={{ background: 'var(--surface)' }}>
              <span className="text-lg font-bold font-mono" style={{ color: 'var(--accent-gold)' }}>{speedResult.ping}</span>
              <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>ms ping</span>
            </div>
            <div className="flex flex-col items-center py-2 rounded-md" style={{ background: 'var(--surface)' }}>
              <span className="text-lg font-bold font-mono" style={{ color: 'var(--success)' }}>{speedResult.download.toFixed(0)}</span>
              <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>Mbps down</span>
            </div>
            <div className="flex flex-col items-center py-2 rounded-md" style={{ background: 'var(--surface)' }}>
              <span className="text-lg font-bold font-mono" style={{ color: 'var(--info)' }}>{speedResult.upload.toFixed(0)}</span>
              <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>Mbps up</span>
            </div>
          </div>
        ) : (
          <div className="text-center py-2 text-xs" style={{ color: 'var(--text-muted)' }}>
            Click Start Test to measure your network speed
          </div>
        )}
      </div>

      {/* Device list */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center justify-between px-3 py-2 text-xs font-medium shrink-0" style={{ color: 'var(--text-muted)', borderBottom: '1px solid var(--border-subtle)' }}>
          <span>Discovered Devices ({onlineCount}/{devices.length} online)</span>
        </div>
        <div className="flex-1 overflow-y-auto">
          {devices.map((device) => (
            <button
              key={device.id}
              onClick={() => setSelectedDevice(selectedDevice?.id === device.id ? null : device)}
              className="w-full flex items-center gap-3 px-3 py-2.5 text-left transition-colors border-b"
              style={{ borderColor: 'var(--border-subtle)', background: selectedDevice?.id === device.id ? 'rgba(201,168,76,0.06)' : 'transparent' }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{
                  background: device.status === 'online' ? 'rgba(90,158,111,0.15)' : 'var(--surface-elevated)',
                  color: device.status === 'online' ? 'var(--success)' : 'var(--text-muted)',
                }}
              >
                {DEVICE_ICONS[device.type]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium truncate">{device.hostname}</span>
                  {device.status === 'online' ? (
                    <CheckCircle2 size={10} style={{ color: 'var(--success)' }} />
                  ) : (
                    <XCircle size={10} style={{ color: 'var(--danger)' }} />
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px]" style={{ color: 'var(--text-muted)' }}>
                  <span className="font-mono">{device.ip}</span>
                  <span>·</span>
                  <span className="font-mono">{device.mac}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {device.status === 'online' && (
                  <span className="text-[10px] font-mono" style={{ color: 'var(--accent-gold)' }}>{device.latency}ms</span>
                )}
                <ChevronRightIcon />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Device detail panel */}
      {selectedDevice && (
        <div className="shrink-0 p-3" style={{ background: 'var(--surface)', borderTop: '1px solid var(--border-subtle)' }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold">{selectedDevice.hostname} Details</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => pingDevice(selectedDevice)}
                className="flex items-center gap-1 px-2 py-1 rounded text-[10px] hover:bg-[#222235] transition-colors"
                style={{ color: 'var(--text-secondary)' }}
              >
                <Signal size={10} /> Ping
              </button>
              <button
                onClick={() => scanPorts(selectedDevice)}
                className="flex items-center gap-1 px-2 py-1 rounded text-[10px] hover:bg-[#222235] transition-colors"
                style={{ color: 'var(--text-secondary)' }}
              >
                <Shield size={10} /> Scan Ports
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-1.5 text-[10px] mb-2">
            <div className="flex justify-between px-2 py-1 rounded" style={{ background: 'var(--abyss)' }}>
              <span style={{ color: 'var(--text-muted)' }}>IP</span>
              <span className="font-mono">{selectedDevice.ip}</span>
            </div>
            <div className="flex justify-between px-2 py-1 rounded" style={{ background: 'var(--abyss)' }}>
              <span style={{ color: 'var(--text-muted)' }}>MAC</span>
              <span className="font-mono">{selectedDevice.mac}</span>
            </div>
            <div className="flex justify-between px-2 py-1 rounded" style={{ background: 'var(--abyss)' }}>
              <span style={{ color: 'var(--text-muted)' }}>Type</span>
              <span className="capitalize">{selectedDevice.type}</span>
            </div>
            <div className="flex justify-between px-2 py-1 rounded" style={{ background: 'var(--abyss)' }}>
              <span style={{ color: 'var(--text-muted)' }}>Latency</span>
              <span className="font-mono" style={{ color: selectedDevice.latency > 0 ? 'var(--success)' : 'var(--danger)' }}>{selectedDevice.latency}ms</span>
            </div>
          </div>
          {/* Port status */}
          <div className="text-[10px] font-medium mb-1" style={{ color: 'var(--text-muted)' }}>Port Status</div>
          <div className="grid grid-cols-4 gap-1">
            {selectedDevice.ports.map((port) => (
              <div
                key={port.port}
                className="flex items-center justify-between px-2 py-1 rounded"
                style={{ background: port.open ? 'rgba(90,158,111,0.12)' : 'var(--abyss)' }}
              >
                <div className="flex flex-col">
                  <span className="font-mono text-[10px]" style={{ color: port.open ? 'var(--success)' : 'var(--text-muted)' }}>{port.port}</span>
                  <span className="text-[8px]" style={{ color: 'var(--text-muted)' }}>{port.service}</span>
                </div>
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: port.open ? 'var(--success)' : 'var(--danger)' }}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ChevronRightIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: 'var(--text-muted)' }}>
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}
