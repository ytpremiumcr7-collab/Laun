import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import {
  Copy, Check, Plus
} from 'lucide-react';

/* ── color utilities ── */
function hsvToRgb(h: number, s: number, v: number): [number, number, number] {
  s /= 100; v /= 100;
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; }
  else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; }
  else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; }
  else { r = c; b = x; }
  return [
    Math.round((r + m) * 255),
    Math.round((g + m) * 255),
    Math.round((b + m) * 255),
  ];
}

function rgbToHsv(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d + 6) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
  }
  const s = max === 0 ? 0 : (d / max) * 100;
  const v = max * 100;
  return [Math.round(h), Math.round(s), Math.round(v)];
}

function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map(c => c.toString(16).padStart(2, '0')).join('').toUpperCase();
}

function hexToRgb(hex: string): [number, number, number] | null {
  const m = hex.replace('#', '').match(/^([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/);
  if (!m) return null;
  return [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)];
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d + 6) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60;
  }
  const l = (max + min) / 2;
  const s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
  return [Math.round(h), Math.round(s * 100), Math.round(l * 100)];
}

function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  s /= 100; l /= 100;
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0, g = 0, b = 0;
  if (h < 60) { r = c; g = x; }
  else if (h < 120) { r = x; g = c; }
  else if (h < 180) { g = c; b = x; }
  else if (h < 240) { g = x; b = c; }
  else if (h < 300) { r = x; b = c; }
  else { r = c; b = x; }
  return [
    Math.round((r + m) * 255),
    Math.round((g + m) * 255),
    Math.round((b + m) * 255),
  ];
}

function getContrastRatio(bg: [number, number, number], fg: [number, number, number]): number {
  const lum = (c: number[]) => {
    const a = c.map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
  };
  const l1 = lum(bg) + 0.05;
  const l2 = lum(fg) + 0.05;
  return Math.max(l1, l2) / Math.min(l1, l2);
}

/* ── harmony calculators ── */
function getHarmonies(h: number, s: number, v: number) {
  return {
    complementary: [hsvToRgb((h + 180) % 360, s, v)],
    analogous: [hsvToRgb((h + 30) % 360, s, v), hsvToRgb((h - 30 + 360) % 360, s, v)],
    triadic: [hsvToRgb((h + 120) % 360, s, v), hsvToRgb((h + 240) % 360, s, v)],
    splitComplementary: [hsvToRgb((h + 150) % 360, s, v), hsvToRgb((h + 210) % 360, s, v)],
  };
}

export default function ColorPicker() {
  const [hue, setHue] = useState(43);
  const [sat, setSat] = useState(53);
  const [val, setVal] = useState(79);
  const [recent, setRecent] = useState<string[]>(['#C9A84C', '#4A9E9E', '#5A9E6F', '#7B6FB8', '#B84A4A', '#D4953A']);
  const [copiedField, setCopiedField] = useState('');
  const [activeHarmony, setActiveHarmony] = useState<'complementary' | 'analogous' | 'triadic' | 'splitComplementary'>('complementary');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hueCanvasRef = useRef<HTMLCanvasElement>(null);
  const isDragging = useRef(false);
  const isHueDragging = useRef(false);

  const rgbVal = useMemo(() => hsvToRgb(hue, sat, val), [hue, sat, val]);
  const hex = useMemo(() => rgbToHex(rgbVal[0], rgbVal[1], rgbVal[2]), [rgbVal]);
  const rgb = rgbVal;
  const hsl = useMemo(() => rgbToHsl(rgb[0], rgb[1], rgb[2]), [rgb]);
  const harmonies = useMemo(() => getHarmonies(hue, sat, val), [hue, sat, val]);

  const whiteContrast = useMemo(() => getContrastRatio(rgb, [255, 255, 255]), [rgb]);
  const blackContrast = useMemo(() => getContrastRatio(rgb, [0, 0, 0]), [rgb]);

  /* Draw gradient canvas */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // White → color gradient
    const gradWhite = ctx.createLinearGradient(0, 0, w, 0);
    gradWhite.addColorStop(0, '#ffffff');
    gradWhite.addColorStop(1, `hsl(${hue}, 100%, 50%)`);
    ctx.fillStyle = gradWhite;
    ctx.fillRect(0, 0, w, h);

    // Transparent → black gradient
    const gradBlack = ctx.createLinearGradient(0, 0, 0, h);
    gradBlack.addColorStop(0, 'rgba(0,0,0,0)');
    gradBlack.addColorStop(1, '#000000');
    ctx.fillStyle = gradBlack;
    ctx.fillRect(0, 0, w, h);
  }, [hue]);

  /* Draw hue slider */
  useEffect(() => {
    const canvas = hueCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const grad = ctx.createLinearGradient(0, 0, canvas.width, 0);
    for (let i = 0; i <= 360; i += 30) {
      grad.addColorStop(i / 360, `hsl(${i}, 100%, 50%)`);
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const handleCanvasClick = useCallback((e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setSat(Math.round(Math.max(0, Math.min(1, x)) * 100));
    setVal(Math.round((1 - Math.max(0, Math.min(1, y))) * 100));
  }, []);

  const handleHueClick = useCallback((e: React.MouseEvent) => {
    const canvas = hueCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    setHue(Math.round(Math.max(0, Math.min(1, x)) * 360));
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging.current) handleCanvasClick(e);
    if (isHueDragging.current) handleHueClick(e);
  }, [handleCanvasClick, handleHueClick]);

  const handleMouseUp = useCallback(() => {
    isDragging.current = false;
    isHueDragging.current = false;
  }, []);

  const addRecent = useCallback(() => {
    setRecent(prev => {
      const filtered = prev.filter(c => c.toLowerCase() !== hex.toLowerCase());
      return [hex, ...filtered].slice(0, 16);
    });
  }, [hex]);

  const copyHex = useCallback(async (h: string, field: string) => {
    try { await navigator.clipboard.writeText(h); setCopiedField(field); setTimeout(() => setCopiedField(''), 2000); } catch { /* noop */ }
  }, []);

  const updateFromRgb = useCallback((index: 0 | 1 | 2, value: number) => {
    const newRgb: [number, number, number] = [...rgb] as [number, number, number];
    newRgb[index] = Math.max(0, Math.min(255, value));
    const newHsv = rgbToHsv(newRgb[0], newRgb[1], newRgb[2]);
    setHue(newHsv[0]); setSat(newHsv[1]); setVal(newHsv[2]);
  }, [rgb]);

  const updateFromHex = useCallback((h: string) => {
    const newRgb = hexToRgb(h);
    if (newRgb) {
      const newHsv = rgbToHsv(newRgb[0], newRgb[1], newRgb[2]);
      setHue(newHsv[0]); setSat(newHsv[1]); setVal(newHsv[2]);
    }
  }, []);

  const updateFromHsl = useCallback((h: number, s: number, l: number) => {
    const newRgb = hslToRgb(h, s, l);
    const newHsv = rgbToHsv(newRgb[0], newRgb[1], newRgb[2]);
    setHue(newHsv[0]); setSat(newHsv[1]); setVal(newHsv[2]);
  }, []);

  const selectorX = (sat / 100) * 100;
  const selectorY = (1 - val / 100) * 100;
  const hueX = (hue / 360) * 100;

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs select-none"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      <div className="flex-1 overflow-auto p-4">
        <div className="max-w-lg mx-auto flex flex-col gap-4">
          {/* Color gradient canvas */}
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  width={300}
                  height={200}
                  className="w-full rounded-lg cursor-crosshair border border-[#2A2A3E]"
                  onClick={handleCanvasClick}
                  onMouseDown={() => isDragging.current = true}
                />
                {/* Selector handle */}
                <div
                  className="absolute w-4 h-4 rounded-full border-2 border-white shadow-md pointer-events-none"
                  style={{
                    left: `calc(${selectorX}% - 8px)`,
                    top: `calc(${selectorY}% - 8px)`,
                    background: hex,
                    boxShadow: '0 0 0 1px rgba(0,0,0,0.5), inset 0 0 0 1px rgba(0,0,0,0.3)',
                  }}
                />
              </div>
              {/* Hue slider */}
              <div className="relative mt-2">
                <canvas
                  ref={hueCanvasRef}
                  width={300}
                  height={16}
                  className="w-full rounded-full cursor-pointer border border-[#2A2A3E]"
                  onClick={handleHueClick}
                  onMouseDown={() => isHueDragging.current = true}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-5 rounded-full border-2 border-white pointer-events-none"
                  style={{ left: `calc(${hueX}% - 6px)`, background: `hsl(${hue}, 100%, 50%)` }}
                />
              </div>
            </div>

            {/* Preview */}
            <div className="w-20 flex flex-col gap-2 shrink-0">
              <div
                className="w-20 h-20 rounded-lg border-2 border-[#2A2A3E] shadow-lg"
                style={{ background: hex }}
              />
              <button
                className="flex items-center justify-center gap-1 px-2 py-1.5 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
                onClick={() => copyHex(hex, 'hex')}
              >
                {copiedField === 'hex' ? <Check className="w-3 h-3 text-[#5A9E6F]" /> : <Copy className="w-3 h-3" />}
                <span className="font-mono text-[11px]">{hex}</span>
              </button>
              <button
                className="flex items-center justify-center gap-1 px-2 py-1.5 rounded bg-[#C9A84C] text-[#030305] hover:bg-[#D4B85A] transition-colors"
                onClick={addRecent}
              >
                <Plus className="w-3 h-3" /> Save
              </button>
            </div>
          </div>

          {/* RGB Inputs */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'R', value: rgb[0], max: 255, onChange: (v: number) => updateFromRgb(0, v) },
              { label: 'G', value: rgb[1], max: 255, onChange: (v: number) => updateFromRgb(1, v) },
              { label: 'B', value: rgb[2], max: 255, onChange: (v: number) => updateFromRgb(2, v) },
            ].map(({ label, value, max, onChange }) => (
              <div key={label} className="flex flex-col gap-1">
                <label className="text-[10px] text-[#8A8578] uppercase">{label}</label>
                <input
                  type="number"
                  min={0}
                  max={max}
                  value={value}
                  onChange={e => onChange(parseInt(e.target.value) || 0)}
                  className="bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1 font-mono text-xs outline-none focus:border-[#C9A84C]"
                />
              </div>
            ))}
          </div>

          {/* HEX & HSL */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-[#8A8578] uppercase">HEX</label>
              <input
                type="text"
                value={hex}
                onChange={e => updateFromHex(e.target.value)}
                className="bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1 font-mono text-xs outline-none focus:border-[#C9A84C] uppercase"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] text-[#8A8578] uppercase">HSL</label>
              <div className="flex gap-1">
                <input type="number" value={hsl[0]} min={0} max={360}
                  onChange={e => updateFromHsl(parseInt(e.target.value) || 0, hsl[1], hsl[2])}
                  className="w-full bg-[#0A0A0F] border border-[#2A2A3E] rounded px-1 py-1 font-mono text-[10px] outline-none focus:border-[#C9A84C]"
                />
                <input type="number" value={hsl[1]} min={0} max={100}
                  onChange={e => updateFromHsl(hsl[0], parseInt(e.target.value) || 0, hsl[2])}
                  className="w-full bg-[#0A0A0F] border border-[#2A2A3E] rounded px-1 py-1 font-mono text-[10px] outline-none focus:border-[#C9A84C]"
                />
                <input type="number" value={hsl[2]} min={0} max={100}
                  onChange={e => updateFromHsl(hsl[0], hsl[1], parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0A0A0F] border border-[#2A2A3E] rounded px-1 py-1 font-mono text-[10px] outline-none focus:border-[#C9A84C]"
                />
              </div>
            </div>
          </div>

          {/* Contrast */}
          <div className="rounded-lg border border-[#2A2A3E] overflow-hidden">
            <div className="px-3 py-1.5 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E]">
              Contrast Check
            </div>
            <div className="flex">
              <div className="flex-1 p-3 flex items-center justify-center" style={{ background: hex }}>
                <span className="text-sm font-medium" style={{ color: '#FFFFFF' }}>White {whiteContrast.toFixed(2)}:1</span>
              </div>
              <div className="flex-1 p-3 flex items-center justify-center" style={{ background: hex }}>
                <span className="text-sm font-medium" style={{ color: '#000000' }}>Black {blackContrast.toFixed(2)}:1</span>
              </div>
            </div>
          </div>

          {/* Harmonies */}
          <div>
            <div className="flex items-center gap-1 mb-2">
              {([
                { key: 'complementary' as const, label: 'Comp' },
                { key: 'analogous' as const, label: 'Anlg' },
                { key: 'triadic' as const, label: 'Triad' },
                { key: 'splitComplementary' as const, label: 'Split' },
              ]).map(({ key, label }) => (
                <button
                  key={key}
                  className={`px-2 py-1 text-[10px] rounded transition-colors ${
                    activeHarmony === key ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'text-[#8A8578] hover:bg-[#1A1A26]'
                  }`}
                  onClick={() => setActiveHarmony(key)}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <div
                className="w-10 h-10 rounded border border-[#2A2A3E]"
                style={{ background: hex }}
                title={`Current: ${hex}`}
              />
              {harmonies[activeHarmony].map((h, i) => {
                const hHex = rgbToHex(h[0], h[1], h[2]);
                return (
                  <button
                    key={i}
                    className="w-10 h-10 rounded border border-[#2A2A3E] hover:scale-110 transition-transform"
                    style={{ background: hHex }}
                    title={hHex}
                    onClick={() => {
                      const newHsv = rgbToHsv(h[0], h[1], h[2]);
                      setHue(newHsv[0]); setSat(newHsv[1]); setVal(newHsv[2]);
                    }}
                  />
                );
              })}
            </div>
          </div>

          {/* Recent colors */}
          <div>
            <div className="text-[10px] text-[#4D4A42] uppercase tracking-wider mb-2">Recent</div>
            <div className="flex flex-wrap gap-1.5">
              {recent.map((c, i) => (
                <button
                  key={`${c}-${i}`}
                  className="w-7 h-7 rounded border border-[#2A2A3E] hover:scale-110 hover:border-[#C9A84C] transition-all"
                  style={{ background: c }}
                  title={c}
                  onClick={() => {
                    const newRgb = hexToRgb(c);
                    if (newRgb) {
                      const newHsv = rgbToHsv(newRgb[0], newRgb[1], newRgb[2]);
                      setHue(newHsv[0]); setSat(newHsv[1]); setVal(newHsv[2]);
                    }
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
