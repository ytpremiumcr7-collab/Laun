import { useState, useCallback, useRef } from 'react';
import {
  Folder, FolderOpen, FileCode, FileJson, FileType,
  File as FileIcon, X, Plus, Save, ChevronRight, ChevronDown
} from 'lucide-react';

/* ── types ── */
interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  language?: string;
  content?: string;
  isOpen?: boolean;
  children?: FileNode[];
}

interface TabFile {
  id: string;
  name: string;
  language: string;
  content: string;
  isModified: boolean;
}

/* ── sample file tree ── */
const SAMPLE_TREE: FileNode[] = [
  {
    id: 'src', name: 'src', type: 'folder', isOpen: true,
    children: [
      {
        id: 'components', name: 'components', type: 'folder', isOpen: true,
        children: [
          { id: 'Button.tsx', name: 'Button.tsx', type: 'file', language: 'tsx', content: `import { useState } from 'react';\n\ninterface ButtonProps {\n  label: string;\n  onClick: () => void;\n  variant?: 'primary' | 'secondary';\n}\n\nexport default function Button({ label, onClick, variant = 'primary' }: ButtonProps) {\n  const [hovered, setHovered] = useState(false);\n\n  return (\n    <button\n      className={\`btn \${variant} \${hovered ? 'hover' : ''}\`}\n      onClick={onClick}\n      onMouseEnter={() => setHovered(true)}\n      onMouseLeave={() => setHovered(false)}\n    >\n      {label}\n    </button>\n  );\n}` },
          { id: 'Card.tsx', name: 'Card.tsx', type: 'file', language: 'tsx', content: `import type { ReactNode } from 'react';\n\ninterface CardProps {\n  children: ReactNode;\n  title?: string;\n}\n\nexport default function Card({ children, title }: CardProps) {\n  return (\n    <div className=\"card\">\n      {title && <h3 className=\"card-title\">{title}</h3>}\n      <div className=\"card-body\">{children}</div>\n    </div>\n  );\n}` },
          { id: 'Modal.tsx', name: 'Modal.tsx', type: 'file', language: 'tsx', content: `import { useEffect } from 'react';\n\ninterface ModalProps {\n  isOpen: boolean;\n  onClose: () => void;\n  title: string;\n}\n\nexport default function Modal({ isOpen, onClose, title }: ModalProps) {\n  useEffect(() => {\n    const handleEsc = (e: KeyboardEvent) => {\n      if (e.key === 'Escape') onClose();\n    };\n    window.addEventListener('keydown', handleEsc);\n    return () => window.removeEventListener('keydown', handleEsc);\n  }, [onClose]);\n\n  if (!isOpen) return null;\n\n  return (\n    <div className=\"modal-overlay\" onClick={onClose}>\n      <div className=\"modal\" onClick={(e) => e.stopPropagation()}>\n        <h2>{title}</h2>\n      </div>\n    </div>\n  );\n}` },
        ]
      },
      {
        id: 'styles', name: 'styles', type: 'folder', isOpen: false,
        children: [
          { id: 'global.css', name: 'global.css', type: 'file', language: 'css', content: `* {\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n}\n\nbody {\n  font-family: 'Inter', sans-serif;\n  background: var(--color-bg);\n  color: var(--color-text);\n  line-height: 1.5;\n}\n\n.container {\n  max-width: 1200px;\n  margin: 0 auto;\n  padding: 1rem;\n}\n\n.btn {\n  padding: 0.5rem 1rem;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  font-size: 0.875rem;\n  transition: all 0.15s ease;\n}\n\n.btn.primary {\n  background: #3b82f6;\n  color: white;\n}\n\n.btn:hover {\n  opacity: 0.9;\n  transform: translateY(-1px);\n}` },
          { id: 'theme.css', name: 'theme.css', type: 'file', language: 'css', content: `:root {\n  --color-bg: #0f0f1a;\n  --color-surface: #1a1a26;\n  --color-border: #2a2a3e;\n  --color-text: #e8e4dc;\n  --color-text-muted: #8a8578;\n  --color-accent: #c9a84c;\n  --color-success: #5a9e6f;\n  --color-danger: #b84a4a;\n}\n\n[data-theme=\"light\"] {\n  --color-bg: #f5f5f0;\n  --color-surface: #ffffff;\n  --color-border: #d4d4c8;\n  --color-text: #1a1a1a;\n  --color-text-muted: #6a6a60;\n}` },
        ]
      },
      { id: 'App.tsx', name: 'App.tsx', type: 'file', language: 'tsx', content: `import { useState, useEffect } from 'react';\nimport Button from './components/Button';\nimport Card from './components/Card';\nimport './styles/global.css';\n\ninterface User {\n  id: number;\n  name: string;\n  email: string;\n}\n\nexport default function App() {\n  const [users, setUsers] = useState<User[]>([]);\n  const [loading, setLoading] = useState(true);\n  const [count, setCount] = useState(0);\n\n  useEffect(() => {\n    fetch('https://jsonplaceholder.typicode.com/users')\n      .then((res) => res.json())\n      .then((data) => {\n        setUsers(data);\n        setLoading(false);\n      })\n      .catch((err) => {\n        console.error('Failed to load users:', err);\n        setLoading(false);\n      });\n  }, []);\n\n  const handleIncrement = () => setCount((c) => c + 1);\n  const handleReset = () => setCount(0);\n\n  if (loading) {\n    return <div className=\"loading\">Loading...</div>;\n  }\n\n  return (\n    <div className=\"container\">\n      <h1>User Dashboard</h1>\n      <Card title=\"Counter\">\n        <p>Count: {count}</p>\n        <Button label=\"Increment\" onClick={handleIncrement} />\n        <Button label=\"Reset\" onClick={handleReset} variant=\"secondary\" />\n      </Card>\n      <div className=\"user-list\">\n        {users.map((user) => (\n          <Card key={user.id} title={user.name}>\n            <p>{user.email}</p>\n          </Card>\n        ))}\n      </div>\n    </div>\n  );\n}` },
      { id: 'utils.ts', name: 'utils.ts', type: 'file', language: 'ts', content: `export function formatDate(date: Date): string {\n  return date.toLocaleDateString('en-US', {\n    year: 'numeric',\n    month: 'short',\n    day: 'numeric',\n  });\n}\n\nexport function debounce<T extends (...args: unknown[]) => unknown>(\n  fn: T,\n  delay: number\n): (...args: Parameters<T>) => void {\n  let timer: ReturnType<typeof setTimeout>;\n  return (...args: Parameters<T>) => {\n    clearTimeout(timer);\n    timer = setTimeout(() => fn(...args), delay);\n  };\n}\n\nexport function clamp(value: number, min: number, max: number): number {\n  return Math.min(Math.max(value, min), max);\n}\n\nexport const CONSTANTS = {\n  MAX_ITEMS: 100,\n  PAGE_SIZE: 20,\n  API_BASE: 'https://api.example.com/v1',\n} as const;` },
      { id: 'main.tsx', name: 'main.tsx', type: 'file', language: 'tsx', content: `import { StrictMode } from 'react';\nimport { createRoot } from 'react-dom/client';\nimport App from './App';\n\nconst root = document.getElementById('root');\nif (!root) throw new Error('Root element not found');\n\ncreateRoot(root).render(\n  <StrictMode>\n    <App />\n  </StrictMode>\n);` },
    ]
  },
  { id: 'index.html', name: 'index.html', type: 'file', language: 'html', content: `<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n  <title>Cornstone App</title>\n  <link rel=\"stylesheet\" href=\"/styles/theme.css\" />\n  <link rel=\"stylesheet\" href=\"/styles/global.css\" />\n</head>\n<body>\n  <div id=\"root\"></div>\n  <script type=\"module\" src=\"/src/main.tsx\"></script>\n</body>\n</html>` },
  { id: 'package.json', name: 'package.json', type: 'file', language: 'json', content: `{\n  \"name\": \"cornstone-app\",\n  \"version\": \"1.0.0\",\n  \"type\": \"module\",\n  \"scripts\": {\n    \"dev\": \"vite\",\n    \"build\": \"tsc && vite build\",\n    \"preview\": \"vite preview\",\n    \"lint\": \"eslint . --ext ts,tsx\",\n    \"test\": \"vitest\"\n  },\n  \"dependencies\": {\n    \"react\": \"^18.2.0\",\n    \"react-dom\": \"^18.2.0\"\n  },\n  \"devDependencies\": {\n    \"@types/react\": \"^18.2.43\",\n    \"@vitejs/plugin-react\": \"^4.2.1\",\n    \"typescript\": \"^5.3.3\",\n    \"vite\": \"^5.0.8\"\n  }\n}` },
  { id: 'README.md', name: 'README.md', type: 'file', language: 'markdown', content: `# Cornstone App\n\nA modern React application built with TypeScript and Vite.\n\n## Getting Started\n\n\`\`\`bash\nnpm install\nnpm run dev\n\`\`\`\n\n## Features\n\n- React 18 with TypeScript\n- Component-based architecture\n- CSS theming support\n- Hot module replacement\n\n## Project Structure\n\n- \`src/components/\` - Reusable UI components\n- \`src/styles/\` - Global and theme styles\n- \`src/utils.ts\` - Helper functions\n\n## License\n\nMIT` },
];

/* ── syntax highlighting helpers ── */
const KEYWORDS = [
  'import', 'from', 'export', 'default', 'function', 'return', 'const', 'let', 'var',
  'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'break', 'continue', 'new',
  'try', 'catch', 'finally', 'throw', 'typeof', 'instanceof', 'in', 'of', 'as', 'await',
  'async', 'yield', 'interface', 'type', 'extends', 'implements', 'static', 'public',
  'private', 'protected', 'readonly', 'enum', 'namespace', 'module', 'declare', 'abstract',
  'true', 'false', 'null', 'undefined'
];

const TS_TYPES = ['string', 'number', 'boolean', 'any', 'unknown', 'never', 'void', 'Record', 'Array', 'Promise', 'ReactNode', 'HTMLAttributes', 'MouseEvent', 'KeyboardEvent'];

function highlightCode(code: string, language: string): string {
  let html = code
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  if (language === 'json') {
    html = html
      .replace(/"([^"]*)":/g, '<span style="color:#C9A84C">"$1"</span>:');
    html = html
      .replace(/: "([^"]*)"/g, ': <span style="color:#5A9E6F">"$1"</span>');
    html = html
      .replace(/: (\d+)/g, ': <span style="color:#4A9E9E">$1</span>');
    return html;
  }

  if (language === 'css') {
    const lines = html.split('\n');
    return lines.map(line => {
      let l = line;
      if (line.includes('{') || line.includes('}')) return line;
      if (line.includes(':') && line.includes(';')) {
        const [prop, ...rest] = line.split(':');
        return `<span style="color:#C9A84C">${prop}</span>:${rest.join(':')}`;
      }
      if (line.includes('@')) {
        return l.replace(/(@\w+)/, '<span style="color:#7B6FB8">$1</span>');
      }
      if (line.includes('--')) {
        return l.replace(/(--[\w-]+)/g, '<span style="color:#4A9E9E">$1</span>');
      }
      return l;
    }).join('\n');
  }

  if (language === 'html') {
    html = html
      .replace(/(&lt;\/?)([\w-]+)/g, '$1<span style="color:#7B6FB8">$2</span>');
    html = html
      .replace(/([\w-]+)=/g, '<span style="color:#C9A84C">$1</span>=');
    return html;
  }

  if (language === 'markdown') {
    return html
      .replace(/^(#{1,6}\s+)(.*)$/gm, '<span style="color:#7B6FB8">$1</span><span style="color:#C9A84C">$2</span>')
      .replace(/^(\`|\`\`\`)/gm, '<span style="color:#5A9E6F">$1</span>')
      .replace(/\*\*(.*?)\*\*/g, '<span style="color:#E8E4DC;font-weight:bold">**$1**</span>');
  }

  /* JS / TS / TSX */
  // Comments first
  html = html.replace(/(\/\/.*$)/gm, '<span style="color:#4D4A42;font-style:italic">$1</span>');

  // Strings
  html = html.replace(/('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|`(?:[^`\\]|\\.)*`)/g, '<span style="color:#5A9E6F">$1</span>');

  // Keywords
  const kw = new RegExp(`\\b(${KEYWORDS.join('|')})\\b`, 'g');
  html = html.replace(kw, '<span style="color:#7B6FB8">$1</span>');

  // TypeScript types
  const tp = new RegExp(`\\b(${TS_TYPES.join('|')})\\b`, 'g');
  html = html.replace(tp, '<span style="color:#5A8AB8">$1</span>');

  // Numbers
  html = html.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span style="color:#4A9E9E">$1</span>');

  // Function calls
  html = html.replace(/\b([a-zA-Z_$][\w$]*)\s*(?=\()/g, '<span style="color:#C9A84C">$1</span>');

  return html;
}

function getFileIcon(name: string) {
  if (name.endsWith('.tsx') || name.endsWith('.ts')) return <FileCode className="w-4 h-4 text-[#5A8AB8]" />;
  if (name.endsWith('.css')) return <FileType className="w-4 h-4 text-[#7B6FB8]" />;
  if (name.endsWith('.json')) return <FileJson className="w-4 h-4 text-[#D4B85A]" />;
  if (name.endsWith('.html')) return <FileCode className="w-4 h-4 text-[#B84A4A]" />;
  if (name.endsWith('.md')) return <FileIcon className="w-4 h-4 text-[#8A8578]" />;
  return <FileCode className="w-4 h-4 text-[#4A9E9E]" />;
}

export default function CodeEditor() {
  const [tree, setTree] = useState<FileNode[]>(SAMPLE_TREE);
  const [tabs, setTabs] = useState<TabFile[]>([]);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [newFileName, setNewFileName] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const activeFile = tabs.find(t => t.id === activeTab);

  const toggleFolder = useCallback((nodes: FileNode[], id: string): FileNode[] => {
    return nodes.map(n => {
      if (n.id === id && n.type === 'folder') return { ...n, isOpen: !n.isOpen };
      if (n.children) return { ...n, children: toggleFolder(n.children, id) };
      return n;
    });
  }, []);

  const findFile = useCallback((nodes: FileNode[], id: string): FileNode | null => {
    for (const n of nodes) {
      if (n.id === id && n.type === 'file') return n;
      if (n.children) {
        const found = findFile(n.children, id);
        if (found) return found;
      }
    }
    return null;
  }, []);

  const openFile = useCallback((id: string) => {
    const file = findFile(tree, id);
    if (!file || file.type !== 'file') return;
    if (!tabs.find(t => t.id === id)) {
      setTabs(prev => [...prev, {
        id: file.id,
        name: file.name,
        language: file.language || 'text',
        content: file.content || '',
        isModified: false,
      }]);
    }
    setActiveTab(id);
  }, [tree, tabs, findFile]);

  const closeTab = useCallback((id: string) => {
    setTabs(prev => {
      const filtered = prev.filter(t => t.id !== id);
      if (activeTab === id) {
        setActiveTab(filtered.length > 0 ? filtered[filtered.length - 1].id : null);
      }
      return filtered;
    });
  }, [activeTab]);

  const updateContent = useCallback((id: string, newContent: string) => {
    setTabs(prev => prev.map(t =>
      t.id === id ? { ...t, content: newContent, isModified: true } : t
    ));
  }, []);

  const saveFile = useCallback(() => {
    if (!activeFile) return;
    setTabs(prev => prev.map(t =>
      t.id === activeFile.id ? { ...t, isModified: false } : t
    ));
  }, [activeFile]);

  const createFile = useCallback(() => {
    if (!newFileName.trim()) return;
    const newNode: FileNode = {
      id: newFileName,
      name: newFileName,
      type: 'file',
      language: newFileName.split('.').pop() || 'text',
      content: '',
    };
    setTree(prev => [...prev, newNode]);
    setNewFileName('');
    setShowNewFile(false);
    openFile(newNode.id);
  }, [newFileName, openFile]);

  const handleScroll = useCallback(() => {
    if (editorRef.current && lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = editorRef.current.scrollTop;
    }
  }, []);

  /* ── line numbers ── */
  const lines = activeFile ? activeFile.content.split('\n') : [''];
  const lineCount = Math.max(lines.length, 1);

  /* ── render tree ── */
  function renderTree(nodes: FileNode[], depth = 0) {
    return nodes.map(node => (
      <div key={node.id}>
        <div
          className={`flex items-center gap-1 px-2 py-1 text-xs cursor-pointer transition-colors select-none ${
            activeTab === node.id ? 'bg-[#222235] border-l-2 border-[#C9A84C]' : 'hover:bg-[#1A1A26] border-l-2 border-transparent'
          }`}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
          onClick={() => {
            if (node.type === 'folder') {
              setTree(prev => toggleFolder(prev, node.id));
            } else {
              openFile(node.id);
            }
          }}
        >
          {node.type === 'folder' ? (
            node.isOpen ? (
              <ChevronDown className="w-3 h-3 text-[#8A8578]" />
            ) : (
              <ChevronRight className="w-3 h-3 text-[#8A8578]" />
            )
          ) : (
            <span className="w-3" />
          )}
          {node.type === 'folder' ? (
            node.isOpen ? (
              <FolderOpen className="w-4 h-4 text-[#D4B85A]" />
            ) : (
              <Folder className="w-4 h-4 text-[#D4B85A]" />
            )
          ) : (
            getFileIcon(node.name)
          )}
          <span className="truncate">{node.name}</span>
        </div>
        {node.type === 'folder' && node.isOpen && node.children && (
          renderTree(node.children, depth + 1)
        )}
      </div>
    ));
  }

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col font-mono text-sm overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-3 py-1.5 bg-[#12121A] border-b border-[#2A2A3E]">
        <button
          className="flex items-center gap-1 px-2 py-1 text-xs rounded hover:bg-[#222235] transition-colors"
          onClick={() => setShowNewFile(!showNewFile)}
        >
          <Plus className="w-3.5 h-3.5" /> New File
        </button>
        <button
          className="flex items-center gap-1 px-2 py-1 text-xs rounded hover:bg-[#222235] transition-colors"
          onClick={saveFile}
        >
          <Save className="w-3.5 h-3.5" /> Save
        </button>
      </div>

      {/* New file input */}
      {showNewFile && (
        <div className="flex items-center gap-2 px-3 py-1.5 bg-[#0A0A0F] border-b border-[#2A2A3E]">
          <input
            type="text"
            className="flex-1 bg-[#12121A] border border-[#2A2A3E] rounded px-2 py-1 text-xs outline-none focus:border-[#C9A84C]"
            placeholder="filename.ext"
            value={newFileName}
            onChange={e => setNewFileName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && createFile()}
            autoFocus
          />
          <button
            className="px-2 py-1 text-xs bg-[#C9A84C] text-[#030305] rounded hover:bg-[#D4B85A]"
            onClick={createFile}
          >
            Create
          </button>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* File Explorer */}
        <div className="w-52 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col shrink-0 overflow-hidden">
          <div className="px-3 py-2 text-[10px] font-semibold text-[#4D4A42] uppercase tracking-wider select-none">
            Explorer
          </div>
          <div className="flex-1 overflow-y-auto text-xs">
            {renderTree(tree)}
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Tabs */}
          <div className="flex items-center gap-0 bg-[#0A0A0F] border-b border-[#2A2A3E] overflow-x-auto">
            {tabs.map(tab => (
              <div
                key={tab.id}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs cursor-pointer transition-colors border-b-2 min-w-0 shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-[#1A1A26] border-[#C9A84C] text-[#E8E4DC]'
                    : 'border-transparent text-[#8A8578] hover:bg-[#1A1A26] hover:text-[#E8E4DC]'
                }`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.isModified && <span className="w-1.5 h-1.5 rounded-full bg-[#D4B85A] shrink-0" />}
                <span className="truncate">{tab.name}</span>
                <button
                  className="ml-1 p-0.5 rounded hover:bg-[#B84A4A]/20 hover:text-[#B84A4A] transition-colors shrink-0"
                  onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>

          {/* Editor area */}
          {activeFile ? (
            <div className="flex-1 flex overflow-hidden relative">
              {/* Line numbers */}
              <div
                ref={lineNumbersRef}
                className="w-12 bg-[#0A0A0F] text-right pr-2 py-2 text-xs text-[#4D4A42] select-none overflow-hidden shrink-0"
              >
                {Array.from({ length: lineCount }, (_, i) => (
                  <div key={i} className="leading-6">{i + 1}</div>
                ))}
              </div>
              {/* Code area */}
              <div className="flex-1 relative overflow-auto" ref={contentRef}>
                <textarea
                  ref={editorRef}
                  className="absolute inset-0 w-full h-full bg-transparent text-transparent caret-[#E8E4DC] p-2 text-xs leading-6 resize-none outline-none font-mono z-10 whitespace-pre"
                  value={activeFile.content}
                  onChange={e => updateContent(activeFile.id, e.target.value)}
                  onScroll={handleScroll}
                  spellCheck={false}
                />
                <pre
                  className="absolute inset-0 w-full h-full p-2 text-xs leading-6 pointer-events-none overflow-hidden font-mono"
                  aria-hidden="true"
                >
                  <code dangerouslySetInnerHTML={{
                    __html: highlightCode(activeFile.content, activeFile.language)
                  }} />
                </pre>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-[#4D4A42] text-sm">
              <div className="text-center">
                <FileCode className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>Open a file from the explorer to start editing</p>
                <p className="text-xs mt-1 opacity-60">Click on any file in the left sidebar</p>
              </div>
            </div>
          )}

          {/* Status bar */}
          {activeFile && (
            <div className="flex items-center justify-between px-3 py-1 bg-[#C9A84C]/10 text-[10px] text-[#8A8578]">
              <div className="flex items-center gap-3">
                <span>{activeFile.language.toUpperCase()}</span>
                {activeFile.isModified && <span className="text-[#D4B85A]">● Modified</span>}
              </div>
              <div className="flex items-center gap-3">
                <span>{lineCount} lines</span>
                <span>{activeFile.content.length} chars</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
