import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Plus,
  X,
  Clock,
  MapPin,
  Trash2,
} from 'lucide-react';
import {
  format,
  addMonths,
  subMonths,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addDays,
  isToday,
} from 'date-fns';
import { AnimatePresence, motion } from 'framer-motion';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface CalendarEvent {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time: string;
  description: string;
  color: string;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const STORAGE_KEY = 'cornstone-calendar-events';

const MEXICAN_HOLIDAYS: Record<number, Record<number, string>> = {
  0: { 1: 'New Year\'s Day' },
  1: { 5: 'Constitution Day' },
  2: { 21: 'Benito Juarez Day' },
  4: { 1: 'Labor Day' },
  8: { 16: 'Independence Day' },
  10: { 20: 'Revolution Day' },
  11: { 25: 'Christmas Day' },
};

const EVENT_COLORS = [
  { name: 'Gold', value: '#C9A84C' },
  { name: 'Cyan', value: '#4A9E9E' },
  { name: 'Green', value: '#5A9E6F' },
  { name: 'Purple', value: '#7B6FB8' },
  { name: 'Red', value: '#B84A4A' },
  { name: 'Blue', value: '#5A8AB8' },
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
function loadEvents(): CalendarEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [];
}

function saveEvents(events: CalendarEvent[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
}

function fmtDate(d: Date): string {
  return format(d, 'yyyy-MM-dd');
}

/* ------------------------------------------------------------------ */
/*  Event Modal                                                        */
/* ------------------------------------------------------------------ */
function EventModal({
  date,
  existingEvent,
  onSave,
  onDelete,
  onClose,
}: {
  date: Date;
  existingEvent?: CalendarEvent;
  onSave: (e: CalendarEvent) => void;
  onDelete?: (id: string) => void;
  onClose: () => void;
}) {
  const [title, setTitle] = useState(existingEvent?.title ?? '');
  const [time, setTime] = useState(existingEvent?.time ?? '09:00');
  const [description, setDescription] = useState(existingEvent?.description ?? '');
  const [color, setColor] = useState(existingEvent?.color ?? EVENT_COLORS[0].value);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSave({
      id: existingEvent?.id ?? `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: title.trim(),
      date: existingEvent?.date ?? fmtDate(date),
      time,
      description: description.trim(),
      color,
    });
    onClose();
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-[#030305]/60 backdrop-blur-sm" />
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="relative z-10 w-[420px] bg-[#1A1A26] border border-[#2A2A3E] rounded-xl shadow-[0_12px_48px_rgba(0,0,0,0.5)] p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-semibold text-[#E8E4DC]">
            {existingEvent ? 'Edit Event' : 'New Event'}
          </h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#222235] rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-[#8A8578]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Title</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Event title"
              autoFocus
              className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none transition-colors"
            />
          </div>

          <div className="flex gap-3">
            <div className="flex-1">
              <label className="block text-xs text-[#8A8578] mb-1">Date</label>
              <div className="h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] flex items-center">
                {format(date, 'MMM d, yyyy')}
              </div>
            </div>
            <div className="flex-1">
              <label className="block text-xs text-[#8A8578] mb-1">Time</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full h-9 px-3 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] focus:border-[#C9A84C] focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details..."
              rows={3}
              className="w-full px-3 py-2 bg-[#12121A] border border-[#2A2A3E] rounded-md text-sm text-[#E8E4DC] placeholder-[#4D4A42] focus:border-[#C9A84C] focus:outline-none resize-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs text-[#8A8578] mb-2">Color</label>
            <div className="flex gap-2">
              {EVENT_COLORS.map((c) => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setColor(c.value)}
                  className={`w-6 h-6 rounded-full border-2 transition-all ${
                    color === c.value ? 'border-[#E8E4DC] scale-110' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: c.value }}
                  title={c.name}
                />
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            {existingEvent && onDelete && (
              <button
                type="button"
                onClick={() => {
                  onDelete(existingEvent.id);
                  onClose();
                }}
                className="px-4 h-9 bg-[#B84A4A]/10 text-[#B84A4A] rounded-md text-sm font-medium hover:bg-[#B84A4A]/20 transition-colors flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete
              </button>
            )}
            <div className="flex-1" />
            <button
              type="button"
              onClick={onClose}
              className="px-4 h-9 bg-[#222235] text-[#E8E4DC] rounded-md text-sm font-medium hover:bg-[#2A2A3E] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 h-9 bg-[#C9A84C] text-[#030305] rounded-md text-sm font-semibold hover:bg-[#D4B85A] transition-colors"
            >
              Save
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Mini Calendar                                                      */
/* ------------------------------------------------------------------ */
function MiniCalendar({
  currentMonth,
  selectedDate,
  onSelectDate,
  events,
}: {
  currentMonth: Date;
  selectedDate: Date;
  onSelectDate: (d: Date) => void;
  events: CalendarEvent[];
}) {
  const days = useMemo(() => {
    const start = startOfWeek(startOfMonth(currentMonth));
    const end = endOfWeek(endOfMonth(currentMonth));
    return eachDayOfInterval({ start, end });
  }, [currentMonth]);

  return (
    <div className="mb-4">
      <div className="text-xs font-medium text-[#8A8578] mb-2 text-center">
        {format(currentMonth, 'MMMM yyyy')}
      </div>
      <div className="grid grid-cols-7 gap-0.5 text-center">
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
          <div key={i} className="text-[10px] text-[#4D4A42] py-0.5">{d}</div>
        ))}
        {days.map((day) => {
          const hasEvent = events.some((e) => e.date === fmtDate(day));
          return (
            <button
              key={day.toISOString()}
              onClick={() => onSelectDate(day)}
              className={`h-6 w-6 mx-auto rounded-full text-[10px] flex items-center justify-center transition-colors ${
                isSameDay(day, selectedDate)
                  ? 'bg-[#C9A84C] text-[#030305] font-bold'
                  : isToday(day)
                  ? 'text-[#C9A84C] font-bold border border-[#C9A84C]/50'
                  : isSameMonth(day, currentMonth)
                  ? 'text-[#E8E4DC] hover:bg-[#222235]'
                  : 'text-[#4D4A42]'
              }`}
            >
              {format(day, 'd')}
              {hasEvent && (
                <span
                  className="absolute bottom-0.5 w-1 h-1 rounded-full"
                  style={{
                    backgroundColor: events.find((e) => e.date === fmtDate(day))?.color || '#C9A84C',
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Week View                                                          */
/* ------------------------------------------------------------------ */
function WeekView({
  selectedDate,
  events,
  onDateClick,
}: {
  selectedDate: Date;
  events: CalendarEvent[];
  onDateClick: (d: Date) => void;
}) {
  const weekDays = useMemo(() => {
    const start = startOfWeek(selectedDate);
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  }, [selectedDate]);

  const hours = Array.from({ length: 24 }, (_, i) => i);

  return (
    <div className="flex-1 overflow-auto">
      <div className="grid grid-cols-8 border-b border-[#2A2A3E]">
        <div className="p-2 border-r border-[#2A2A3E]" />
        {weekDays.map((day) => (
          <div
            key={day.toISOString()}
            className={`p-2 text-center border-r border-[#2A2A3E] cursor-pointer hover:bg-[#222235]/50 transition-colors ${
              isToday(day) ? 'bg-[#C9A84C]/10' : ''
            }`}
            onClick={() => onDateClick(day)}
          >
            <div className={`text-xs ${isToday(day) ? 'text-[#C9A84C] font-bold' : 'text-[#8A8578]'}`}>
              {format(day, 'EEE')}
            </div>
            <div className={`text-sm mt-0.5 ${isToday(day) ? 'text-[#C9A84C]' : 'text-[#E8E4DC]'}`}>
              {format(day, 'd')}
            </div>
          </div>
        ))}
      </div>
      <div className="overflow-auto" style={{ maxHeight: '380px' }}>
        {hours.map((hour) => (
          <div key={hour} className="grid grid-cols-8 border-b border-[#2A2A3E]/50 min-h-[48px]">
            <div className="p-1.5 border-r border-[#2A2A3E] text-[10px] text-[#4D4A42] text-right pr-2 pt-2">
              {hour === 0 ? '12 AM' : hour < 12 ? `${hour} AM` : hour === 12 ? '12 PM' : `${hour - 12} PM`}
            </div>
            {weekDays.map((day) => {
              const dayEvents = events.filter(
                (e) => e.date === fmtDate(day) && parseInt(e.time.split(':')[0]) === hour
              );
              return (
                <div
                  key={day.toISOString()}
                  className="border-r border-[#2A2A3E]/50 p-0.5 relative hover:bg-[#222235]/30 transition-colors cursor-pointer"
                  onClick={() => onDateClick(day)}
                >
                  {dayEvents.map((evt) => (
                    <div
                      key={evt.id}
                      className="text-[10px] px-1.5 py-0.5 rounded mb-0.5 truncate text-white"
                      style={{ backgroundColor: evt.color + 'CC' }}
                      title={evt.title}
                    >
                      {evt.time} {evt.title}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Calendar App                                                  */
/* ------------------------------------------------------------------ */
export default function CalendarApp() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [events, setEvents] = useState<CalendarEvent[]>(loadEvents);
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | undefined>();
  const [viewMode, setViewMode] = useState<'month' | 'week'>('month');

  useEffect(() => {
    saveEvents(events);
  }, [events]);

  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const calStart = startOfWeek(monthStart);
    const calEnd = endOfWeek(monthEnd);
    return eachDayOfInterval({ start: calStart, end: calEnd });
  }, [currentMonth]);

  const selectedDateEvents = useMemo(
    () => events.filter((e) => e.date === fmtDate(selectedDate)).sort((a, b) => a.time.localeCompare(b.time)),
    [events, selectedDate]
  );

  const upcomingEvents = useMemo(
    () =>
      events
        .filter((e) => e.date >= fmtDate(new Date()))
        .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))
        .slice(0, 10),
    [events]
  );

  const getHoliday = useCallback((date: Date): string | undefined => {
    const month = date.getMonth();
    const day = date.getDate();
    return MEXICAN_HOLIDAYS[month]?.[day];
  }, []);

  const getEventsForDay = useCallback(
    (day: Date) => events.filter((e) => e.date === fmtDate(day)),
    [events]
  );

  const handlePrevMonth = () => setCurrentMonth((m) => subMonths(m, 1));
  const handleNextMonth = () => setCurrentMonth((m) => addMonths(m, 1));
  const handleToday = () => {
    const now = new Date();
    setCurrentMonth(now);
    setSelectedDate(now);
  };

  const handleDateClick = (day: Date) => {
    setSelectedDate(day);
    if (!isSameMonth(day, currentMonth)) {
      setCurrentMonth(startOfMonth(day));
    }
  };

  const handleSaveEvent = (event: CalendarEvent) => {
    setEvents((prev) => {
      const idx = prev.findIndex((e) => e.id === event.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = event;
        return next;
      }
      return [...prev, event];
    });
  };

  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((e) => e.id !== id));
  };

  const handleEventDotClick = (evt: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingEvent(evt);
    setShowEventModal(true);
  };

  return (
    <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex">
      {/* Sidebar */}
      <div className="w-[200px] border-r border-[#2A2A3E] p-4 flex flex-col overflow-auto">
        <button
          onClick={() => {
            setEditingEvent(undefined);
            setShowEventModal(true);
          }}
          className="mb-4 h-9 bg-[#C9A84C] text-[#030305] rounded-md text-sm font-semibold hover:bg-[#D4B85A] transition-colors flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Event
        </button>

        <MiniCalendar
          currentMonth={currentMonth}
          selectedDate={selectedDate}
          onSelectDate={handleDateClick}
          events={events}
        />

        <div className="mt-2">
          <div className="text-xs font-medium text-[#8A8578] mb-2">Upcoming</div>
          <div className="space-y-1.5 max-h-[180px] overflow-auto pr-1">
            {upcomingEvents.length === 0 && (
              <div className="text-[11px] text-[#4D4A42]">No upcoming events</div>
            )}
            {upcomingEvents.map((evt) => (
              <button
                key={evt.id}
                onClick={() => {
                  setSelectedDate(new Date(evt.date + 'T00:00:00'));
                  setCurrentMonth(startOfMonth(new Date(evt.date + 'T00:00:00')));
                }}
                className="w-full text-left p-2 rounded-md bg-[#1A1A26] border border-[#2A2A3E]/50 hover:border-[#3D3D5C] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: evt.color }} />
                  <span className="text-[11px] text-[#E8E4DC] truncate flex-1">{evt.title}</span>
                </div>
                <div className="text-[10px] text-[#8A8578] mt-0.5 ml-3.5">
                  {evt.time} &middot; {format(new Date(evt.date + 'T00:00:00'), 'MMM d')}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-auto pt-3 border-t border-[#2A2A3E]">
          <div className="text-[10px] text-[#4D4A42]">
            <MapPin className="w-3 h-3 inline mr-1" />
            Holidays: Mexico
          </div>
        </div>
      </div>

      {/* Main area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#2A2A3E]">
          <div className="flex items-center gap-3">
            <CalendarDays className="w-5 h-5 text-[#C9A84C]" />
            <h2 className="text-lg font-semibold text-[#E8E4DC] min-w-[180px]">
              {format(currentMonth, 'MMMM yyyy')}
            </h2>
            <div className="flex items-center gap-1 ml-2">
              <button
                onClick={handlePrevMonth}
                className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors"
              >
                <ChevronLeft className="w-4 h-4 text-[#8A8578]" />
              </button>
              <button
                onClick={handleNextMonth}
                className="p-1.5 hover:bg-[#222235] rounded-lg transition-colors"
              >
                <ChevronRight className="w-4 h-4 text-[#8A8578]" />
              </button>
            </div>
            <button
              onClick={handleToday}
              className="ml-2 px-3 h-8 bg-[#222235] hover:bg-[#2A2A3E] text-[#E8E4DC] rounded-md text-xs font-medium transition-colors border border-[#2A2A3E]"
            >
              Today
            </button>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-[#1A1A26] rounded-md border border-[#2A2A3E] overflow-hidden">
              {(['month', 'week'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className={`px-3 h-7 text-xs font-medium capitalize transition-colors ${
                    viewMode === mode
                      ? 'bg-[#C9A84C] text-[#030305]'
                      : 'text-[#8A8578] hover:text-[#E8E4DC]'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
            <button
              onClick={() => {
                setEditingEvent(undefined);
                setShowEventModal(true);
              }}
              className="p-1.5 bg-[#C9A84C] text-[#030305] rounded-md hover:bg-[#D4B85A] transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Calendar body */}
        <div className="flex-1 overflow-auto">
          {viewMode === 'month' ? (
            <div className="p-4">
              {/* Day headers */}
              <div className="grid grid-cols-7 mb-1">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                  <div key={d} className="text-center text-xs text-[#8A8578] font-medium py-2">
                    {d}
                  </div>
                ))}
              </div>

              {/* Grid */}
              <div className="grid grid-cols-7 gap-px bg-[#2A2A3E]/50 border border-[#2A2A3E]/50 rounded-lg overflow-hidden">
                {calendarDays.map((day) => {
                  const inMonth = isSameMonth(day, currentMonth);
                  const selected = isSameDay(day, selectedDate);
                  const today = isToday(day);
                  const holiday = getHoliday(day);
                  const dayEvents = getEventsForDay(day);

                  return (
                    <motion.div
                      key={day.toISOString()}
                      initial={false}
                      className={`min-h-[80px] p-1.5 cursor-pointer transition-colors relative ${
                        inMonth ? 'bg-[#12121A]' : 'bg-[#0A0A0F]'
                      } ${selected ? 'ring-1 ring-[#C9A84C] ring-inset bg-[#222235]/60' : ''} ${
                        today && !selected ? 'bg-[#C9A84C]/5' : ''
                      } hover:bg-[#222235]/40`}
                      onClick={() => handleDateClick(day)}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span
                          className={`text-xs w-6 h-6 flex items-center justify-center rounded-full ${
                            today
                              ? 'bg-[#C9A84C] text-[#030305] font-bold'
                              : selected
                              ? 'text-[#C9A84C] font-medium'
                              : inMonth
                              ? 'text-[#E8E4DC]'
                              : 'text-[#4D4A42]'
                          }`}
                        >
                          {format(day, 'd')}
                        </span>
                      </div>

                      {holiday && (
                        <div className="text-[9px] text-[#B84A4A] font-medium truncate leading-tight">
                          {holiday}
                        </div>
                      )}

                      <div className="flex flex-wrap gap-1 mt-1">
                        {dayEvents.slice(0, 3).map((evt) => (
                          <button
                            key={evt.id}
                            onClick={(e) => handleEventDotClick(evt, e)}
                            className="w-1.5 h-1.5 rounded-full flex-shrink-0 hover:scale-150 transition-transform"
                            style={{ backgroundColor: evt.color }}
                            title={`${evt.time} ${evt.title}`}
                          />
                        ))}
                        {dayEvents.length > 3 && (
                          <span className="text-[8px] text-[#4D4A42]">+{dayEvents.length - 3}</span>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          ) : (
            <WeekView
              selectedDate={selectedDate}
              events={events}
              onDateClick={handleDateClick}
            />
          )}
        </div>

        {/* Selected day events panel */}
        <div className="border-t border-[#2A2A3E] px-5 py-3 max-h-[160px] overflow-auto">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-[#E8E4DC]">
              {format(selectedDate, 'EEEE, MMMM d, yyyy')}
            </div>
            <div className="text-xs text-[#8A8578]">
              {selectedDateEvents.length} event{selectedDateEvents.length !== 1 ? 's' : ''}
            </div>
          </div>
          {selectedDateEvents.length === 0 ? (
            <div className="text-xs text-[#4D4A42]">No events for this day</div>
          ) : (
            <div className="space-y-1.5">
              {selectedDateEvents.map((evt) => (
                <button
                  key={evt.id}
                  onClick={() => {
                    setEditingEvent(evt);
                    setShowEventModal(true);
                  }}
                  className="w-full flex items-center gap-3 p-2 rounded-md bg-[#1A1A26] border border-[#2A2A3E]/50 hover:border-[#3D3D5C] transition-colors text-left"
                >
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: evt.color }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-[#E8E4DC] truncate">{evt.title}</div>
                    {evt.description && (
                      <div className="text-[10px] text-[#8A8578] truncate">{evt.description}</div>
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-[#8A8578] flex-shrink-0">
                    <Clock className="w-3 h-3" />
                    {evt.time}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Event Modal */}
      <AnimatePresence>
        {showEventModal && (
          <EventModal
            date={selectedDate}
            existingEvent={editingEvent}
            onSave={handleSaveEvent}
            onDelete={editingEvent ? handleDeleteEvent : undefined}
            onClose={() => {
              setShowEventModal(false);
              setEditingEvent(undefined);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
