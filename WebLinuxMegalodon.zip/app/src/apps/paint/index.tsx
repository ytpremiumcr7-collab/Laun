import { useState, useRef, useCallback, useEffect } from 'react';
import {
  Pencil, Paintbrush, Eraser, Minus, Square, Circle,
  PaintBucket, Pipette, Type, Trash2, Undo2, Redo2,
  Download, Plus, Minus as MinusIcon
} from 'lucide-react';

type Tool = 'pencil' | 'brush' | 'eraser' | 'line' | 'rect' | 'circle' | 'fill' | 'eyedropper' | 'text';

interface Point { x: number; y: number }

const PALETTE = [
  '#000000', '#FFFFFF', '#808080', '#C0C0C0',
  '#B84A4A', '#D4953A', '#C9A84C', '#5A9E6F',
  '#4A9E9E', '#5A8AB8', '#7B6FB8', '#8B7340',
  '#FF6B6B', '#FFD93D', '#6BCB77', '#4D96FF',
  '#9B59B6', '#E17055', '#FDCB6E', '#55EFC4',
];

const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;

export default function Paint() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [tool, setTool] = useState<Tool>('pencil');
  const [color, setColor] = useState('#C9A84C');
  const [brushSize, setBrushSize] = useState(3);
  const [opacity, setOpacity] = useState(100);
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState<Point | null>(null);
  const [currentPos, setCurrentPos] = useState<Point | null>(null);
  const [fillShape, setFillShape] = useState(false);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [textInput, setTextInput] = useState('');
  const [showTextInput, setShowTextInput] = useState(false);
  const [textPos, setTextPos] = useState<Point | null>(null);

  const tools: { key: Tool; icon: any; label: string }[] = [
    { key: 'pencil', icon: Pencil, label: 'Pencil' },
    { key: 'brush', icon: Paintbrush, label: 'Brush' },
    { key: 'eraser', icon: Eraser, label: 'Eraser' },
    { key: 'line', icon: Minus, label: 'Line' },
    { key: 'rect', icon: Square, label: 'Rect' },
    { key: 'circle', icon: Circle, label: 'Circle' },
    { key: 'fill', icon: PaintBucket, label: 'Fill' },
    { key: 'eyedropper', icon: Pipette, label: 'Pick' },
    { key: 'text', icon: Type, label: 'Text' },
  ];

  /* Initialize canvas */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    saveState(ctx);
  }, []);

  const saveState = useCallback((ctx: CanvasRenderingContext2D) => {
    const imageData = ctx.getImageData(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    setHistory(prev => [...prev.slice(0, historyIndex + 1), imageData].slice(-50));
    setHistoryIndex(prev => Math.min(prev + 1, 49));
  }, [historyIndex]);

  const getCoords = useCallback((e: React.MouseEvent<HTMLCanvasElement>): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }, []);

  const startDrawing = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getCoords(e);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (tool === 'eyedropper') {
      const pixel = ctx.getImageData(coords.x, coords.y, 1, 1).data;
      const hex = '#' + [pixel[0], pixel[1], pixel[2]].map(c => c.toString(16).padStart(2, '0')).join('');
      setColor(hex.toUpperCase());
      setTool('pencil');
      return;
    }

    if (tool === 'fill') {
      floodFill(Math.floor(coords.x), Math.floor(coords.y), color);
      const newCtx = canvas.getContext('2d');
      if (newCtx) saveState(newCtx);
      return;
    }

    if (tool === 'text') {
      setTextPos(coords);
      setShowTextInput(true);
      return;
    }

    setIsDrawing(true);
    setStartPos(coords);
    setCurrentPos(coords);

    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    ctx.strokeStyle = tool === 'eraser' ? '#FFFFFF' : color;
    ctx.lineWidth = brushSize;
    ctx.lineCap = tool === 'brush' ? 'round' : 'butt';
    ctx.lineJoin = 'round';
    ctx.globalAlpha = opacity / 100;
  }, [tool, color, brushSize, opacity, getCoords, saveState]);

  const draw = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getCoords(e);
    setCurrentPos(coords);
    if (!isDrawing || !startPos) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (tool === 'pencil' || tool === 'brush' || tool === 'eraser') {
      ctx.lineTo(coords.x, coords.y);
      ctx.stroke();
    }
  }, [isDrawing, startPos, tool, getCoords]);

  const stopDrawing = useCallback(() => {
    if (!isDrawing || !startPos || !currentPos) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (tool === 'line' || tool === 'rect' || tool === 'circle') {
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.lineWidth = brushSize;
      ctx.globalAlpha = opacity / 100;

      if (tool === 'line') {
        ctx.beginPath();
        ctx.moveTo(startPos.x, startPos.y);
        ctx.lineTo(currentPos.x, currentPos.y);
        ctx.stroke();
      } else if (tool === 'rect') {
        const w = currentPos.x - startPos.x;
        const h = currentPos.y - startPos.y;
        if (fillShape) {
          ctx.fillRect(startPos.x, startPos.y, w, h);
        }
        ctx.strokeRect(startPos.x, startPos.y, w, h);
      } else if (tool === 'circle') {
        const rx = Math.abs(currentPos.x - startPos.x) / 2;
        const ry = Math.abs(currentPos.y - startPos.y) / 2;
        const cx = (startPos.x + currentPos.x) / 2;
        const cy = (startPos.y + currentPos.y) / 2;
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        if (fillShape) ctx.fill();
        ctx.stroke();
      }
    }

    ctx.globalAlpha = 1;
    setIsDrawing(false);
    setStartPos(null);
    setCurrentPos(null);
    saveState(ctx);
  }, [isDrawing, startPos, currentPos, tool, color, brushSize, opacity, fillShape, saveState]);

  const floodFill = useCallback((startX: number, startY: number, fillColor: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    const data = imageData.data;

    const hexToRgba = (hex: string) => {
      const r = parseInt(hex.slice(1, 3), 16);
      const g = parseInt(hex.slice(3, 5), 16);
      const b = parseInt(hex.slice(5, 7), 16);
      return [r, g, b, 255];
    };

    const targetColor = hexToRgba(fillColor);
    const startIdx = (startY * CANVAS_WIDTH + startX) * 4;
    const startR = data[startIdx];
    const startG = data[startIdx + 1];
    const startB = data[startIdx + 2];

    if (
      startR === targetColor[0] &&
      startG === targetColor[1] &&
      startB === targetColor[2]
    ) return;

    const stack: [number, number][] = [[startX, startY]];
    const visited = new Set<number>();

    while (stack.length > 0) {
      const [x, y] = stack.pop()!;
      const idx = (y * CANVAS_WIDTH + x) * 4;
      const key = y * CANVAS_WIDTH + x;

      if (x < 0 || x >= CANVAS_WIDTH || y < 0 || y >= CANVAS_HEIGHT) continue;
      if (visited.has(key)) continue;
      if (data[idx] !== startR || data[idx + 1] !== startG || data[idx + 2] !== startB) continue;

      visited.add(key);
      data[idx] = targetColor[0];
      data[idx + 1] = targetColor[1];
      data[idx + 2] = targetColor[2];

      stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
    }

    ctx.putImageData(imageData, 0, 0);
  }, []);

  const undo = useCallback(() => {
    if (historyIndex <= 0) return;
    const newIndex = historyIndex - 1;
    setHistoryIndex(newIndex);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx || !history[newIndex]) return;
    ctx.putImageData(history[newIndex], 0, 0);
  }, [history, historyIndex]);

  const redo = useCallback(() => {
    if (historyIndex >= history.length - 1) return;
    const newIndex = historyIndex + 1;
    setHistoryIndex(newIndex);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx || !history[newIndex]) return;
    ctx.putImageData(history[newIndex], 0, 0);
  }, [history, historyIndex]);

  const clearCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    saveState(ctx);
  }, [saveState]);

  const saveImage = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = 'painting.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
  }, []);

  const addText = useCallback(() => {
    if (!textPos || !textInput.trim()) { setShowTextInput(false); return; }
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.font = `${brushSize * 3 + 10}px Inter, sans-serif`;
    ctx.fillStyle = color;
    ctx.globalAlpha = opacity / 100;
    ctx.fillText(textInput, textPos.x, textPos.y);
    ctx.globalAlpha = 1;
    saveState(ctx);
    setShowTextInput(false);
    setTextInput('');
    setTextPos(null);
  }, [textPos, textInput, color, brushSize, opacity, saveState]);

  /* Keyboard shortcuts */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'z') { e.preventDefault(); undo(); }
      if (e.ctrlKey && e.key === 'y') { e.preventDefault(); redo(); }
      if (e.key === '[') setBrushSize(prev => Math.max(1, prev - 1));
      if (e.key === ']') setBrushSize(prev => Math.min(50, prev + 1));
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [undo, redo]);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Top toolbar */}
      <div className="flex items-center gap-1 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        {/* Tools */}
        <div className="flex items-center gap-0.5">
          {tools.map(({ key, icon: Icon, label }) => (
            <button
              key={key}
              title={label}
              className={`p-2 rounded transition-colors ${tool === key ? 'bg-[#C9A84C]/20 text-[#C9A84C]' : 'hover:bg-[#222235] text-[#8A8578]'}`}
              onClick={() => setTool(key)}
            >
              <Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-[#2A2A3E] mx-1" />

        {/* Brush size */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[#8A8578]">Size</span>
          <button className="p-1 rounded hover:bg-[#222235]" onClick={() => setBrushSize(Math.max(1, brushSize - 1))}>
            <MinusIcon className="w-3 h-3" />
          </button>
          <span className="text-[10px] w-5 text-center font-mono">{brushSize}</span>
          <button className="p-1 rounded hover:bg-[#222235]" onClick={() => setBrushSize(Math.min(50, brushSize + 1))}>
            <Plus className="w-3 h-3" />
          </button>
        </div>

        {/* Opacity */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[#8A8578]">Op</span>
          <input
            type="range" min={10} max={100} value={opacity}
            onChange={e => setOpacity(parseInt(e.target.value))}
            className="w-16 h-1 accent-[#C9A84C]"
          />
          <span className="text-[10px] w-6 font-mono">{opacity}%</span>
        </div>

        {/* Fill toggle */}
        <label className="flex items-center gap-1 cursor-pointer ml-1">
          <input type="checkbox" checked={fillShape} onChange={e => setFillShape(e.target.checked)} className="accent-[#C9A84C] w-3 h-3" />
          <span className="text-[10px] text-[#8A8578]">Fill</span>
        </label>

        <div className="flex-1" />

        {/* Actions */}
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={undo}>
          <Undo2 className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#222235] transition-colors" onClick={redo}>
          <Redo2 className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2 py-1.5 rounded hover:bg-[#B84A4A]/20 text-[#B84A4A] transition-colors" onClick={clearCanvas}>
          <Trash2 className="w-3.5 h-3.5" />
        </button>
        <button className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#C9A84C] text-[#030305] hover:bg-[#D4B85A] transition-colors" onClick={saveImage}>
          <Download className="w-3.5 h-3.5" /> Save
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Color palette */}
        <div className="w-10 bg-[#0A0A0F] border-r border-[#2A2A3E] flex flex-col items-center py-2 gap-1 shrink-0 overflow-y-auto">
          {/* Current color swatch */}
          <div className="w-7 h-7 rounded border-2 border-[#E8E4DC] mb-1" style={{ background: color }} />
          {PALETTE.map(c => (
            <button
              key={c}
              className={`w-5 h-5 rounded-sm border transition-all hover:scale-110 ${color === c ? 'border-[#E8E4DC] scale-110' : 'border-[#2A2A3E]'}`}
              style={{ background: c }}
              onClick={() => setColor(c)}
            />
          ))}
          {/* Custom color picker */}
          <input
            type="color"
            value={color}
            onChange={e => setColor(e.target.value)}
            className="w-6 h-6 rounded cursor-pointer border-0 p-0 mt-1"
          />
        </div>

        {/* Canvas */}
        <div className="flex-1 flex items-center justify-center bg-[#0A0A0F] overflow-auto p-4">
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={CANVAS_WIDTH}
              height={CANVAS_HEIGHT}
              className="border border-[#2A2A3E] shadow-lg cursor-crosshair"
              style={{ maxWidth: '100%', maxHeight: 'calc(100vh - 140px)', imageRendering: 'auto' }}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
            />
            {/* Text input overlay */}
            {showTextInput && textPos && (
              <div
                className="absolute z-10"
                style={{
                  left: `${(textPos.x / CANVAS_WIDTH) * 100}%`,
                  top: `${(textPos.y / CANVAS_HEIGHT) * 100}%`,
                }}
              >
                <input
                  type="text"
                  autoFocus
                  className="bg-transparent border-b border-[#C9A84C] text-[#E8E4DC] outline-none text-sm px-1"
                  style={{ color, textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}
                  value={textInput}
                  onChange={e => setTextInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') addText(); if (e.key === 'Escape') setShowTextInput(false); }}
                  placeholder="Type text..."
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
