import { useState, useMemo, useCallback } from 'react';
import {
  Regex, Trash2, Lightbulb, ChevronDown,
  CheckCircle2, XCircle, Replace
} from 'lucide-react';

/* ── preset patterns ── */
const PRESETS = [
  { name: 'Email', pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$', explanation: 'Matches email addresses: local@domain.tld', flags: '' },
  { name: 'URL', pattern: 'https?://(?:[-\\w.])+(?:[:\\d]+)?(?:/(?:[\\w/_.])*(?:\\?(?:[\\w&=%.])*)?(?:#(?:[\\w.])*)?)?', explanation: 'Matches HTTP/HTTPS URLs', flags: 'i' },
  { name: 'Phone', pattern: '\\+?1?\\s*\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})', explanation: 'Matches US phone numbers with optional country code', flags: '' },
  { name: 'IPv4', pattern: '^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$', explanation: 'Matches IPv4 addresses (0.0.0.0 - 255.255.255.255)', flags: '' },
  { name: 'Date (YYYY-MM-DD)', pattern: '^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$', explanation: 'Matches dates in ISO format: YYYY-MM-DD', flags: '' },
  { name: 'Hex Color', pattern: '^#(?:[0-9a-fA-F]{3}){1,2}$', explanation: 'Matches hex color codes: #FFF or #FFFFFF', flags: 'i' },
  { name: 'Credit Card', pattern: '^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12})$', explanation: 'Matches major credit card numbers (Visa, MC, Amex, Discover, Diners, JCB)', flags: '' },
];

const SAMPLE_TEXT = `Contact Information:
Alice Johnson - alice@cornstone.dev
Bob Smith - bob.smith@example.org
Office: +1 (555) 123-4567
Mobile: 555.987.6543

Website: https://cornstone.dev
Documentation: http://docs.cornstone.dev/guide?section=api#intro

Server: 192.168.1.100
Backup: 10.0.0.255
Gateway: 256.300.1.1 (invalid)

Colors:
Primary: #C9A84C
Secondary: #1A1A26
Accent: #5A9E6F
Invalid: #GGGGGG

Appointments:
2025-03-15 - Team Standup
2025-12-31 - Year End Review
Invalid: 2025-13-45`;

interface MatchInfo {
  match: string;
  index: number;
  length: number;
  groups: string[];
}

export default function RegexTester() {
  const [pattern, setPattern] = useState('^\\w+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$');
  const [flags, setFlags] = useState({ g: true, i: false, m: false, s: false, u: false });
  const [testText, setTestText] = useState(SAMPLE_TEXT);
  const [replaceText, setReplaceText] = useState('[REDACTED]');
  const [showPresets, setShowPresets] = useState(false);

  const activeFlags = useMemo(() =>
    Object.entries(flags).filter(([, v]) => v).map(([k]) => k).join('')
  , [flags]);

  const { regex, matches, error, highlightedText, replacedText } = useMemo(() => {
    const result: {
      regex: RegExp | null;
      matches: MatchInfo[];
      error: string;
      highlightedText: string;
      replacedText: string;
    } = { regex: null, matches: [], error: '', highlightedText: '', replacedText: '' };

    if (!pattern) {
      result.highlightedText = escapeHtml(testText);
      result.replacedText = testText;
      return result;
    }

    try {
      const fl = activeFlags || '';
      const effectiveFlags = fl.includes('g') ? fl : fl + 'g';
      result.regex = new RegExp(pattern, effectiveFlags);
      result.error = '';

      /* matches */
      const matchArr: MatchInfo[] = [];
      let m: RegExpExecArray | null;
      const tempRegex = new RegExp(pattern, effectiveFlags);
      const text = testText;

      /* For highlighting */
      const hlColors = ['#5A9E6F', '#C9A84C', '#4A9E9E', '#7B6FB8'];
      let lastIndex = 0;
      const hlParts: string[] = [];

      /* Replacement */
      let replaceLast = 0;
      const replaceParts: string[] = [];

      while ((m = tempRegex.exec(text)) !== null) {
        if (m.index === tempRegex.lastIndex) tempRegex.lastIndex++;

        matchArr.push({
          match: m[0],
          index: m.index,
          length: m[0].length,
          groups: m.slice(1).filter(Boolean),
        });

        /* highlight */
        hlParts.push(escapeHtml(text.slice(lastIndex, m.index)));
        const color = hlColors[matchArr.length % hlColors.length];
        hlParts.push(`<mark style="background:${color}30;border-bottom:2px solid ${color};color:#E8E4DC;border-radius:2px;padding:0 1px">${escapeHtml(m[0])}</mark>`);
        lastIndex = m.index + m[0].length;

        /* replacement */
        replaceParts.push(text.slice(replaceLast, m.index));
        replaceParts.push(replaceText);
        replaceLast = m.index + m[0].length;
      }

      hlParts.push(escapeHtml(text.slice(lastIndex)));
      result.highlightedText = hlParts.join('');

      replaceParts.push(text.slice(replaceLast));
      result.replacedText = replaceParts.join('');

      result.matches = matchArr;
    } catch (e) {
      result.error = e instanceof Error ? e.message : 'Invalid regex';
      result.highlightedText = escapeHtml(testText);
      result.replacedText = testText;
    }

    return result;
  }, [pattern, activeFlags, testText, replaceText]);

  const applyPreset = useCallback((preset: typeof PRESETS[0]) => {
    setPattern(preset.pattern);
    const newFlags = { g: false, i: false, m: false, s: false, u: false };
    for (const f of preset.flags) {
      if (f in newFlags) (newFlags as Record<string, boolean>)[f] = true;
    }
    setFlags(newFlags);
    setShowPresets(false);
  }, []);

  const getExplanation = useMemo(() => {
    const preset = PRESETS.find(p => p.pattern === pattern);
    if (preset) return preset.explanation;

    const parts: string[] = [];
    if (pattern.includes('^')) parts.push('^ asserts position at start of line');
    if (pattern.includes('$')) parts.push('$ asserts position at end of line');
    if (pattern.includes('\\d')) parts.push('\\d matches any digit (0-9)');
    if (pattern.includes('\\w')) parts.push('\\w matches any word character (a-z, A-Z, 0-9, _)');
    if (pattern.includes('\\s')) parts.push('\\s matches any whitespace character');
    if (pattern.includes('.')) parts.push('. matches any character except newline');
    if (pattern.includes('*')) parts.push('* matches 0 or more of the preceding');
    if (pattern.includes('+')) parts.push('+ matches 1 or more of the preceding');
    if (pattern.includes('?')) parts.push('? matches 0 or 1 of the preceding');
    if (pattern.includes('|')) parts.push('| acts as an OR operator');
    if (pattern.includes('[]')) parts.push('[...] defines a character class');
    if (pattern.includes('()')) parts.push('(...) creates a capturing group');
    if (pattern.includes('{')) parts.push('{n,m} specifies repetition count');

    return parts.length > 0 ? parts.join('\n') : 'Custom regex pattern';
  }, [pattern]);

  return (
    <div className="w-full h-full bg-[#030305] text-[#E8E4DC] flex flex-col overflow-hidden text-xs">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#12121A] border-b border-[#2A2A3E] shrink-0 flex-wrap">
        <div className="relative">
          <button
            className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E] transition-colors"
            onClick={() => setShowPresets(!showPresets)}
          >
            <Regex className="w-3.5 h-3.5" /> Presets <ChevronDown className="w-3 h-3" />
          </button>
          {showPresets && (
            <div className="absolute top-full left-0 mt-1 w-56 bg-[#1A1A26] border border-[#2A2A3E] rounded shadow-lg z-50">
              {PRESETS.map(p => (
                <button
                  key={p.name}
                  className="w-full text-left px-3 py-2 hover:bg-[#222235] transition-colors border-b border-[#2A2A3E] last:border-0"
                  onClick={() => applyPreset(p)}
                >
                  <div className="text-[#E8E4DC]">{p.name}</div>
                  <div className="text-[#4D4A42] truncate mt-0.5">/{p.pattern}/{p.flags}</div>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="w-px h-5 bg-[#2A2A3E]" />
        <span className="text-[#4D4A42]">Flags:</span>
        {(['g', 'i', 'm', 's', 'u'] as const).map(f => (
          <button
            key={f}
            className={`w-7 h-7 rounded text-xs font-mono transition-colors ${
              flags[f] ? 'bg-[#C9A84C]/20 text-[#C9A84C] border border-[#C9A84C]' : 'bg-[#1A1A26] text-[#8A8578] border border-[#2A2A3E] hover:bg-[#222235]'
            }`}
            onClick={() => setFlags(prev => ({ ...prev, [f]: !prev[f] }))}
            title={f === 'g' ? 'Global' : f === 'i' ? 'Case insensitive' : f === 'm' ? 'Multiline' : f === 's' ? 'DotAll' : 'Unicode'}
          >
            {f}
          </button>
        ))}
        <div className="flex-1" />
        <button
          className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-[#1A1A26] hover:bg-[#222235] border border-[#2A2A3E]"
          onClick={() => setTestText('')}
        >
          <Trash2 className="w-3 h-3" /> Clear
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left: Pattern + Test + Replace */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Pattern input */}
          <div className="px-3 py-2 border-b border-[#2A2A3E] shrink-0">
            <label className="text-[10px] text-[#4D4A42] uppercase tracking-wider mb-1 block">Pattern</label>
            <div className="flex items-center gap-1">
              <span className="text-[#8A8578] font-mono text-sm">/</span>
              <input
                type="text"
                className={`flex-1 bg-[#0A0A0F] border rounded px-2 py-1.5 font-mono text-sm outline-none transition-colors ${
                  error ? 'border-[#B84A4A] text-[#B84A4A]' : 'border-[#2A2A3E] focus:border-[#C9A84C] text-[#E8E4DC]'
                }`}
                value={pattern}
                onChange={e => setPattern(e.target.value)}
                placeholder="Enter regex pattern..."
              />
              <span className="text-[#8A8578] font-mono text-sm">/{activeFlags}</span>
            </div>
            {error && (
              <div className="flex items-center gap-1 mt-1 text-[#B84A4A]">
                <XCircle className="w-3 h-3" /> {error}
              </div>
            )}
            {!error && regex && (
              <div className="flex items-center gap-1 mt-1 text-[#5A9E6F]">
                <CheckCircle2 className="w-3 h-3" /> Valid regex — {matches.length} match{matches.length !== 1 ? 'es' : ''}
              </div>
            )}
          </div>

          {/* Test text */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="px-3 py-1 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
              Test String
            </div>
            <div className="flex-1 overflow-auto p-3 bg-[#0A0A0F] font-mono text-xs whitespace-pre-wrap"
              dangerouslySetInnerHTML={{ __html: highlightedText }}
            />
            <textarea
              className="absolute opacity-0 pointer-events-none"
              value={testText}
              onChange={e => setTestText(e.target.value)}
            />
          </div>

          {/* Hidden textarea overlay for editing */}
          <div className="flex-1 flex flex-col min-h-0 -mt-full">
            <div className="shrink-0 h-5" /> {/* spacer for label */}
            <textarea
              className="flex-1 bg-[#0A0A0F] font-mono text-xs p-3 resize-none outline-none text-[#E8E4DC] whitespace-pre-wrap overflow-auto"
              value={testText}
              onChange={e => setTestText(e.target.value)}
              spellCheck={false}
              style={{ color: 'transparent', caretColor: '#E8E4DC' }}
            />
          </div>

          {/* Replace */}
          <div className="px-3 py-2 border-t border-[#2A2A3E] shrink-0">
            <label className="text-[10px] text-[#4D4A42] uppercase tracking-wider mb-1 block">Replace</label>
            <div className="flex items-center gap-2">
              <Replace className="w-3.5 h-3.5 text-[#8A8578]" />
              <input
                type="text"
                className="flex-1 bg-[#0A0A0F] border border-[#2A2A3E] rounded px-2 py-1.5 font-mono text-xs outline-none focus:border-[#C9A84C]"
                value={replaceText}
                onChange={e => setReplaceText(e.target.value)}
                placeholder="Replacement text..."
              />
            </div>
            <div className="mt-2 p-2 bg-[#0A0A0F] rounded border border-[#2A2A3E] font-mono text-xs whitespace-pre-wrap max-h-24 overflow-auto">
              {replacedText}
            </div>
          </div>
        </div>

        {/* Right: Matches + Explanation */}
        <div className="w-64 border-l border-[#2A2A3E] flex flex-col overflow-hidden shrink-0">
          <div className="px-3 py-2 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E] shrink-0">
            Matches ({matches.length})
          </div>
          <div className="flex-1 overflow-auto p-2">
            {matches.length === 0 ? (
              <p className="text-[#4D4A42] text-center mt-4">No matches</p>
            ) : (
              <div className="flex flex-col gap-1.5">
                {matches.map((m, i) => (
                  <div key={i} className="p-2 rounded bg-[#12121A] border border-[#2A2A3E]">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] text-[#C9A84C]">Match {i + 1}</span>
                      <span className="text-[10px] text-[#4D4A42]">pos {m.index}</span>
                    </div>
                    <div className="font-mono text-xs text-[#5A9E6F] break-all">{m.match}</div>
                    {m.groups.length > 0 && (
                      <div className="mt-1 flex flex-col gap-0.5">
                        {m.groups.map((g, gi) => (
                          <div key={gi} className="text-[10px] text-[#4A9E9E]">
                            Group {gi + 1}: <span className="font-mono">{g}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Explanation */}
          <div className="border-t border-[#2A2A3E] shrink-0">
            <div className="flex items-center gap-1 px-3 py-1.5 text-[10px] text-[#4D4A42] uppercase tracking-wider border-b border-[#2A2A3E]">
              <Lightbulb className="w-3 h-3" /> Explanation
            </div>
            <div className="p-2 text-[10px] text-[#8A8578] whitespace-pre-line leading-relaxed max-h-32 overflow-auto">
              {getExplanation}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
