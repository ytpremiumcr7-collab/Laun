import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AppDefinition } from '@/types';

const ALL_APPS: AppDefinition[] = [
  // System
  { id: 'file-manager', name: 'File Manager', icon: 'FolderOpen', category: 'system', component: 'FileManager', defaultSize: { width: 900, height: 600 }, minSize: { width: 400, height: 300 }, pinned: true },
  { id: 'terminal', name: 'Terminal', icon: 'Terminal', category: 'system', component: 'Terminal', defaultSize: { width: 700, height: 450 }, minSize: { width: 400, height: 250 }, pinned: true },
  { id: 'text-editor', name: 'Text Editor', icon: 'FileText', category: 'system', component: 'TextEditor', defaultSize: { width: 700, height: 500 }, minSize: { width: 400, height: 300 }, pinned: true },
  { id: 'system-monitor', name: 'System Monitor', icon: 'Activity', category: 'system', component: 'SystemMonitor', defaultSize: { width: 800, height: 550 }, minSize: { width: 400, height: 300 }, pinned: false },
  { id: 'settings', name: 'Settings', icon: 'Settings', category: 'system', component: 'Settings', defaultSize: { width: 700, height: 500 }, minSize: { width: 500, height: 400 }, pinned: true },
  { id: 'calculator', name: 'Calculator', icon: 'Calculator', category: 'system', component: 'Calculator', defaultSize: { width: 340, height: 500 }, minSize: { width: 280, height: 400 }, pinned: true },
  { id: 'calendar', name: 'Calendar', icon: 'Calendar', category: 'system', component: 'Calendar', defaultSize: { width: 500, height: 450 }, minSize: { width: 350, height: 350 }, pinned: false },
  { id: 'clock', name: 'Clock', icon: 'Clock', category: 'system', component: 'Clock', defaultSize: { width: 320, height: 200 }, minSize: { width: 200, height: 150 }, pinned: false },
  { id: 'trash', name: 'Trash', icon: 'Trash2', category: 'system', component: 'Trash', defaultSize: { width: 600, height: 400 }, minSize: { width: 400, height: 300 }, pinned: false },
  // Productivity
  { id: 'spreadsheet', name: 'Spreadsheet', icon: 'Table2', category: 'productivity', component: 'Spreadsheet', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'presentation', name: 'Presentation', icon: 'Presentation', category: 'productivity', component: 'Presentation', defaultSize: { width: 900, height: 600 }, minSize: { width: 600, height: 450 }, pinned: false },
  { id: 'pdf-viewer', name: 'PDF Viewer', icon: 'FileType', category: 'productivity', component: 'PdfViewer', defaultSize: { width: 800, height: 600 }, minSize: { width: 400, height: 500 }, pinned: false },
  { id: 'notes', name: 'Notes', icon: 'StickyNote', category: 'productivity', component: 'Notes', defaultSize: { width: 500, height: 500 }, minSize: { width: 300, height: 300 }, pinned: false },
  { id: 'task-manager', name: 'Task Manager', icon: 'CheckSquare', category: 'productivity', component: 'TaskManager', defaultSize: { width: 550, height: 500 }, minSize: { width: 350, height: 350 }, pinned: false },
  { id: 'password-manager', name: 'Password Manager', icon: 'KeyRound', category: 'productivity', component: 'PasswordManager', defaultSize: { width: 500, height: 450 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'whiteboard', name: 'Whiteboard', icon: 'Pencil', category: 'productivity', component: 'Whiteboard', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Development
  { id: 'code-editor', name: 'Code Editor', icon: 'Code2', category: 'development', component: 'CodeEditor', defaultSize: { width: 1000, height: 650 }, minSize: { width: 500, height: 400 }, pinned: true },
  { id: 'json-viewer', name: 'JSON Viewer', icon: 'Braces', category: 'development', component: 'JsonViewer', defaultSize: { width: 700, height: 500 }, minSize: { width: 400, height: 300 }, pinned: false },
  { id: 'regex-tester', name: 'Regex Tester', icon: 'Search', category: 'development', component: 'RegexTester', defaultSize: { width: 650, height: 500 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'base64-encoder', name: 'Base64 Encoder', icon: 'Hash', category: 'development', component: 'Base64Encoder', defaultSize: { width: 550, height: 450 }, minSize: { width: 350, height: 300 }, pinned: false },
  { id: 'api-client', name: 'API Client', icon: 'Globe', category: 'development', component: 'ApiClient', defaultSize: { width: 800, height: 550 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'color-picker', name: 'Color Picker', icon: 'Palette', category: 'development', component: 'ColorPicker', defaultSize: { width: 450, height: 400 }, minSize: { width: 350, height: 300 }, pinned: false },
  { id: 'diff-tool', name: 'Diff Tool', icon: 'GitCompare', category: 'development', component: 'DiffTool', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'git-dashboard', name: 'Git Dashboard', icon: 'GitBranch', category: 'development', component: 'GitDashboard', defaultSize: { width: 800, height: 550 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Media
  { id: 'image-editor', name: 'Image Editor', icon: 'Image', category: 'media', component: 'ImageEditor', defaultSize: { width: 900, height: 650 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'music-player', name: 'Music Player', icon: 'Music', category: 'media', component: 'MusicPlayer', defaultSize: { width: 400, height: 550 }, minSize: { width: 300, height: 400 }, pinned: false },
  { id: 'video-player', name: 'Video Player', icon: 'PlayCircle', category: 'media', component: 'VideoPlayer', defaultSize: { width: 800, height: 500 }, minSize: { width: 400, height: 300 }, pinned: false },
  { id: 'paint', name: 'Paint', icon: 'Paintbrush', category: 'media', component: 'Paint', defaultSize: { width: 800, height: 600 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'svg-editor', name: 'SVG Editor', icon: 'PenTool', category: 'media', component: 'SvgEditor', defaultSize: { width: 800, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'ascii-art', name: 'ASCII Art', icon: 'Type', category: 'media', component: 'AsciiArt', defaultSize: { width: 650, height: 500 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'chart-maker', name: 'Chart Maker', icon: 'BarChart3', category: 'media', component: 'ChartMaker', defaultSize: { width: 800, height: 550 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Communication
  { id: 'web-browser', name: 'Browser', icon: 'Globe', category: 'communication', component: 'WebBrowser', defaultSize: { width: 1000, height: 650 }, minSize: { width: 500, height: 400 }, pinned: true },
  { id: 'email-client', name: 'Email', icon: 'Mail', category: 'communication', component: 'EmailClient', defaultSize: { width: 900, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  { id: 'chat', name: 'Chat', icon: 'MessageSquare', category: 'communication', component: 'Chat', defaultSize: { width: 500, height: 550 }, minSize: { width: 350, height: 400 }, pinned: false },
  { id: 'rss-reader', name: 'RSS Reader', icon: 'Rss', category: 'communication', component: 'RssReader', defaultSize: { width: 700, height: 550 }, minSize: { width: 400, height: 350 }, pinned: false },
  { id: 'network-scanner', name: 'Network Scanner', icon: 'ScanLine', category: 'communication', component: 'NetworkScanner', defaultSize: { width: 700, height: 500 }, minSize: { width: 400, height: 350 }, pinned: false },
  // Science
  { id: 'bim-calculator', name: 'BIM Calculator', icon: 'Building2', category: 'science', component: 'BimCalculator', defaultSize: { width: 550, height: 450 }, minSize: { width: 350, height: 300 }, pinned: false },
  { id: 'unit-converter', name: 'Unit Converter', icon: 'ArrowLeftRight', category: 'science', component: 'UnitConverter', defaultSize: { width: 450, height: 500 }, minSize: { width: 350, height: 350 }, pinned: false },
  { id: 'scientific-calc', name: 'Scientific Calc', icon: 'FlaskConical', category: 'science', component: 'ScientificCalc', defaultSize: { width: 500, height: 550 }, minSize: { width: 350, height: 400 }, pinned: false },
  { id: 'periodic-table', name: 'Periodic Table', icon: 'Atom', category: 'science', component: 'PeriodicTable', defaultSize: { width: 900, height: 550 }, minSize: { width: 600, height: 400 }, pinned: false },
  { id: 'graphing-calc', name: 'Graphing Calc', icon: 'TrendingUp', category: 'science', component: 'GraphingCalc', defaultSize: { width: 700, height: 550 }, minSize: { width: 450, height: 400 }, pinned: false },
  { id: 'monte-carlo', name: 'Monte Carlo', icon: 'Dices', category: 'science', component: 'MonteCarlo', defaultSize: { width: 700, height: 500 }, minSize: { width: 450, height: 350 }, pinned: false },
  { id: 'topography', name: 'Topography', icon: 'Mountain', category: 'science', component: 'Topography', defaultSize: { width: 800, height: 600 }, minSize: { width: 500, height: 400 }, pinned: false },
  // Games
  { id: 'snake', name: 'Snake', icon: 'SnakeIcon', category: 'games', component: 'Snake', defaultSize: { width: 500, height: 520 }, minSize: { width: 400, height: 420 }, pinned: false },
  { id: 'tetris', name: 'Tetris', icon: 'Grid3X3', category: 'games', component: 'Tetris', defaultSize: { width: 400, height: 560 }, minSize: { width: 320, height: 480 }, pinned: false },
  { id: 'chess', name: 'Chess', icon: 'Crown', category: 'games', component: 'Chess', defaultSize: { width: 520, height: 560 }, minSize: { width: 400, height: 440 }, pinned: false },
  { id: 'solitaire', name: 'Solitaire', icon: 'Layers', category: 'games', component: 'Solitaire', defaultSize: { width: 750, height: 550 }, minSize: { width: 600, height: 450 }, pinned: false },
  { id: 'minesweeper', name: 'Minesweeper', icon: 'Bomb', category: 'games', component: 'Minesweeper', defaultSize: { width: 400, height: 480 }, minSize: { width: 300, height: 380 }, pinned: false },
  // Flagship
  { id: 'megalodon-costos', name: 'Megalodon CostOS', icon: 'Hammer', category: 'flagship', component: 'MegalodonCostos', defaultSize: { width: 1100, height: 700 }, minSize: { width: 600, height: 450 }, pinned: true },
  { id: 'star-map', name: 'Star Map', icon: 'Star', category: 'flagship', component: 'StarMap', defaultSize: { width: 1000, height: 700 }, minSize: { width: 600, height: 450 }, pinned: true },
];

interface AppRegistryState {
  apps: AppDefinition[];
  getApp: (id: string) => AppDefinition | undefined;
  pinApp: (id: string) => void;
  unpinApp: (id: string) => void;
  getPinnedApps: () => AppDefinition[];
  getAppsByCategory: (category: string) => AppDefinition[];
}

export const useAppRegistry = create<AppRegistryState>()(
  persist(
    (set, get) => ({
      apps: ALL_APPS,
      getApp: (id) => get().apps.find((a) => a.id === id),
      pinApp: (id) => {
        set({
          apps: get().apps.map((a) => (a.id === id ? { ...a, pinned: true } : a)),
        });
      },
      unpinApp: (id) => {
        set({
          apps: get().apps.map((a) => (a.id === id ? { ...a, pinned: false } : a)),
        });
      },
      getPinnedApps: () => get().apps.filter((a) => a.pinned),
      getAppsByCategory: (category) => get().apps.filter((a) => a.category === category),
    }),
    {
      name: 'cornstone-apps',
      partialize: (state) => ({ apps: state.apps.map(a => ({ id: a.id, pinned: a.pinned })) }),
      merge: (persisted, current) => {
        const p = persisted as { apps?: { id: string; pinned: boolean }[] } | undefined;
        const pinnedMap = new Map(p?.apps?.map(a => [a.id, Boolean(a.pinned)]) ?? []);
        return {
          ...current,
          apps: current.apps.map(a => ({
            ...a,
            pinned: pinnedMap.has(a.id) ? pinnedMap.get(a.id)! : a.pinned,
          })),
        };
      },
    }
  )
);

export { ALL_APPS };
