import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ContextMenuState {
  visible: boolean;
  x: number;
  y: number;
}

interface DesktopState {
  wallpaper: string;
  selectedIconId: string | null;
  iconPositions: Record<string, { x: number; y: number }>;
  contextMenu: ContextMenuState;
  setWallpaper: (wallpaper: string) => void;
  setSelectedIconId: (id: string | null) => void;
  setContextMenu: (menu: ContextMenuState) => void;
  setIconPosition: (id: string, x: number, y: number) => void;
}

const DEFAULT_DESKTOP_ICONS = [
  'file-manager', 'megalodon-costos', 'star-map', 'terminal', 'text-editor',
  'settings', 'calculator', 'calendar', 'system-monitor', 'trash',
  'snake', 'web-browser',
];

const DEFAULT_POSITIONS: Record<string, { x: number; y: number }> = {};
DEFAULT_DESKTOP_ICONS.forEach((id, i) => {
  const col = Math.floor(i / 6);
  const row = i % 6;
  DEFAULT_POSITIONS[id] = { x: 16 + col * 100, y: 16 + row * 96 };
});

export const useDesktopStore = create<DesktopState>()(
  persist(
    (set) => ({
      wallpaper: '/desktop-bg.jpg',
      selectedIconId: null,
      iconPositions: DEFAULT_POSITIONS,
      contextMenu: { visible: false, x: 0, y: 0 },
      setWallpaper: (wallpaper) => set({ wallpaper }),
      setSelectedIconId: (id) => set({ selectedIconId: id }),
      setContextMenu: (menu) => set({ contextMenu: menu }),
      setIconPosition: (id, x, y) =>
        set((state) => ({
          iconPositions: { ...state.iconPositions, [id]: { x, y } },
        })),
    }),
    {
      name: 'cornstone-desktop',
      partialize: (state) => ({
        wallpaper: state.wallpaper,
        iconPositions: state.iconPositions,
      }),
    }
  )
);
