import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '@/types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isBootComplete: boolean;
  login: (username: string, _password?: string) => void;
  logout: () => void;
  setBootComplete: (complete: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isBootComplete: false,
      login: (username) => {
        const user: User = {
          id: `user-${Date.now()}`,
          name: username === 'Guest' ? 'Guest User' : 'Cornstone User',
          username: username || 'user',
          isGuest: username === 'Guest',
        };
        set({ user, isAuthenticated: true, isBootComplete: false });
      },
      logout: () => {
        set({ user: null, isAuthenticated: false, isBootComplete: false });
      },
      setBootComplete: (complete) => set({ isBootComplete: complete }),
    }),
    {
      name: 'cornstone-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
