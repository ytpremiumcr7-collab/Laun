import { create } from 'zustand';

interface WindowState {
  id: string;
  appId: string;
  title: string;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  isMinimized: boolean;
  isMaximized: boolean;
  prevSize?: { x: number; y: number; width: number; height: number };
}

interface WindowManagerState {
  windows: WindowState[];
  activeWindowId: string | null;
  nextZIndex: number;
  openWindow: (appId: string, title: string, defaultSize?: { width: number; height: number }, minSize?: { width: number; height: number }) => string;
  closeWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  restoreWindow: (id: string) => void;
  setWindowPosition: (id: string, x: number, y: number) => void;
  setWindowSize: (id: string, width: number, height: number) => void;
  minimizeAll: () => void;
}

const DEFAULT_SIZE = { width: 800, height: 600 };
const MIN_SIZE = { width: 320, height: 200 };

function getCascadePosition(appId: string, windows: WindowState[], defaultSize: { width: number; height: number }) {
  const sameAppWindows = windows.filter(w => w.appId === appId && !w.isMinimized);
  if (sameAppWindows.length === 0) {
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1200;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
    return {
      x: Math.max(48, Math.round((vw - defaultSize.width) / 2)),
      y: Math.max(48, Math.round((vh - defaultSize.height) / 2)),
    };
  }
  const last = sameAppWindows[sameAppWindows.length - 1];
  return {
    x: Math.min(last.x + 32, (typeof window !== 'undefined' ? window.innerWidth : 1200) - defaultSize.width - 48),
    y: Math.min(last.y + 32, (typeof window !== 'undefined' ? window.innerHeight : 800) - defaultSize.height - 100),
  };
}

export const useWindowManager = create<WindowManagerState>((set, get) => ({
  windows: [],
  activeWindowId: null,
  nextZIndex: 100,

  openWindow: (appId, title, defaultSize = DEFAULT_SIZE, minSize = MIN_SIZE) => {
    const state = get();
    const id = `window-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    const pos = getCascadePosition(appId, state.windows, defaultSize);
    const constrainedWidth = Math.max(minSize.width, defaultSize.width);
    const constrainedHeight = Math.max(minSize.height, defaultSize.height);
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1200;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
    const safeWidth = Math.min(constrainedWidth, vw - 64);
    const safeHeight = Math.min(constrainedHeight, vh - 80);

    const newWindow: WindowState = {
      id,
      appId,
      title,
      x: Math.max(48, Math.min(pos.x, vw - safeWidth - 16)),
      y: Math.max(48, Math.min(pos.y, vh - safeHeight - 64)),
      width: safeWidth,
      height: safeHeight,
      zIndex: state.nextZIndex,
      isMinimized: false,
      isMaximized: false,
    };

    set({
      windows: [...state.windows, newWindow],
      activeWindowId: id,
      nextZIndex: state.nextZIndex + 1,
    });

    return id;
  },

  closeWindow: (id) => {
    const state = get();
    set({
      windows: state.windows.filter((w) => w.id !== id),
      activeWindowId: state.activeWindowId === id
        ? (state.windows.filter((w) => w.id !== id && !w.isMinimized).slice(-1)[0]?.id ?? null)
        : state.activeWindowId,
    });
  },

  focusWindow: (id) => {
    const state = get();
    const target = state.windows.find((w) => w.id === id);
    if (!target || target.isMinimized) return;
    set({
      windows: state.windows.map((w) =>
        w.id === id ? { ...w, zIndex: state.nextZIndex } : w
      ),
      activeWindowId: id,
      nextZIndex: state.nextZIndex + 1,
    });
  },

  minimizeWindow: (id) => {
    const state = get();
    set({
      windows: state.windows.map((w) =>
        w.id === id ? { ...w, isMinimized: true } : w
      ),
      activeWindowId: state.activeWindowId === id
        ? (state.windows.filter((w) => w.id !== id && !w.isMinimized).slice(-1)[0]?.id ?? null)
        : state.activeWindowId,
    });
  },

  maximizeWindow: (id) => {
    const state = get();
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1200;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
    set({
      windows: state.windows.map((w) =>
        w.id === id
          ? {
              ...w,
              isMaximized: true,
              prevSize: { x: w.x, y: w.y, width: w.width, height: w.height },
              x: 0,
              y: 0,
              width: vw,
              height: vh - 48,
            }
          : w
      ),
      activeWindowId: id,
    });
  },

  restoreWindow: (id) => {
    const state = get();
    set({
      windows: state.windows.map((w) =>
        w.id === id
          ? {
              ...w,
              isMaximized: false,
              isMinimized: false,
              x: w.prevSize?.x ?? w.x,
              y: w.prevSize?.y ?? w.y,
              width: w.prevSize?.width ?? w.width,
              height: w.prevSize?.height ?? w.height,
              prevSize: undefined,
            }
          : w
      ),
    });
  },

  setWindowPosition: (id, x, y) => {
    const state = get();
    set({
      windows: state.windows.map((w) =>
        w.id === id ? { ...w, x, y } : w
      ),
    });
  },

  setWindowSize: (id, width, height) => {
    const state = get();
    set({
      windows: state.windows.map((w) =>
        w.id === id ? { ...w, width, height } : w
      ),
    });
  },

  minimizeAll: () => {
    const state = get();
    set({
      windows: state.windows.map((w) => ({ ...w, isMinimized: true })),
      activeWindowId: null,
    });
  },
}));
