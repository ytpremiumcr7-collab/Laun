import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Search, Power, Lock, RotateCcw, FolderOpen, Home, Download, Image, Music, User,
  FolderOpen as IconFolderOpen, Terminal, FileText, Activity, Settings, Calculator,
  Calendar, Clock, Trash2, Hammer, Star, Code2, Table2, Globe, AppWindow, Gamepad2,
  Presentation, FileType, StickyNote, CheckSquare, KeyRound, Pencil, Braces,
  Search as IconSearch, Hash, Palette, GitCompare, GitBranch, Image as IconImage,
  Music as IconMusic, PlayCircle, Paintbrush, PenTool, Type, BarChart3, Mail,
  MessageSquare, Rss, ScanLine, Building2, ArrowLeftRight, FlaskConical, Atom,
  TrendingUp, Dices, Mountain, Grid3X3, Crown, Layers, Bomb
} from 'lucide-react';
import { useAppRegistry } from '@/stores/useAppRegistry';
import { useAuthStore } from '@/stores/useAuthStore';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  FolderOpen: IconFolderOpen, Terminal, FileText, Activity, Settings, Calculator, Calendar,
  Clock, Trash2, Hammer, Star, Code2, Table2, Globe, AppWindow, Gamepad2,
  Presentation, FileType, StickyNote, CheckSquare, KeyRound, Pencil,
  Braces, Search: IconSearch, Hash, Palette, GitCompare, GitBranch,
  Image: IconImage, Music: IconMusic, PlayCircle, Paintbrush, PenTool,
  Type, BarChart3, Mail, MessageSquare, Rss, ScanLine, Building2,
  ArrowLeftRight, FlaskConical, Atom, TrendingUp, Dices, Mountain,
  Grid3X3, Crown, Layers, Bomb,
};

interface StartMenuProps {
  onClose: () => void;
  onOpenApp: (appId: string) => void;
}

export default function StartMenu({ onClose, onOpenApp }: StartMenuProps) {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'pinned' | 'all'>('pinned');
  const { apps, getPinnedApps, pinApp, unpinApp } = useAppRegistry();
  const { logout } = useAuthStore();

  const pinnedApps = getPinnedApps();

  const filteredApps = useMemo(() => {
    if (!search.trim()) return apps;
    const q = search.toLowerCase();
    return apps.filter(a => a.name.toLowerCase().includes(q));
  }, [search, apps]);

  const groupedApps = useMemo(() => {
    const groups: Record<string, typeof apps> = {};
    filteredApps.forEach(app => {
      const letter = app.name[0].toUpperCase();
      if (!groups[letter]) groups[letter] = [];
      groups[letter].push(app);
    });
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, [filteredApps]);

  const renderIcon = (iconName: string, className?: string) => {
    const Comp = ICON_MAP[iconName] || AppWindow;
    return <Comp className={className} />;
  };

  const handlePinToggle = (appId: string, isPinned: boolean) => {
    if (isPinned) unpinApp(appId);
    else pinApp(appId);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 10 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="fixed bottom-14 left-2 w-[480px] max-h-[640px] rounded-lg flex flex-col overflow-hidden"
        style={{
          background: '#1A1A26',
          border: '1px solid #2A2A3E',
          boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
          zIndex: 20000,
        }}
      >
        {/* User bar */}
        <div className="flex items-center justify-between px-4 h-[52px] border-b border-[#2A2A3E] bg-[#12121A]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#222235] flex items-center justify-center">
              <User className="w-5 h-5 text-[#8A8578]" />
            </div>
            <span className="text-sm text-[#E8E4DC]">Cornstone User</span>
          </div>
          <div className="flex items-center gap-1">
            <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-[#222235] transition-colors text-[#8A8578] hover:text-[#E8E4DC]" title="Lock">
              <Lock className="w-4 h-4" />
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-[#222235] transition-colors text-[#8A8578] hover:text-[#E8E4DC]" title="Restart">
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => logout()}
              className="w-8 h-8 flex items-center justify-center rounded hover:bg-[#B84A4A]/20 transition-colors text-[#8A8578] hover:text-[#B84A4A]"
              title="Shutdown"
            >
              <Power className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="px-4 pt-3 pb-2">
          <div className="flex items-center gap-2 bg-[#0A0A0F] rounded-md px-3 h-10 border border-[#2A2A3E] focus-within:border-[#C9A84C] transition-colors">
            <Search className="w-4 h-4 text-[#4D4A42]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search apps, files, and settings"
              className="flex-1 bg-transparent text-sm text-[#E8E4DC] outline-none placeholder:text-[#4D4A42]"
              autoFocus
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 px-4 pb-2 border-b border-[#2A2A3E]">
          <button
            onClick={() => setActiveTab('pinned')}
            className={`text-sm pb-1 transition-colors ${activeTab === 'pinned' ? 'text-[#C9A84C] border-b-2 border-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
          >
            Pinned
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className={`text-sm pb-1 transition-colors ${activeTab === 'all' ? 'text-[#C9A84C] border-b-2 border-[#C9A84C]' : 'text-[#8A8578] hover:text-[#E8E4DC]'}`}
          >
            All apps
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto px-4 py-3 min-h-[200px]">
          {activeTab === 'pinned' ? (
            <div className="grid grid-cols-4 gap-2">
              {(search ? filteredApps : pinnedApps).map((app, i) => (
                <motion.button
                  key={app.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.015, duration: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                  onClick={() => onOpenApp(app.id)}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-lg hover:bg-[#222235] transition-colors group"
                >
                  <div className="w-8 h-8 flex items-center justify-center">
                    {renderIcon(app.icon, 'w-7 h-7 text-[#8A8578] group-hover:text-[#C9A84C] transition-colors')}
                  </div>
                  <span className="text-[11px] text-[#8A8578] group-hover:text-[#E8E4DC] transition-colors text-center leading-tight">{app.name}</span>
                </motion.button>
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {groupedApps.map(([letter, groupApps]) => (
                <div key={letter}>
                  <div className="sticky top-0 bg-[#1A1A26] px-2 py-1 text-xs text-[#4D4A42] font-medium uppercase">{letter}</div>
                  {groupApps.map(app => (
                    <button
                      key={app.id}
                      onClick={() => onOpenApp(app.id)}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        handlePinToggle(app.id, app.pinned);
                      }}
                      className="flex items-center gap-3 w-full px-2 py-2 text-sm text-[#E8E4DC] hover:bg-[#222235] transition-colors rounded"
                    >
                      {renderIcon(app.icon, 'w-5 h-5 text-[#8A8578]')}
                      <span>{app.name}</span>
                      {app.pinned && <span className="ml-auto text-[10px] text-[#C9A84C]">pinned</span>}
                    </button>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick access */}
        <div className="flex items-center gap-4 px-4 h-11 border-t border-[#2A2A3E] bg-[#12121A]">
          {[
            { icon: Home, label: 'Home' },
            { icon: FolderOpen, label: 'Documents' },
            { icon: Download, label: 'Downloads' },
            { icon: Image, label: 'Pictures' },
            { icon: Music, label: 'Music' },
          ].map(item => (
            <button key={item.label} className="flex items-center gap-1.5 text-xs text-[#8A8578] hover:text-[#E8E4DC] transition-colors">
              <item.icon className="w-3.5 h-3.5" />
              {item.label}
            </button>
          ))}
        </div>
      </motion.div>
      {/* Backdrop click */}
      <div className="fixed inset-0 z-[19999]" onClick={onClose} />
    </>
  );
}
