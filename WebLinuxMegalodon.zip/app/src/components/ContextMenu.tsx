import { motion, AnimatePresence } from 'framer-motion';
import { FolderPlus, FilePlus, Layout, ArrowUpDown, RefreshCw, ClipboardPaste, Image, Terminal, Info } from 'lucide-react';
import { useDesktopStore } from '@/stores/useDesktopStore';
import { useWindowManager } from '@/stores/useWindowManager';
import { useAppRegistry } from '@/stores/useAppRegistry';

export default function ContextMenu() {
  const { contextMenu, setContextMenu } = useDesktopStore();
  const { openWindow } = useWindowManager();
  const { getApp } = useAppRegistry();

  const handleOpenSettings = () => {
    const app = getApp('settings');
    if (app) openWindow('settings', app.name, app.defaultSize, app.minSize);
    setContextMenu({ ...contextMenu, visible: false });
  };

  const handleOpenTerminal = () => {
    const app = getApp('terminal');
    if (app) openWindow('terminal', app.name, app.defaultSize, app.minSize);
    setContextMenu({ ...contextMenu, visible: false });
  };

  if (!contextMenu.visible) return null;

  // Position adjustment to stay within viewport
  const menuWidth = 200;
  const menuHeight = 280;
  const x = Math.min(contextMenu.x, window.innerWidth - menuWidth - 8);
  const y = Math.min(contextMenu.y, window.innerHeight - menuHeight - 8);

  const menuItems = [
    { id: 'new-folder', label: 'New Folder', icon: FolderPlus, action: () => setContextMenu({ ...contextMenu, visible: false }) },
    { id: 'new-doc', label: 'New Document', icon: FilePlus, action: () => setContextMenu({ ...contextMenu, visible: false }) },
    { id: 'sep1', label: '', icon: () => null, action: () => {}, separator: true },
    { id: 'view', label: 'View', icon: Layout, action: () => setContextMenu({ ...contextMenu, visible: false }) },
    { id: 'sort', label: 'Sort by', icon: ArrowUpDown, action: () => setContextMenu({ ...contextMenu, visible: false }) },
    { id: 'refresh', label: 'Refresh', icon: RefreshCw, action: () => setContextMenu({ ...contextMenu, visible: false }) },
    { id: 'sep2', label: '', icon: () => null, action: () => {}, separator: true },
    { id: 'paste', label: 'Paste', icon: ClipboardPaste, action: () => setContextMenu({ ...contextMenu, visible: false }), disabled: true },
    { id: 'sep3', label: '', icon: () => null, action: () => {}, separator: true },
    { id: 'background', label: 'Change Background', icon: Image, action: handleOpenSettings },
    { id: 'open-terminal', label: 'Open in Terminal', icon: Terminal, action: handleOpenTerminal },
    { id: 'sep4', label: '', icon: () => null, action: () => {}, separator: true },
    { id: 'system-info', label: 'System Info', icon: Info, action: () => setContextMenu({ ...contextMenu, visible: false }) },
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.15, ease: [0.165, 0.84, 0.44, 1] as [number, number, number, number] }}
        className="fixed rounded-lg py-1.5 overflow-hidden"
        style={{
          left: x,
          top: y,
          width: menuWidth,
          background: 'var(--surface-elevated)',
          border: '1px solid var(--border-subtle)',
          boxShadow: 'var(--shadow-elevated)',
          zIndex: 20001,
        }}
      >
        {menuItems.map((item) => (
          item.separator ? (
            <div key={item.id} className="my-1 border-t border-[#2A2A3E]" />
          ) : (
            <button
              key={item.id}
              onClick={item.action}
              disabled={item.disabled}
              className={`flex items-center gap-2.5 w-full px-3 py-1.5 text-sm transition-colors ${
                item.disabled
                  ? 'text-[#4D4A42] cursor-not-allowed'
                  : 'text-[#E8E4DC] hover:bg-[#222235] cursor-pointer'
              }`}
            >
              <item.icon className="w-4 h-4 text-[#8A8578]" />
              {item.label}
            </button>
          )
        ))}
      </motion.div>
      {/* Backdrop to close menu */}
      <div
        className="fixed inset-0 z-[20000]"
        onClick={() => setContextMenu({ ...contextMenu, visible: false })}
      />
    </AnimatePresence>
  );
}
