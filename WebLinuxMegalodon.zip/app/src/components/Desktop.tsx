import { useCallback, useEffect } from 'react';
import { useDesktopStore } from '@/stores/useDesktopStore';
import { useWindowManager } from '@/stores/useWindowManager';
import DesktopIcons from './DesktopIcons';
import ContextMenu from './ContextMenu';
import WindowManager from './WindowManager';
import Taskbar from './Taskbar';

export default function Desktop() {
  const { wallpaper, setContextMenu, setSelectedIconId } = useDesktopStore();
  const openWindow = useWindowManager(s => s.openWindow);

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({ visible: true, x: e.clientX, y: e.clientY });
  }, [setContextMenu]);

  const handleClick = useCallback(() => {
    setSelectedIconId(null);
    setContextMenu({ visible: false, x: 0, y: 0 });
  }, [setSelectedIconId, setContextMenu]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      // Super + D - Show desktop
      if (e.metaKey && e.key === 'd') {
        e.preventDefault();
        useWindowManager.getState().minimizeAll();
      }
      // Super + E - File manager
      if (e.metaKey && e.key === 'e') {
        e.preventDefault();
        openWindow('file-manager', 'File Manager', { width: 900, height: 600 }, { width: 400, height: 300 });
      }
      // Super + T - Terminal
      if (e.metaKey && e.key === 't') {
        e.preventDefault();
        openWindow('terminal', 'Terminal', { width: 700, height: 450 }, { width: 400, height: 250 });
      }
    };

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [openWindow]);

  return (
    <div
      className="fixed inset-0 bottom-12 overflow-hidden"
      onContextMenu={handleContextMenu}
      onClick={handleClick}
    >
      {/* Wallpaper */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-opacity duration-800"
        style={{ backgroundImage: `url(${wallpaper})`, zIndex: 0 }}
      />
      <div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 30%, rgba(3,3,5,0.15) 100%)',
          zIndex: 1,
        }}
      />

      {/* Desktop Icons */}
      <DesktopIcons />

      {/* Windows */}
      <WindowManager />

      {/* Context Menu */}
      <ContextMenu />

      {/* Taskbar */}
      <Taskbar />
    </div>
  );
}
