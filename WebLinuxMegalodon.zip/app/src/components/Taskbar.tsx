import { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import {
  Wifi, Volume2, Bell, FolderOpen, Terminal, FileText,
  Activity, Settings, Calculator, Calendar, Clock, Trash2,
  Hammer, Star, Code2, Table2, Globe, AppWindow, Gamepad2,
  Presentation, FileType, StickyNote, CheckSquare, KeyRound,
  Pencil, Braces, Search, Hash, Palette, GitCompare, GitBranch,
  Image, Music, PlayCircle, Paintbrush, PenTool, Type, BarChart3,
  Mail, MessageSquare, Rss, ScanLine, Building2, ArrowLeftRight,
  FlaskConical, Atom, TrendingUp, Dices, Mountain, Grid3X3,
  Crown, Layers, Bomb
} from 'lucide-react';
import { useWindowManager } from '@/stores/useWindowManager';
import { useAppRegistry } from '@/stores/useAppRegistry';
import { useNotificationStore } from '@/stores/useNotificationStore';
import { useDesktopStore } from '@/stores/useDesktopStore';
import StartMenu from './StartMenu';
import NotificationPanel from './NotificationPanel';

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  FolderOpen, Terminal, FileText, Activity, Settings, Calculator, Calendar,
  Clock, Trash2, Hammer, Star, Code2, Table2, Globe, AppWindow, Gamepad2,
  Presentation, FileType, StickyNote, CheckSquare, KeyRound, Pencil,
  Braces, Search, Hash, Palette, GitCompare, GitBranch, Image, Music,
  PlayCircle, Paintbrush, PenTool, Type, BarChart3, Mail, MessageSquare,
  Rss, ScanLine, Building2, ArrowLeftRight, FlaskConical, Atom,
  TrendingUp, Dices, Mountain, Grid3X3, Crown, Layers, Bomb,
};

export default function Taskbar() {
  const [showStartMenu, setShowStartMenu] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);
  const [time, setTime] = useState(new Date());
  const { windows, activeWindowId, focusWindow, minimizeWindow, openWindow, restoreWindow, minimizeAll } = useWindowManager();
  const { getApp, getPinnedApps } = useAppRegistry();
  const notifications = useNotificationStore(s => s.notifications);
  const setSelectedIconId = useDesktopStore(s => s.setSelectedIconId);
  const notificationCount = notifications.length;

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Meta') {
        e.preventDefault();
        setShowStartMenu(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const handlePinnedClick = (appId: string) => {
    const existing = windows.filter(w => w.appId === appId && !w.isMinimized);
    if (existing.length === 1) {
      if (activeWindowId === existing[0].id) {
        minimizeWindow(existing[0].id);
      } else {
        focusWindow(existing[0].id);
      }
    } else if (existing.length > 1) {
      focusWindow(existing[existing.length - 1].id);
    } else {
      const app = getApp(appId);
      if (app) openWindow(appId, app.name, app.defaultSize, app.minSize);
    }
    setShowStartMenu(false);
    setSelectedIconId(null);
  };

  const handleWindowPreviewClick = (windowId: string) => {
    if (activeWindowId === windowId) {
      minimizeWindow(windowId);
    } else {
      restoreWindow(windowId);
      focusWindow(windowId);
    }
  };

  const handleShowDesktop = () => {
    const allMinimized = windows.every(w => w.isMinimized);
    if (allMinimized) {
      windows.forEach(w => restoreWindow(w.id));
    } else {
      minimizeAll();
    }
  };

  const pinnedApps = getPinnedApps();
  const timeStr = time.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
  const dateStr = time.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

  return (
    <>
      <div
        className="fixed bottom-0 left-0 right-0 h-12 flex items-center px-2 gap-1"
        style={{
          zIndex: 50000,
          background: 'rgba(10,10,15,0.92)',
          backdropFilter: 'blur(20px) saturate(1.2)',
          borderTop: '1px solid #2A2A3E',
        }}
      >
        {/* Start button */}
        <button
          onClick={() => setShowStartMenu(!showStartMenu)}
          className={`w-10 h-10 flex items-center justify-center rounded-lg transition-all duration-150 ${
            showStartMenu ? 'bg-[#222235]' : 'hover:bg-[#1A1A26]'
          }`}
        >
          <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke={showStartMenu ? '#C9A84C' : '#8A8578'} strokeWidth="1.5">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
          </svg>
        </button>

        {/* Pinned apps */}
        <div className="flex items-center gap-0.5 ml-1">
          {pinnedApps.map(app => {
            const isRunning = windows.some(w => w.appId === app.id && !w.isMinimized);
            const isActive = windows.some(w => w.appId === app.id && w.id === activeWindowId);
            return (
              <button
                key={app.id}
                onClick={() => handlePinnedClick(app.id)}
                className="relative w-9 h-9 flex items-center justify-center rounded-lg hover:bg-[#1A1A26] transition-colors group"
                title={app.name}
              >
                <TaskbarIcon name={app.icon} className={`w-5 h-5 transition-colors ${isActive ? 'text-[#C9A84C]' : isRunning ? 'text-[#E8E4DC]' : 'text-[#8A8578]'}`} />
                {isRunning && (
                  <div className={`absolute bottom-0.5 left-1/2 -translate-x-1/2 h-0.5 rounded-full transition-all ${isActive ? 'w-5 bg-[#C9A84C]' : 'w-3 bg-[#8A8578]'}`} />
                )}
              </button>
            );
          })}
        </div>

        {/* Window previews */}
        <div className="flex-1 flex items-center justify-center gap-1 px-2 overflow-hidden">
          {windows.filter(w => !w.isMinimized).map(win => {
            const app = getApp(win.appId);
            const isActive = win.id === activeWindowId;
            return (
              <button
                key={win.id}
                onClick={() => handleWindowPreviewClick(win.id)}
                className={`h-9 px-3 rounded-lg flex items-center gap-2 transition-all min-w-0 max-w-[160px] ${
                  isActive ? 'bg-[#1A1A26] border-b-2 border-[#C9A84C]' : 'bg-[#12121A]/60 hover:bg-[#1A1A26] border-b border-[#2A2A3E]'
                }`}
              >
                <TaskbarIcon name={app?.icon || 'AppWindow'} className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-[#C9A84C]' : 'text-[#8A8578]'}`} />
                <span className={`text-xs truncate ${isActive ? 'text-[#E8E4DC]' : 'text-[#8A8578]'}`}>{win.title}</span>
              </button>
            );
          })}
        </div>

        {/* System tray */}
        <div className="flex items-center gap-2 pl-2 border-l border-[#2A2A3E]">
          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-[#1A1A26] transition-colors text-[#8A8578]">
            <Volume2 className="w-4 h-4" />
          </button>
          <button className="w-8 h-8 flex items-center justify-center rounded hover:bg-[#1A1A26] transition-colors text-[#8A8578]">
            <Wifi className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowNotifs(!showNotifs)}
            className="relative w-8 h-8 flex items-center justify-center rounded hover:bg-[#1A1A26] transition-colors text-[#8A8578]"
          >
            <Bell className="w-4 h-4" />
            {notificationCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[#B84A4A] rounded-full flex items-center justify-center text-[9px] text-white font-bold">
                {notificationCount}
              </span>
            )}
          </button>
          <button
            className="flex flex-col items-end px-2 py-1 rounded hover:bg-[#1A1A26] transition-colors ml-1"
            title={dateStr}
          >
            <span className="text-xs text-[#E8E4DC] font-mono">{timeStr}</span>
          </button>
        </div>

        {/* Show desktop button */}
        <button
          className="w-2 h-full ml-1 hover:bg-[#1A1A26] transition-colors border-l border-[#2A2A3E]"
          onClick={handleShowDesktop}
        />
      </div>

      {/* Start Menu */}
      <AnimatePresence>
        {showStartMenu && <StartMenu onClose={() => setShowStartMenu(false)} onOpenApp={handlePinnedClick} />}
      </AnimatePresence>

      {/* Notification Panel */}
      <AnimatePresence>
        {showNotifs && <NotificationPanel onClose={() => setShowNotifs(false)} />}
      </AnimatePresence>
    </>
  );
}

function TaskbarIcon({ name, className }: { name: string; className?: string }) {
  const Comp = ICON_MAP[name] || AppWindow;
  return <Comp className={className} />;
}
