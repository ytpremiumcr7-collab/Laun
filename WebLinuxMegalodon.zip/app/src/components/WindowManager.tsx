import { AnimatePresence } from 'framer-motion';
import { Suspense, lazy } from 'react';
import { useWindowManager } from '@/stores/useWindowManager';
import { useAppRegistry } from '@/stores/useAppRegistry';
import WindowChrome from './WindowChrome';

const appModules = import.meta.glob('../apps/*/index.tsx') as Record<string, () => Promise<{ default: React.ComponentType }>>;

function getAppComponent(appId: string) {
  const path = `../apps/${appId}/index.tsx`;
  const loader = appModules[path];
  if (!loader) {
    return () => (
      <div className="w-full h-full bg-[#12121A] text-[#E8E4DC] flex items-center justify-center">
        <p className="text-sm text-[#8A8578]">App not found: {appId}</p>
      </div>
    );
  }
  return lazy(loader);
}

export default function WindowManager() {
  const { windows, activeWindowId } = useWindowManager();
  const { getApp } = useAppRegistry();

  return (
    <div className="fixed inset-0 bottom-12 pointer-events-none" style={{ zIndex: 'var(--z-windows)' }}>
      <AnimatePresence>
        {windows.filter(w => !w.isMinimized).map((win) => {
          const app = getApp(win.appId);
          const AppComponent = getAppComponent(win.appId);

          return (
            <div key={win.id} className="pointer-events-auto absolute" style={{ left: 0, top: 0 }}>
              <WindowChrome
                windowId={win.id}
                appId={win.appId}
                title={win.title}
                icon={app?.icon || 'AppWindow'}
                isActive={activeWindowId === win.id}
                initialX={win.x}
                initialY={win.y}
                width={win.width}
                height={win.height}
                minWidth={app?.minSize?.width}
                minHeight={app?.minSize?.height}
                isMaximized={win.isMaximized}
                isMinimized={win.isMinimized}
              >
                <Suspense fallback={
                  <div className="w-full h-full bg-[#12121A] flex items-center justify-center">
                    <div className="w-6 h-6 border-2 border-[#C9A84C]/30 border-t-[#C9A84C] rounded-full animate-spin" />
                  </div>
                }>
                  <AppComponent />
                </Suspense>
              </WindowChrome>
            </div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
