import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore } from '@/stores/useAuthStore';

const BOOT_LINES = [
  { text: '[ OK ] Loading kernel cornstone-6.8.0-generic', delay: 0 },
  { text: '[ OK ] Mounting virtual file system', delay: 200 },
  { text: '[ OK ] Initializing window manager v3.2', delay: 400 },
  { text: '[ OK ] Loading app registry (50 applications)', delay: 600 },
  { text: '[ OK ] Mounting /home/user filesystem', delay: 800 },
  { text: '[ OK ] Starting notification daemon', delay: 1000 },
  { text: '[ OK ] Initializing 3D rendering engine (WebGL 2.0)', delay: 1200 },
  { text: '[ OK ] Loading Megalodon CostOS engine v3.1', delay: 1400 },
  { text: '[ OK ] Loading Citation Star-Map corpus (200 nodes)', delay: 1600 },
  { text: '[ OK ] Restoring desktop session', delay: 1800 },
  { text: '[ OK ] Starting system services... done', delay: 2000 },
];

export default function BootSequence() {
  const setBootComplete = useAuthStore(s => s.setBootComplete);
  const [visibleLines, setVisibleLines] = useState<number>(0);
  const [showVerse, setShowVerse] = useState(false);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];

    BOOT_LINES.forEach((line, i) => {
      timers.push(setTimeout(() => {
        setVisibleLines(i + 1);
      }, line.delay));
    });

    timers.push(setTimeout(() => setShowVerse(true), 2400));
    timers.push(setTimeout(() => setFadeOut(true), 4000));
    timers.push(setTimeout(() => setBootComplete(true), 4700));

    return () => timers.forEach(clearTimeout);
  }, [setBootComplete]);

  // Skip on any keypress or click
  useEffect(() => {
    const skip = () => {
      setBootComplete(true);
    };
    window.addEventListener('keydown', skip, { once: true });
    window.addEventListener('click', skip, { once: true });
    return () => {
      window.removeEventListener('keydown', skip);
      window.removeEventListener('click', skip);
    };
  }, [setBootComplete]);

  return (
    <AnimatePresence>
      {!fadeOut && (
        <motion.div
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="fixed inset-0 z-[50000] bg-[#030305] flex flex-col items-start justify-center"
          style={{ paddingLeft: '15%' }}
        >
          <div className="max-w-[600px] w-full">
            {/* Boot log */}
            <div className="font-mono text-sm space-y-1 min-h-[280px]">
              {BOOT_LINES.slice(0, visibleLines).map((line, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex"
                >
                  <span className="text-[#5A9E6F] mr-2">[ OK ]</span>
                  <span className="text-[#8A8578]">{line.text.slice(7)}</span>
                </motion.div>
              ))}
              {visibleLines > 0 && visibleLines <= BOOT_LINES.length && (
                <span className="inline-block w-2 h-4 bg-[#C9A84C] ml-0 animate-pulse" />
              )}
            </div>

            {/* Progress bar */}
            <div className="mt-6 w-full">
              <div className="w-full h-[3px] bg-[#12121A] rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-[#C9A84C]"
                  initial={{ width: '0%' }}
                  animate={{ width: `${(visibleLines / BOOT_LINES.length) * 100}%` }}
                  transition={{ duration: 0.3, ease: 'easeInOut' }}
                  style={{ boxShadow: '0 0 8px rgba(201,168,76,0.3)' }}
                />
              </div>
            </div>

            {/* Golden verse */}
            {showVerse && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="mt-6 font-mono text-sm text-[#C9A84C] italic"
                style={{ textShadow: '0 0 20px rgba(201,168,76,0.3)' }}
              >
                &ldquo;And He said, My presence shall go with thee, and I will give thee rest.&rdquo;
              </motion.div>
            )}
          </div>

          {/* Skip hint */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            transition={{ delay: 1 }}
            className="absolute bottom-6 left-1/2 -translate-x-1/2 text-xs text-[#8A8578] font-mono"
          >
            Press any key to skip
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
