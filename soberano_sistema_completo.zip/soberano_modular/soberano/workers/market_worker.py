#!/usr/bin/env python3
"""Worker de Inteligencia de Mercado: Precios de construcción en tiempo real."""

import asyncio
import json

import redis.asyncio as redis
import asyncpg

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.workers.base import BaseWorker
from soberano.extractors.market_intelligence import market_engine, PrecioMaterial
from soberano.storage.postgres import guardar_precios_mercado
from soberano.bots.telegram_bot import telegram_alert


class MarketIntelligenceWorker(BaseWorker):
    """Worker especializado en inteligencia de mercado de materiales."""

    def __init__(self, redis_client: redis.Redis, pg_pool: asyncpg.Pool, telegram_app=None):
        super().__init__(redis_client, "market_intel")
        self.pg_pool = pg_pool
        self.telegram_app = telegram_app

    async def process_batch(self, stream: str):
        """Procesa mensajes de inteligencia de mercado."""
        results = await self.read_messages(stream)
        if not results:
            return

        for _, messages in results:
            for msg_id, data in messages:
                action = data.get(b"action", b"scan").decode()
                material = data.get(b"material", b"").decode()

                logger.set_context(msg_id=msg_id.decode(), action=action)
                try:
                    if action == "scan_material" and material:
                        precios = await market_engine.obtener_precios_material(material)
                        if precios:
                            await guardar_precios_mercado(self.pg_pool, precios)
                            await metrics.increment("market_intel_prices_collected", len(precios))
                            logger.info(f"{material}: {len(precios)} precios guardados")

                    elif action == "scan_all":
                        resultados = await market_engine.escanear_mercado_completo()
                        total = sum(len(v) for v in resultados.values())
                        await metrics.increment("market_intel_prices_collected", total)
                        if self.telegram_app:
                            await telegram_alert(
                                self.telegram_app,
                                f"📊 Inteligencia de Mercado: {total} precios actualizados"
                            )

                    elif action == "compare":
                        analisis = await market_engine.comparar_precios(material)
                        # Guardar análisis en Redis para consulta rápida
                        await self.redis.set(
                            f"market:compare:{material}",
                            json.dumps(analisis),
                            ex=3600
                        )

                    await self.ack(stream, msg_id)
                    await metrics.increment("messages_processed")

                except Exception as e:
                    logger.error(f"Error Market Intel: {e}")
                    if not await self.handle_retry(stream, msg_id, {"action": action}, str(e)):
                        pass
                finally:
                    logger.clear_context()

    async def run_periodic_scan(self):
        """Ejecuta escaneo periódico automático."""
        while self.running:
            try:
                if settings.MARKET_INTEL_ENABLED:
                    logger.info("Iniciando escaneo periódico de mercado...")
                    resultados = await market_engine.escanear_mercado_completo()
                    total = sum(len(v) for v in resultados.values())
                    for material, precios in resultados.items():
                        if precios:
                            await guardar_precios_mercado(self.pg_pool, precios)
                    await metrics.increment("market_intel_prices_collected", total)
                    logger.info(f"Escaneo periódico completado: {total} precios")
                    if self.telegram_app and total > 0:
                        await telegram_alert(
                            self.telegram_app,
                            f"📊 Escaneo automático: {total} precios de materiales actualizados"
                        )
            except Exception as e:
                logger.error(f"Error en escaneo periódico: {e}")
            await asyncio.sleep(settings.MARKET_INTEL_INTERVAL_HOURS * 3600)
