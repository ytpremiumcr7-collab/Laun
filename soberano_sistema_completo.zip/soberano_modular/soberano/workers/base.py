#!/usr/bin/env python3
"""Base para todos los workers con retry, DLQ y métricas."""

import asyncio
import os
from typing import Dict, Any, Optional

import redis.asyncio as redis

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.utils import backoff_delay


class BaseWorker:
    """Worker base con sistema de reintentos, DLQ y métricas.
    CORRECCION #5: Implementa retry_counts y DLQ con REDIS_MAX_RETRIES.
    """

    def __init__(self, redis_client: redis.Redis, group_name: str):
        self.redis = redis_client
        self.group_name = group_name
        self.retry_counts: Dict[str, int] = {}
        self.running = True

    async def init_group(self, stream: str):
        """Inicializa grupo de consumidores."""
        try:
            await self.redis.xgroup_create(stream, self.group_name, id="0", mkstream=True)
        except redis.ResponseError:
            pass

    async def ack(self, stream: str, msg_id: bytes):
        """Acknowledge de mensaje."""
        try:
            await self.redis.xack(stream, self.group_name, msg_id)
        except Exception as e:
            logger.error(f"Error haciendo ack: {e}")

    async def send_to_dlq(self, stream: str, error: str, msg_id: bytes, data: Dict):
        """Envía mensaje a DLQ con metadata."""
        try:
            await self.redis.xadd(settings.REDIS_DLQ_STREAM, {
                "error": error,
                "original_msg_id": msg_id.decode() if isinstance(msg_id, bytes) else str(msg_id),
                "worker_group": self.group_name,
                **{k: str(v) for k, v in data.items()}
            })
            await metrics.increment("dlq_size")
        except Exception as e:
            logger.error(f"Error enviando a DLQ: {e}")

    async def handle_retry(self, stream: str, msg_id: bytes, data: Dict, error: str) -> bool:
        """Maneja lógica de reintentos. Retorna True si debe reintentar, False si va a DLQ."""
        msg_key = msg_id.decode() if isinstance(msg_id, bytes) else str(msg_id)
        current_retry = self.retry_counts.get(msg_key, 0) + 1
        self.retry_counts[msg_key] = current_retry

        if current_retry >= settings.REDIS_MAX_RETRIES:
            logger.error(f"Max retries ({settings.REDIS_MAX_RETRIES}) alcanzado para {msg_key}, enviando a DLQ")
            await self.send_to_dlq(stream, error, msg_id, data)
            await self.ack(stream, msg_id)
            self.retry_counts.pop(msg_key, None)
            return False

        delay = backoff_delay(current_retry - 1)
        logger.warning(f"Reintento {current_retry}/{settings.REDIS_MAX_RETRIES} para {msg_key} en {delay:.1f}s")
        await asyncio.sleep(delay)
        return True

    async def read_messages(self, stream: str, count: int = 1, block: int = 5000):
        """Lee mensajes del stream."""
        try:
            return await self.redis.xreadgroup(
                groupname=self.group_name,
                consumername=f"{self.group_name}-{os.getpid()}",
                streams={stream: ">"},
                count=count,
                block=block
            )
        except Exception as e:
            logger.error(f"Error leyendo stream: {e}")
            return []

    async def run(self, stream: str):
        """Bucle principal del worker."""
        await self.init_group(stream)
        while self.running:
            try:
                await self.process_batch(stream)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error en worker {self.group_name}: {e}")
                await asyncio.sleep(5)

    async def process_batch(self, stream: str):
        """Procesa un batch de mensajes. Override en subclases."""
        raise NotImplementedError

    def stop(self):
        self.running = False
