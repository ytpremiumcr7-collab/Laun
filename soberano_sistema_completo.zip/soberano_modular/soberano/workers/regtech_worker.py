#!/usr/bin/env python3
"""Worker RegTech: SAT 69-B, cadena de suministro, actas de rescisión.
CORRECCION #4: Simplifica SQL de cadena_suministro con LIMIT 1.
"""

import asyncio
import os
from typing import Dict

import redis.asyncio as redis
import asyncpg
from minio import Minio

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.security import sha256_file, es_pdf_valido
from soberano.core.utils import human_delay
from soberano.parsers.pdf_parser import parse_pdf_sync
from soberano.parsers.cadena_suministro import parsear_cadena_suministro_desde_pdf
from soberano.workers.base import BaseWorker
from soberano.engines.motor_b_regtech import SATClient, generar_acta_rescision
from soberano.bots.telegram_bot import telegram_alert


class RegTechWorker(BaseWorker):
    """Worker especializado en compliance y regulación."""

    def __init__(self, redis_client: redis.Redis, pg_pool: asyncpg.Pool,
                 minio_client: Minio, parse_executor, telegram_app=None):
        super().__init__(redis_client, "regtech")
        self.pg_pool = pg_pool
        self.minio_client = minio_client
        self.parse_executor = parse_executor
        self.telegram_app = telegram_app
        self.sat_client = SATClient()

    async def process_batch(self, stream: str):
        """Procesa mensajes del stream de licitaciones."""
        results = await self.read_messages(stream)
        if not results:
            return

        for _, messages in results:
            for msg_id, data in messages:
                estado = data[b"estado"].decode()
                ruta_pdf = data[b"ruta_pdf"].decode()
                hash_original = data[b"hash"].decode()
                rfc_ganador = data.get(b"rfc_ganador", b"").decode()

                logger.set_context(msg_id=msg_id.decode(), estado=estado)
                try:
                    if not es_pdf_valido(ruta_pdf):
                        raise ValueError("PDF no válido")

                    hash_actual = sha256_file(ruta_pdf)
                    if hash_actual != hash_original:
                        await self.send_to_dlq(stream, "HASH_MISMATCH", msg_id, {"estado": estado})
                        await self.ack(stream, msg_id)
                        if self.telegram_app:
                            await telegram_alert(self.telegram_app, f"🚨 {estado}: Hash incorrecto (RegTech).")
                        continue

                    # Parsear PDF
                    registros = await asyncio.get_running_loop().run_in_executor(
                        self.parse_executor, parse_pdf_sync, ruta_pdf, estado
                    )

                    # Extraer texto para cadena de suministro
                    import pdfplumber
                    texto_completo = ""
                    with pdfplumber.open(ruta_pdf) as pdf:
                        texto_completo = " ".join(page.extract_text() or "" for page in pdf.pages)

                    sub_registros = parsear_cadena_suministro_desde_pdf(texto_completo, rfc_ganador, 0)

                    async with self.pg_pool.acquire() as conn:
                        # CORRECCION #4: SQL simplificado con LIMIT 1
                        for sub in sub_registros:
                            await conn.execute(
                                "INSERT INTO cadena_suministro (contrato_id, rfc_proveedor, rfc_subcontratista, monto, concepto, fuente) "
                                "VALUES ((SELECT id FROM adjudicaciones WHERE datos->>'rfc' = $1 LIMIT 1), $1, $2, $3, $4, $5)",
                                rfc_ganador, sub["rfc_subcontratista"], sub["monto"], sub["concepto"], sub["fuente"]
                            )

                        # Consultar SAT para RFC principal y subcontratistas
                        rfcs_a_consultar = [rfc_ganador] + [s["rfc_subcontratista"] for s in sub_registros]
                        for rfc in rfcs_a_consultar:
                            if not rfc:
                                continue
                            await human_delay(0.5, 1.5)  # Pausa entre consultas SAT
                            res = await self.sat_client.consultar_rfc(rfc)
                            await conn.execute(
                                "INSERT INTO compliance_blacklist (rfc, nombre, nivel_riesgo, fecha_consulta) "
                                "VALUES ($1, $2, $3, NOW()) ON CONFLICT (rfc) DO UPDATE SET nombre=EXCLUDED.nombre, nivel_riesgo=EXCLUDED.nivel_riesgo",
                                res["rfc"], res["nombre"], res["nivel_riesgo"]
                            )
                            if res["blacklisted"]:
                                if self.telegram_app:
                                    await telegram_alert(self.telegram_app, f"🚫 RegTech: RFC {rfc} en lista negra.")
                                if settings.GENERAR_ACTAS_AUTOMATICO:
                                    adj_id = await conn.fetchval(
                                        "SELECT id FROM adjudicaciones WHERE datos->>'rfc' = $1 LIMIT 1", rfc
                                    )
                                    if adj_id:
                                        await generar_acta_rescision(adj_id, rfc, "Lista negra SAT 69-B", self.pg_pool, self.minio_client)

                    await self.ack(stream, msg_id)
                    await metrics.increment("messages_processed")

                except Exception as e:
                    logger.error(f"Error RegTech: {e}")
                    if not await self.handle_retry(stream, msg_id, {"estado": estado}, str(e)):
                        pass  # Ya manejado en handle_retry
                finally:
                    logger.clear_context()
