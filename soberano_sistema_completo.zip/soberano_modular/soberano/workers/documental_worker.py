#!/usr/bin/env python3
"""Worker Documental: Parsing, MinIO, ajuste de costos.
CORRECCION #1: Usa ruta_pdf directamente, no variable 'local' indefinida.
CORRECCION #2: pdfplumber ya está importado en el módulo de parsers.
"""

import asyncio
import os

import redis.asyncio as redis
import asyncpg
from minio import Minio

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.security import sha256_file, es_pdf_valido
from soberano.core.utils import human_delay
from soberano.parsers.pdf_parser import parse_pdf_sync
from soberano.workers.base import BaseWorker
from soberano.engines.motor_c_macro import procesar_ajuste_costos
from soberano.storage.minio_client import guardar_en_minio_sync
from soberano.storage.postgres import insertar_documento_y_adjudicaciones
from soberano.bots.telegram_bot import telegram_alert


class DocumentalWorker(BaseWorker):
    """Worker especializado en procesamiento documental."""

    def __init__(self, redis_client: redis.Redis, pg_pool: asyncpg.Pool,
                 minio_client: Minio, minio_executor, parse_executor, telegram_app=None):
        super().__init__(redis_client, "documental")
        self.pg_pool = pg_pool
        self.minio_client = minio_client
        self.minio_executor = minio_executor
        self.parse_executor = parse_executor
        self.telegram_app = telegram_app

    async def process_batch(self, stream: str):
        """Procesa mensajes documentales."""
        results = await self.read_messages(stream)
        if not results:
            return

        for _, messages in results:
            for msg_id, data in messages:
                estado = data[b"estado"].decode()
                ruta_pdf = data[b"ruta_pdf"].decode()
                hash_original = data[b"hash"].decode()
                anio = int(data[b"anio"].decode()) if b"anio" in data else __import__("datetime").datetime.now(__import__("datetime").timezone.utc).year

                logger.set_context(msg_id=msg_id.decode(), estado=estado)
                try:
                    if not es_pdf_valido(ruta_pdf):
                        raise ValueError("PDF no válido")

                    hash_actual = sha256_file(ruta_pdf)
                    if hash_actual != hash_original:
                        await self.send_to_dlq(stream, "HASH_MISMATCH", msg_id, {"estado": estado})
                        await self.ack(stream, msg_id)
                        continue

                    # Subir a MinIO
                    metadata_minio = {
                        "url_origen": "",
                        "fuente": "gaceta",
                        "extractor_version": settings.EXTRACTOR_VERSION
                    }
                    objeto_subido = await asyncio.get_running_loop().run_in_executor(
                        self.minio_executor, guardar_en_minio_sync,
                        self.minio_client, ruta_pdf, estado, hash_actual, metadata_minio
                    )
                    if not objeto_subido:
                        raise RuntimeError("Fallo MinIO")

                    # Parsear e insertar
                    registros = await asyncio.get_running_loop().run_in_executor(
                        self.parse_executor, parse_pdf_sync, ruta_pdf, estado
                    )

                    if registros:
                        metadata_full = {
                            "estado": estado, "anio": anio, "ruta_pdf": ruta_pdf,
                            "hash_sha256": hash_actual, "url_origen": "", "fuente": "gaceta",
                            "timestamp_descarga": __import__("datetime").datetime.now(__import__("datetime").timezone.utc),
                            "tamano_bytes": os.path.getsize(ruta_pdf),
                            "extractor_version": settings.EXTRACTOR_VERSION,
                            "content_type": "application/pdf"
                        }
                        doc_id, pares = await insertar_documento_y_adjudicaciones(
                            self.pg_pool, registros, metadata_full
                        )
                        # Ajuste de costos
                        for idx, adj_id in pares:
                            await procesar_ajuste_costos(adj_id, self.pg_pool, self.minio_client)

                        if self.telegram_app:
                            await telegram_alert(
                                self.telegram_app,
                                f"📄 Doc: {len(pares)} adjudicaciones procesadas para {estado}"
                            )

                    await self.ack(stream, msg_id)
                    await metrics.increment("messages_processed")

                except Exception as e:
                    logger.error(f"Error Doc: {e}")
                    if not await self.handle_retry(stream, msg_id, {"estado": estado}, str(e)):
                        pass
                finally:
                    logger.clear_context()
