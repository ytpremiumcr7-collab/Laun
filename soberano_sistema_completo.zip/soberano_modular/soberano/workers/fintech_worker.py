#!/usr/bin/env python3
"""Worker FinTech: Tokenización y factoraje de adjudicaciones."""

import asyncio

import redis.asyncio as redis
import asyncpg
from minio import Minio

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.workers.base import BaseWorker
from soberano.engines.motor_a_fintech import MesaDinero
from soberano.bots.telegram_bot import telegram_alert


class FinTechWorker(BaseWorker):
    """Worker especializado en operaciones financieras."""

    def __init__(self, redis_client: redis.Redis, pg_pool: asyncpg.Pool,
                 minio_client: Minio, parse_executor, telegram_app=None):
        super().__init__(redis_client, "fintech")
        self.pg_pool = pg_pool
        self.minio_client = minio_client
        self.parse_executor = parse_executor
        self.telegram_app = telegram_app
        from soberano.engines.motor_b_regtech import SATClient
        self.mesa = MesaDinero(pg_pool, SATClient())

    async def process_batch(self, stream: str):
        """Procesa mensajes para factoraje."""
        results = await self.read_messages(stream)
        if not results:
            return

        for _, messages in results:
            for msg_id, data in messages:
                estado = data[b"estado"].decode()
                rfc_ganador = data.get(b"rfc_ganador", b"").decode()
                monto = float(data.get(b"monto", b"0").decode())

                logger.set_context(msg_id=msg_id.decode(), estado=estado)
                try:
                    adj_id = None
                    async with self.pg_pool.acquire() as conn:
                        row = await conn.fetchrow(
                            "SELECT id FROM adjudicaciones WHERE datos->>'rfc' = $1 ORDER BY fecha_ingesta DESC LIMIT 1",
                            rfc_ganador
                        )
                        if row:
                            adj_id = row["id"]

                    # CORRECCION #6: Loguea advertencia si adj_id es None
                    if adj_id is None:
                        logger.warning(f"FinTech: No se encontró adjudicación para RFC {rfc_ganador}")
                        await self.ack(stream, msg_id)
                        continue

                    if adj_id and monto > 0:
                        try:
                            resultado = await self.mesa.solicitar_factoraje(adj_id, monto)
                            if "token_id" in resultado:
                                if self.telegram_app:
                                    await telegram_alert(
                                        self.telegram_app,
                                        f"💰 FinTech: Token {resultado['token_id']} emitido para {rfc_ganador} por ${resultado['monto_factoraje']:,.2f}"
                                    )
                                await metrics.increment("messages_processed")
                            elif "error" in resultado:
                                logger.warning(f"Factoraje rechazado: {resultado['error']}")
                        except Exception as e:
                            logger.error(f"Error factoraje: {e}")
                            raise

                    await self.ack(stream, msg_id)

                except Exception as e:
                    logger.error(f"Error FinTech: {e}")
                    if not await self.handle_retry(stream, msg_id, {"estado": estado}, str(e)):
                        pass
                finally:
                    logger.clear_context()
