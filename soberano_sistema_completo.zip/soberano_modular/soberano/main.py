#!/usr/bin/env python3
"""Arranque principal del Sistema Soberano de 10 Capas."""

import asyncio
import concurrent.futures
import signal
import sys

from aiohttp import web
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.locks import DistributedLock
from soberano.extractors.ghost_extractor import GhostExtractor
from soberano.storage.postgres import init_postgres
from soberano.storage.redis_client import get_redis_client
from soberano.storage.minio_client import get_minio_client
from soberano.api.gateway import ingesta_handler, health_handler, metrics_handler, market_intel_handler, market_prices_handler
from soberano.api.handlers import (
    certificado_factoraje_handler, factoraje_solicitar_handler,
    transferir_token_handler, ajuste_costos_handler, generar_anexo_handler
)
from soberano.api.middleware import cors_middleware, logging_middleware
from soberano.workers.regtech_worker import RegTechWorker
from soberano.workers.fintech_worker import FinTechWorker
from soberano.workers.documental_worker import DocumentalWorker
from soberano.workers.market_worker import MarketIntelligenceWorker
from soberano.bots.telegram_bot import build_telegram_app, telegram_alert


async def extraccion_nacional_con_lock(redis_client):
    """Ejecuta extracción con lock distribuido."""
    try:
        async with DistributedLock(
            redis_client,
            settings.REDIS_LOCK_KEY,
            settings.REDIS_LOCK_TTL,
            settings.REDIS_LOCK_RENEW_INTERVAL
        ):
            extractor = GhostExtractor()
            await extractor.extraccion_nacional()
    except RuntimeError:
        logger.info("Extracción saltada: otro worker ya la está ejecutando.")


async def monitorear_dlq(redis_client, telegram_app):
    """Monitorea DLQ y alerta."""
    while True:
        try:
            length = await redis_client.xlen(settings.REDIS_DLQ_STREAM)
            if length >= settings.DLQ_ALERT_THRESHOLD:
                await telegram_alert(telegram_app, f"🚨 DLQ con {length} mensajes, revisar urgente.")
        except Exception as e:
            logger.error(f"Error monitoreando DLQ: {e}")
        await asyncio.sleep(settings.DLQ_CHECK_INTERVAL)


async def actualizacion_periodica_sat(pg_pool, sat_client, interval_hours=24):
    """Actualiza compliance SAT periódicamente."""
    while True:
        try:
            async with pg_pool.acquire() as conn:
                rfc_rows = await conn.fetch(
                    "SELECT DISTINCT datos->>'rfc' as rfc FROM adjudicaciones WHERE datos->>'rfc' IS NOT NULL"
                )
                rfc_list = [r["rfc"] for r in rfc_rows if r["rfc"]]
                if rfc_list:
                    logger.info(f"Actualizando SAT 69-B para {len(rfc_list)} RFCs...")
                    for rfc in rfc_list:
                        resultado = await sat_client.consultar_rfc(rfc)
                        await conn.execute("""
                            INSERT INTO compliance_blacklist (rfc, nombre, nivel_riesgo, fecha_consulta)
                            VALUES ($1, $2, $3, NOW())
                            ON CONFLICT (rfc) DO UPDATE SET
                                nombre = EXCLUDED.nombre,
                                nivel_riesgo = EXCLUDED.nivel_riesgo,
                                fecha_consulta = NOW()
                        """, resultado["rfc"], resultado["nombre"], resultado["nivel_riesgo"])
        except Exception as e:
            logger.error(f"Error en actualización periódica SAT: {e}")
        await asyncio.sleep(interval_hours * 3600)


async def main():
    """Arranque principal."""
    try:
        settings.validate()
    except ValueError as e:
        logger.critical(f"Error de configuración: {e}")
        sys.exit(1)

    # ── Pool de conexiones ───────────────────────────────────
    import asyncpg
    pg_pool = await asyncpg.create_pool(
        user=settings.POSTGRES_USER, password=settings.POSTGRES_PASSWORD,
        database=settings.POSTGRES_DB, host=settings.POSTGRES_HOST,
        port=settings.POSTGRES_PORT, min_size=settings.POSTGRES_MIN_CONN,
        max_size=settings.POSTGRES_MAX_CONN
    )
    await init_postgres(pg_pool)

    redis_client = await get_redis_client()

    minio_client = get_minio_client()
    loop = asyncio.get_running_loop()
    if not await loop.run_in_executor(None, minio_client.bucket_exists, settings.MINIO_BUCKET):
        await loop.run_in_executor(None, minio_client.make_bucket, settings.MINIO_BUCKET)

    # ── Ejecutores ───────────────────────────────────────────
    scraper_executor = concurrent.futures.ThreadPoolExecutor(max_workers=settings.MAX_SCRAPER_WORKERS)
    minio_executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)
    parse_executor = concurrent.futures.ProcessPoolExecutor(max_workers=settings.MAX_WORKERS)
    settings.scraper_executor = scraper_executor

    # ── Telegram ─────────────────────────────────────────────
    telegram_app = build_telegram_app(pg_pool)
    if telegram_app:
        await telegram_app.initialize()
        await telegram_app.start()
        await telegram_alert(telegram_app, "🟢 Sistema Soberano de 10 Capas iniciado (producción).")

    # ── API Gateway ──────────────────────────────────────────
    app = web.Application(middlewares=[cors_middleware, logging_middleware])
    app["redis"] = redis_client
    app["pg_pool"] = pg_pool
    app["minio_client"] = minio_client

    app.router.add_post("/api/v1/ingesta-estado", ingesta_handler)
    app.router.add_get("/health", health_handler)
    app.router.add_get("/metrics", metrics_handler)
    app.router.add_post("/api/v1/factoraje/certificate", certificado_factoraje_handler)
    app.router.add_post("/api/v1/factoraje/solicitar", factoraje_solicitar_handler)
    app.router.add_post("/api/v1/tokens/transferir", transferir_token_handler)
    app.router.add_post("/api/v1/ajuste-costos/ejecutar", ajuste_costos_handler)
    app.router.add_post("/api/v1/anexos/generar", generar_anexo_handler)
    app.router.add_post("/api/v1/market/intel", market_intel_handler)
    app.router.add_get("/api/v1/market/precios", market_prices_handler)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host=settings.API_HOST, port=settings.API_PORT)
    await site.start()
    logger.info(f"API escuchando en {settings.API_HOST}:{settings.API_PORT}")

    # ── Workers Especializados ───────────────────────────────
    from soberano.engines.motor_b_regtech import SATClient
    sat_client = SATClient()

    regtech_worker = RegTechWorker(redis_client, pg_pool, minio_client, parse_executor, telegram_app)
    fintech_worker = FinTechWorker(redis_client, pg_pool, minio_client, parse_executor, telegram_app)
    doc_worker = DocumentalWorker(redis_client, pg_pool, minio_client, minio_executor, parse_executor, telegram_app)
    market_worker = MarketIntelligenceWorker(redis_client, pg_pool, telegram_app)

    regtech_task = asyncio.create_task(regtech_worker.run(settings.REDIS_STREAM))
    fintech_task = asyncio.create_task(fintech_worker.run(settings.REDIS_STREAM))
    doc_task = asyncio.create_task(doc_worker.run(settings.REDIS_STREAM))
    market_task = asyncio.create_task(market_worker.run(settings.MARKET_INTEL_STREAM))
    market_periodic = asyncio.create_task(market_worker.run_periodic_scan())

    # ── Tareas de fondo ────────────────────────────────────────
    extractor = GhostExtractor()
    proxy_task = asyncio.create_task(extractor.mantener_pool_proxies())
    dlq_task = asyncio.create_task(monitorear_dlq(redis_client, telegram_app))
    sat_task = asyncio.create_task(actualizacion_periodica_sat(pg_pool, sat_client))

    # ── Scheduler ──────────────────────────────────────────────
    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        lambda: asyncio.create_task(extraccion_nacional_con_lock(redis_client)),
        CronTrigger(hour=0, minute=0), id="extract_daily"
    )
    scheduler.start()
    logger.info("Planificador diario iniciado (00:00)")

    # ── Graceful shutdown ────────────────────────────────────
    stop_event = asyncio.Event()
    def shutdown(sig):
        logger.info(f"Señal {sig}, apagando...")
        stop_event.set()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, shutdown, sig)

    await stop_event.wait()

    # ── Cleanup ────────────────────────────────────────────────
    for worker in [regtech_worker, fintech_worker, doc_worker, market_worker]:
        worker.stop()

    for task in [regtech_task, fintech_task, doc_task, market_task, market_periodic, proxy_task, dlq_task, sat_task]:
        task.cancel()

    scheduler.shutdown()
    await asyncio.gather(
        regtech_task, fintech_task, doc_task, market_task, market_periodic,
        proxy_task, dlq_task, sat_task, return_exceptions=True
    )

    if telegram_app:
        await telegram_app.stop()
        await telegram_app.shutdown()
    await runner.cleanup()
    await redis_client.close()
    await pg_pool.close()
    scraper_executor.shutdown(wait=True)
    minio_executor.shutdown(wait=True)
    parse_executor.shutdown(wait=True)
    logger.info("Sistema detenido.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "extract":
        redis_client = asyncio.run(get_redis_client())
        asyncio.run(extraccion_nacional_con_lock(redis_client))
    else:
        asyncio.run(main())
