#!/usr/bin/env python3
"""Bot de Telegram para control operativo del sistema."""

import json
from functools import wraps
from typing import Callable

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, ConversationHandler, MessageHandler, filters
)

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics

FACTORAJE_AMOUNT = 1


def solo_chat_autorizado(func: Callable) -> Callable:
    """Decorator que restringe comandos a chat autorizado."""
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        if settings.TELEGRAM_CHAT_ID and str(update.effective_chat.id) != settings.TELEGRAM_CHAT_ID:
            await update.message.reply_text("No autorizado.")
            return
        return await func(update, context, *args, **kwargs)
    return wrapper


async def telegram_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /start."""
    keyboard = [
        [InlineKeyboardButton("📊 Ver estado", callback_data="status")],
        [InlineKeyboardButton("💰 Factoraje", callback_data="factoraje")],
        [InlineKeyboardButton("📝 Inyectar propuesta", callback_data="propuesta")],
        [InlineKeyboardButton("🛡️ Compliance", callback_data="compliance")],
        [InlineKeyboardButton("📊 Precios de mercado", callback_data="market")],
    ]
    await update.message.reply_text(
        "🟢 Sistema Soberano de 10 Capas activo.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def telegram_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler de callbacks del teclado inline."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "status":
        await query.edit_message_text("✅ Sistema operativo correctamente.")
    elif data == "factoraje":
        await query.edit_message_text("💰 ¿Qué monto deseas factorar? Escribe el monto o /cancelar")
        return FACTORAJE_AMOUNT
    elif data == "propuesta":
        await query.edit_message_text("📝 Envía /propuesta <id> <monto>")
    elif data == "compliance":
        await query.edit_message_text("🛡️ /compliance <RFC>")
    elif data == "market":
        await query.edit_message_text("📊 /precios <material> — Consulta precios de mercado")
    else:
        await query.edit_message_text("Opción no reconocida.")
    return ConversationHandler.END


@solo_chat_autorizado
async def recibir_monto_factoraje(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Recibe monto de factoraje."""
    try:
        monto = float(update.message.text.replace(",", ""))
        await update.message.reply_text(f"✅ Factoraje por ${monto:,.2f} aprobado (simulado).")
        return ConversationHandler.END
    except ValueError:
        await update.message.reply_text("Monto inválido. Intenta de nuevo o /cancelar")
        return FACTORAJE_AMOUNT


@solo_chat_autorizado
async def cancelar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancela operación."""
    await update.message.reply_text("Operación cancelada.")
    return ConversationHandler.END


@solo_chat_autorizado
async def comando_propuesta(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /propuesta."""
    try:
        lic_id = context.args[0]
        monto = float(context.args[1])
        await update.message.reply_text(f"📝 Propuesta {lic_id} por ${monto:,.2f} inyectada.")
    except (IndexError, ValueError):
        await update.message.reply_text("Uso: /propuesta <id> <monto>")


@solo_chat_autorizado
async def status_licitacion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Consulta status de licitación."""
    if not context.args:
        await update.message.reply_text("Uso: /status_licitacion <id>")
        return
    lic_id = context.args[0]
    pool = context.application.bot_data.get("pg_pool")
    if not pool:
        await update.message.reply_text("Pool no disponible.")
        return
    try:
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT id, estado, fecha_ingesta, datos, ajuste_inflacion FROM adjudicaciones WHERE id = $1",
                int(lic_id)
            )
        if row:
            datos = json.loads(row["datos"]) if row["datos"] else {}
            ajuste = json.loads(row["ajuste_inflacion"]) if row["ajuste_inflacion"] else None
            mensaje = f"📋 Adjudicación {row['id']} ({row['estado']})\n"
            mensaje += f"RFC: {datos.get('rfc', 'N/A')}\n"
            mensaje += f"Monto original: ${datos.get('monto_total', 0):,.2f}\n"
            if ajuste and "factor" in ajuste:
                mensaje += f"Ajuste inflación: {ajuste['factor']:.2%} → ${ajuste['monto_ajustado']:,.2f}\n"
            mensaje += f"Fecha: {row['fecha_ingesta']}"
            await update.message.reply_text(mensaje)
        else:
            await update.message.reply_text("ID no encontrado.")
    except Exception as e:
        logger.error(f"Error consultando adjudicación: {e}")
        await update.message.reply_text("Error al consultar la base de datos.")


@solo_chat_autorizado
async def compliance_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Consulta compliance SAT."""
    if not context.args:
        await update.message.reply_text("Uso: /compliance <RFC>")
        return
    rfc = context.args[0].upper()
    from soberano.engines.motor_b_regtech import SATClient
    sat = SATClient()
    resultado = await sat.consultar_rfc(rfc)
    if resultado["blacklisted"]:
        await update.message.reply_text(
            f"🚫 RFC {rfc} EN LISTA NEGRA (69-B).\n"
            f"Nombre: {resultado['nombre']}\n"
            f"Riesgo: {resultado['nivel_riesgo']}"
        )
    else:
        await update.message.reply_text(
            f"✅ RFC {rfc} sin incidencias (nivel: {resultado['nivel_riesgo']})."
        )


@solo_chat_autorizado
async def amparos_pendientes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lista amparos pendientes."""
    pool = context.application.bot_data.get("pg_pool")
    if not pool:
        await update.message.reply_text("Pool no disponible.")
        return
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT id, folio, estado, monto_original, monto_ajustado, resolucion "
                "FROM amparos WHERE resolucion NOT ILIKE 'Resuelto%' ORDER BY fecha DESC LIMIT 10"
            )
        if rows:
            texto = "⚖️ Amparos pendientes:\n"
            for r in rows:
                texto += (
                    f"• {r['folio']} ({r['estado']}): "
                    f"${r['monto_original']:,.2f} → ${r['monto_ajustado']:,.2f} | {r['resolucion']}\n"
                )
            await update.message.reply_text(texto)
        else:
            await update.message.reply_text("No hay amparos pendientes.")
    except Exception as e:
        logger.error(f"Error consultando amparos: {e}")
        await update.message.reply_text("Error al consultar.")


@solo_chat_autorizado
async def reporte_mensual(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Genera reporte mensual."""
    pool = context.application.bot_data.get("pg_pool")
    if not pool:
        await update.message.reply_text("Pool no disponible.")
        return
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT estado, COUNT(*) as cantidad, SUM((datos->>'monto_total')::numeric) as total
                FROM adjudicaciones
                WHERE fecha_ingesta > NOW() - INTERVAL '30 days'
                GROUP BY estado ORDER BY total DESC
            """)
        if rows:
            texto = "📊 Reporte de los últimos 30 días:\n"
            for r in rows:
                texto += f"{r['estado']}: {r['cantidad']} adjudicaciones, ${r['total']:,.2f}\n"
            await update.message.reply_text(texto)
        else:
            await update.message.reply_text("No hay datos recientes.")
    except Exception as e:
        logger.error(f"Error en reporte: {e}")
        await update.message.reply_text("Error generando reporte.")


@solo_chat_autorizado
async def precios_mercado(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Consulta precios de mercado de materiales."""
    if not context.args:
        await update.message.reply_text("Uso: /precios <material> [fuente]\nEjemplo: /precios cemento")
        return
    material = " ".join(context.args)
    pool = context.application.bot_data.get("pg_pool")
    if not pool:
        await update.message.reply_text("Pool no disponible.")
        return
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM precios_mercado WHERE material ILIKE $1 ORDER BY fecha_extraccion DESC LIMIT 10",
                f"%{material}%"
            )
        if rows:
            texto = f"📊 Precios para '{material}':\n\n"
            for r in rows:
                texto += f"• {r['fuente']} | ${r['precio']:,.2f} {r['moneda']} | {r['tipo_precio']} | {r['fecha_extraccion'].strftime('%d/%m/%Y')}\n"
            await update.message.reply_text(texto)
        else:
            await update.message.reply_text(f"No se encontraron precios para '{material}'.")
    except Exception as e:
        logger.error(f"Error consultando precios: {e}")
        await update.message.reply_text("Error al consultar precios.")


async def telegram_alert(app: Application, mensaje: str):
    """Envía alerta por Telegram."""
    if not settings.TELEGRAM_TOKEN or not settings.TELEGRAM_CHAT_ID:
        return
    try:
        await app.bot.send_message(chat_id=settings.TELEGRAM_CHAT_ID, text=mensaje)
    except Exception as e:
        logger.error(f"Error enviando alerta por Telegram: {e}")


def build_telegram_app(pg_pool) -> Application:
    """Construye y configura la aplicación de Telegram."""
    if not settings.TELEGRAM_TOKEN:
        return None

    app = Application.builder().token(settings.TELEGRAM_TOKEN).build()
    app.bot_data["pg_pool"] = pg_pool

    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(telegram_callback, pattern="^factoraje$")],
        states={FACTORAJE_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, recibir_monto_factoraje)]},
        fallbacks=[CommandHandler("cancelar", cancelar)]
    )

    app.add_handler(CommandHandler("start", telegram_start))
    app.add_handler(conv_handler)
    app.add_handler(CallbackQueryHandler(telegram_callback, pattern="^(status|propuesta|compliance|market)$"))
    app.add_handler(CommandHandler("propuesta", comando_propuesta))
    app.add_handler(CommandHandler("status_licitacion", status_licitacion))
    app.add_handler(CommandHandler("compliance", compliance_handler))
    app.add_handler(CommandHandler("amparos_pendientes", amparos_pendientes))
    app.add_handler(CommandHandler("reporte_mensual", reporte_mensual))
    app.add_handler(CommandHandler("precios", precios_mercado))

    return app
