#!/usr/bin/env python3
"""Cliente MinIO para almacenamiento WORM."""

import os
import time
from typing import Optional, Dict

from minio import Minio
from minio.error import S3Error

from soberano.config.settings import settings
from soberano.config.logging_config import logger


def get_minio_client() -> Minio:
    """Devuelve cliente MinIO configurado."""
    return Minio(
        settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=settings.MINIO_SECURE
    )


def guardar_en_minio_sync(
    minio_client: Minio,
    ruta_local: str,
    estado: str,
    hash_sha: str,
    metadata_extra: Optional[Dict] = None
) -> Optional[str]:
    """Sube archivo a MinIO con metadatos y WORM."""
    bucket = settings.MINIO_BUCKET
    if not minio_client.bucket_exists(bucket):
        minio_client.make_bucket(bucket)
        logger.warning("Bucket creado sin Object Lock. Para WORM fuerte, créelo manualmente con lock habilitado.")

    if settings.MINIO_WORM_ENABLED:
        try:
            config = minio_client.get_object_lock_config(bucket)
            logger.info(f"Object Lock configurado en bucket: {config}")
        except S3Error as e:
            logger.error(f"No se pudo verificar Object Lock: {e}. WORM débil.")

    object_name = f"{estado}/{os.path.basename(ruta_local)}"
    metadata = {
        "x-amz-meta-estado": estado,
        "x-amz-meta-hash": hash_sha,
        "x-amz-meta-timestamp": str(int(time.time())),
    }
    if metadata_extra:
        for k, v in metadata_extra.items():
            metadata[f"x-amz-meta-{k}"] = str(v)[:1024]

    extra_kwargs = {}
    if settings.MINIO_WORM_ENABLED:
        try:
            extra_kwargs["legal_hold"] = "ON"
        except Exception:
            logger.warning("legal_hold no soportado en esta versión de MinIO.")

    try:
        minio_client.fput_object(bucket, object_name, ruta_local, metadata=metadata, **extra_kwargs)
        logger.info(f"Objeto {object_name} subido a MinIO.")
        return object_name
    except S3Error as e:
        logger.error(f"Error subiendo a MinIO: {e}")
        return None
