#!/usr/bin/env python3
"""Inicialización y operaciones de PostgreSQL."""

import asyncpg
import json
from typing import Optional, Tuple, List, Dict

from soberano.config.settings import settings
from soberano.config.logging_config import logger


async def init_postgres(pool: asyncpg.Pool):
    """Crea esquema completo de 10 capas + inteligencia de mercado."""
    async with pool.acquire() as conn:
        if settings.USE_TIMESCALE:
            await conn.execute("CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;")
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS documentos (
                id SERIAL PRIMARY KEY, estado TEXT, hash_sha256 TEXT UNIQUE,
                ruta_pdf TEXT, url_origen TEXT, fuente TEXT,
                timestamp_descarga TIMESTAMPTZ, fecha_ingesta TIMESTAMPTZ DEFAULT NOW(),
                tamano_bytes BIGINT, extractor_version TEXT, content_type TEXT
            );
            CREATE TABLE IF NOT EXISTS adjudicaciones (
                id SERIAL PRIMARY KEY, documento_id INTEGER REFERENCES documentos(id),
                estado TEXT, uid_adjudicacion TEXT UNIQUE,
                fecha_ingesta TIMESTAMPTZ DEFAULT NOW(), datos JSONB, ajuste_inflacion JSONB
            );
            CREATE TABLE IF NOT EXISTS amparos (
                id SERIAL PRIMARY KEY, adjudicacion_id INTEGER UNIQUE REFERENCES adjudicaciones(id),
                fecha TIMESTAMPTZ DEFAULT NOW(), folio TEXT, estado TEXT,
                monto_original NUMERIC, monto_ajustado NUMERIC, resolucion TEXT, firma_rsa BYTEA
            );
            CREATE TABLE IF NOT EXISTS compliance_blacklist (
                rfc TEXT PRIMARY KEY, nombre TEXT, nivel_riesgo TEXT, fecha_consulta TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS factoraje_requests (
                idempotency_key UUID PRIMARY KEY, adjudicacion_id INTEGER,
                monto NUMERIC, status TEXT, certificado_jwt TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS anexos (
                id SERIAL PRIMARY KEY, adjudicacion_id INTEGER REFERENCES adjudicaciones(id),
                tipo TEXT, ruta_minio TEXT, fecha_creacion TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS token_contratos (
                token_id UUID PRIMARY KEY,
                adjudicacion_id INTEGER REFERENCES adjudicaciones(id),
                rfc TEXT, monto_original NUMERIC, monto_factoraje NUMERIC,
                tasa_descuento NUMERIC, plazo_meses INTEGER,
                propietario_actual TEXT, estado TEXT DEFAULT 'ACTIVO',
                metadata_firma JSONB, fecha_creacion TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS cadena_suministro (
                id SERIAL PRIMARY KEY,
                contrato_id INTEGER REFERENCES adjudicaciones(id),
                rfc_proveedor TEXT NOT NULL,
                rfc_subcontratista TEXT NOT NULL,
                monto NUMERIC, fecha_inicio DATE, fecha_fin DATE,
                concepto TEXT, fuente TEXT DEFAULT 'pdf'
            );
            CREATE INDEX IF NOT EXISTS idx_cadena_proveedor ON cadena_suministro (rfc_proveedor);
            CREATE INDEX IF NOT EXISTS idx_cadena_sub ON cadena_suministro (rfc_subcontratista);
            CREATE TABLE IF NOT EXISTS actas_rescision (
                id SERIAL PRIMARY KEY, adjudicacion_id INTEGER REFERENCES adjudicaciones(id),
                rfc_proveedor TEXT, motivo TEXT, fecha_emision TIMESTAMPTZ DEFAULT NOW(),
                ruta_minio TEXT, firma_rsa BYTEA
            );
            CREATE TABLE IF NOT EXISTS ajustes_costos (
                id SERIAL PRIMARY KEY, adjudicacion_id INTEGER REFERENCES adjudicaciones(id),
                partida TEXT, insumo TEXT, sector INPP TEXT,
                monto_original NUMERIC, indice_base NUMERIC, indice_actual NUMERIC,
                factor_ajuste NUMERIC, monto_ajustado NUMERIC,
                documento_ruta TEXT, fecha_emision TIMESTAMPTZ DEFAULT NOW()
            );
            CREATE TABLE IF NOT EXISTS documentos_ajuste (
                id SERIAL PRIMARY KEY, adjudicacion_id INTEGER REFERENCES adjudicaciones(id),
                tipo TEXT, ruta_minio TEXT, fecha_creacion TIMESTAMPTZ DEFAULT NOW()
            );
            -- NUEVO: Inteligencia de Mercado
            CREATE TABLE IF NOT EXISTS precios_mercado (
                id SERIAL PRIMARY KEY,
                material TEXT NOT NULL,
                precio NUMERIC NOT NULL,
                moneda TEXT DEFAULT 'MXN',
                unidad TEXT DEFAULT 'pieza',
                fuente TEXT NOT NULL,
                url_fuente TEXT,
                categoria TEXT,
                subcategoria TEXT,
                tipo_precio TEXT DEFAULT 'menudista',
                fecha_extraccion TIMESTAMPTZ DEFAULT NOW(),
                ubicacion TEXT DEFAULT 'Mexico',
                marca TEXT,
                sku TEXT,
                disponibilidad TEXT,
                confianza NUMERIC DEFAULT 0.0,
                raw_data JSONB,
                UNIQUE(material, fuente, fecha_extraccion)
            );
            CREATE INDEX IF NOT EXISTS idx_precios_material ON precios_mercado (material);
            CREATE INDEX IF NOT EXISTS idx_precios_fecha ON precios_mercado (fecha_extraccion);
            CREATE INDEX IF NOT EXISTS idx_precios_fuente ON precios_mercado (fuente);
        """)
        logger.info("Esquema de PostgreSQL inicializado (10 capas + inteligencia de mercado).")


async def insertar_documento_y_adjudicaciones(
    pool, registros, metadata, max_retries=3
) -> Tuple[Optional[int], List[Tuple[int, int]]]:
    """Inserta documento y adjudicaciones con retry.
    CORRECCION #5: Implementa reintentos con backoff exponencial.
    """
    from soberano.parsers.pdf_parser import generar_uid_adjudicacion

    doc_id = None
    pares = []
    for attempt in range(1, max_retries + 1):
        try:
            async with pool.acquire() as conn:
                async with conn.transaction():
                    row = await conn.fetchrow(
                        """INSERT INTO documentos (estado, hash_sha256, ruta_pdf, url_origen, fuente,
                           timestamp_descarga, tamano_bytes, extractor_version, content_type)
                           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                           ON CONFLICT (hash_sha256) DO UPDATE SET
                               ruta_pdf = EXCLUDED.ruta_pdf,
                               url_origen = EXCLUDED.url_origen,
                               fuente = EXCLUDED.fuente,
                               timestamp_descarga = EXCLUDED.timestamp_descarga,
                               tamano_bytes = EXCLUDED.tamano_bytes,
                               extractor_version = EXCLUDED.extractor_version,
                               content_type = EXCLUDED.content_type
                           RETURNING id""",
                        metadata["estado"], metadata["hash_sha256"], metadata["ruta_pdf"],
                        metadata["url_origen"], metadata["fuente"], metadata["timestamp_descarga"],
                        metadata["tamano_bytes"], metadata["extractor_version"], metadata["content_type"]
                    )
                    doc_id = row["id"]
                    for idx, reg in enumerate(registros):
                        uid = generar_uid_adjudicacion(reg)
                        adj_row = await conn.fetchrow(
                            "INSERT INTO adjudicaciones (documento_id, estado, uid_adjudicacion, datos) "
                            "VALUES ($1,$2,$3,$4) ON CONFLICT (uid_adjudicacion) DO NOTHING RETURNING id",
                            doc_id, metadata["estado"], uid, json.dumps(reg)
                        )
                        if adj_row:
                            pares.append((idx, adj_row["id"]))
                        else:
                            existing = await conn.fetchrow(
                                "SELECT id FROM adjudicaciones WHERE uid_adjudicacion = $1", uid
                            )
                            if existing:
                                pares.append((idx, existing["id"]))
            logger.info(f"Documento {doc_id} con {len(pares)} adjudicaciones mapeadas")
            return doc_id, pares
        except Exception as e:
            logger.error(f"Error insertando (intento {attempt}): {e}")
            if attempt == max_retries:
                raise
            await asyncio.sleep(2 ** attempt)
    return doc_id, pares


async def guardar_precios_mercado(pool, precios_list):
    """Persiste precios de mercado en PostgreSQL."""
    async with pool.acquire() as conn:
        for p in precios_list:
            try:
                await conn.execute("""
                    INSERT INTO precios_mercado
                    (material, precio, moneda, unidad, fuente, url_fuente, categoria,
                     subcategoria, tipo_precio, fecha_extraccion, ubicacion, marca,
                     sku, disponibilidad, confianza, raw_data)
                    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
                    ON CONFLICT (material, fuente, fecha_extraccion) DO NOTHING
                """, p.material, p.precio, p.moneda, p.unidad, p.fuente, p.url_fuente,
                    p.categoria, p.subcategoria, p.tipo_precio, p.fecha_extraccion,
                    p.ubicacion, p.marca, p.sku, p.disponibilidad, p.confianza,
                    json.dumps(p.raw_data) if p.raw_data else None)
            except Exception as e:
                logger.error(f"Error guardando precio {p.material}: {e}")
