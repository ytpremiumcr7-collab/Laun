#!/usr/bin/env python3
"""Cliente Redis con streams y grupos de consumidores."""

import redis.asyncio as redis
from soberano.config.settings import settings


async def get_redis_client() -> redis.Redis:
    """Devuelve cliente Redis conectado."""
    return redis.from_url(f"redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}")


async def crear_grupo(redis_client: redis.Redis, stream: str, group: str):
    """Crea grupo de consumidores si no existe."""
    try:
        await redis_client.xgroup_create(stream, group, id="0", mkstream=True)
    except redis.ResponseError:
        pass
