#!/usr/bin/env python3
"""Extracción de cadena de suministro desde texto de actas."""

import re
from typing import List, Tuple, Optional, Dict


def extraer_subcontratistas_de_texto(texto: str) -> List[Tuple[str, Optional[float]]]:
    """Extrae RFCs de subcontratistas y montos de texto plano."""
    relaciones = []
    patron = re.compile(
        r'(?:subcontratar[aá]?\s*(?:a|con)?\s*)?([A-ZÑ&]{3,4}[0-9]{6}[0-9A-Z]{3})\s'
        r'(?:por\s*(?:un\s+)?monto\s*(?:de\s*)?)?\$\s*([\d,]+\.?\d*)',
        re.IGNORECASE
    )
    for match in patron.finditer(texto):
        rfc_sub = match.group(1)
        monto_str = match.group(2).replace(",", "") if match.group(2) else None
        monto = float(monto_str) if monto_str else None
        relaciones.append((rfc_sub, monto))
    return relaciones


def parsear_cadena_suministro_desde_pdf(texto_completo: str, rfc_proveedor: str, adj_id: int) -> List[Dict]:
    """Parsea cadena de suministro desde texto completo de PDF."""
    subcontratistas = extraer_subcontratistas_de_texto(texto_completo)
    registros = []
    for rfc_sub, monto in subcontratistas:
        registros.append({
            "contrato_id": adj_id,
            "rfc_proveedor": rfc_proveedor,
            "rfc_subcontratista": rfc_sub,
            "monto": monto,
            "concepto": "Subcontratacion detectada en acta",
            "fuente": "pdf"
        })
    return registros
