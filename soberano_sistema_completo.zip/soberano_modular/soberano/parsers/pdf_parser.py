#!/usr/bin/env python3
"""Parser de PDFs de actas de fallo con extracción de tablas y texto."""

import hashlib
import json
import os
import re
from typing import List, Dict, Any

import pdfplumber

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.core.security import es_pdf_valido


def parse_pdf_sync(ruta_pdf: str, estado: str) -> List[Dict[str, Any]]:
    """Parsea PDF de acta de fallo y extrae adjudicaciones.

    CORRECCIÓN #1: Usa ruta_pdf directamente, no variable 'local' indefinida.
    CORRECCIÓN #2: pdfplumber ya está importado al inicio del módulo.
    """
    logger.info(f"Analizando {ruta_pdf}")
    registros = []
    if not es_pdf_valido(ruta_pdf):
        return registros

    try:
        with pdfplumber.open(ruta_pdf) as pdf:
            texto_completo = " ".join(page.extract_text() or "" for page in pdf.pages)
            if not any(kw in texto_completo.lower() for kw in [
                "acta de fallo", "fallo de la licitacion", "adjudicacion",
                "se adjudica", "ganador", "contrato adjudicado"
            ]):
                return registros

            for page in pdf.pages:
                tables = page.extract_tables()
                if not tables:
                    continue
                for table in tables:
                    if not table or len(table) < 2:
                        continue
                    header = table[0]
                    col_rfc = col_pu = col_importe = None
                    for idx, cell in enumerate(header):
                        if cell is None:
                            continue
                        txt = str(cell).lower().strip()
                        if not col_rfc and ("rfc" in txt or "proveedor" in txt):
                            col_rfc = idx
                        elif not col_pu and ("unitario" in txt or "precio" in txt):
                            col_pu = idx
                        elif not col_importe and ("importe" in txt or "total" in txt or "monto" in txt):
                            col_importe = idx

                    # Fallback: búsqueda por regex en filas
                    if col_rfc is None or col_importe is None:
                        for row in table[1:]:
                            row_text = " ".join([str(c).strip() for c in row if c])
                            rfc_match = re.search(r"[A-ZÑ&]{3,4}[0-9]{6}[0-9A-Z]{3}", row_text)
                            if rfc_match:
                                for i, c in enumerate(row):
                                    if c and rfc_match.group(0) in str(c):
                                        col_rfc = i
                                        break
                                numeros = re.findall(r"\$\s*([\d,]+\.?\d*)", row_text)
                                if not numeros:
                                    numeros = re.findall(r"(?<!\d)([\d,]+\.\d{2})(?!\d)", row_text)
                                if numeros:
                                    max_val = 0
                                    for i, c in enumerate(row):
                                        if c:
                                            for n in numeros:
                                                if n in str(c):
                                                    try:
                                                        v = float(n.replace(",", ""))
                                                        if v > max_val:
                                                            max_val = v
                                                            col_importe = i
                                                    except:
                                                        pass
                                break

                    for row in table[1:]:
                        if not row:
                            continue
                        rfc_val = monto_val = precio_unit = None
                        if col_rfc is not None and col_rfc < len(row):
                            val = str(row[col_rfc]).strip() if row[col_rfc] else ""
                            if re.match(r"[A-ZÑ&]{3,4}[0-9]{6}[0-9A-Z]{3}", val):
                                rfc_val = val
                        if col_importe is not None and col_importe < len(row):
                            val = str(row[col_importe]).strip() if row[col_importe] else ""
                            nums = re.findall(r"[\d,]+\.?\d*", val)
                            if nums:
                                try:
                                    monto_val = float(nums[0].replace(",", ""))
                                except:
                                    pass
                        if col_pu is not None and col_pu < len(row):
                            val = str(row[col_pu]).strip() if row[col_pu] else ""
                            nums = re.findall(r"[\d,]+\.?\d*", val)
                            if nums:
                                try:
                                    precio_unit = float(nums[0].replace(",", ""))
                                except:
                                    pass

                        if not rfc_val or not monto_val:
                            row_text = " ".join([str(c).strip() for c in row if c])
                            rfc_match = re.search(r"[A-ZÑ&]{3,4}[0-9]{6}[0-9A-Z]{3}", row_text)
                            if rfc_match:
                                rfc_val = rfc_match.group(0)
                            montos = re.findall(r"\$\s*([\d,]+\.?\d*)", row_text)
                            if not montos:
                                montos = re.findall(r"(?<!\d)([\d,]+\.\d{2})(?!\d)", row_text)
                            valores = []
                            for m in montos:
                                try:
                                    valores.append(float(m.replace(",", "")))
                                except:
                                    pass
                            if valores:
                                monto_val = max(valores)
                                if len(valores) >= 2:
                                    precio_unit = min(valores)

                        if rfc_val and monto_val and re.match(r"[A-ZÑ&]{3,4}[0-9]{6}[0-9A-Z]{3}", rfc_val):
                            cantidad = 0
                            if precio_unit and precio_unit > 0:
                                cantidad = int(round(monto_val / precio_unit))
                            registros.append({
                                "rfc": rfc_val,
                                "precio_unitario": precio_unit,
                                "monto_total": monto_val,
                                "cantidad": cantidad,
                                "estado": estado,
                            })

            # Fallback: línea por línea si no hay tablas
            if not registros:
                lines = texto_completo.split("\n")
                for line in lines:
                    rfc_match = re.search(r"[A-ZÑ&]{3,4}[0-9]{6}[0-9A-Z]{3}", line)
                    if not rfc_match:
                        continue
                    montos = re.findall(r"\$\s*([\d,]+\.?\d*)", line)
                    if not montos:
                        montos = re.findall(r"(?<!\d)([\d,]+\.\d{2})(?!\d)", line)
                    if montos:
                        try:
                            monto = float(montos[0].replace(",", ""))
                            registros.append({
                                "rfc": rfc_match.group(0),
                                "precio_unitario": None,
                                "monto_total": monto,
                                "cantidad": 0,
                                "estado": estado,
                            })
                        except:
                            pass
        return registros
    except Exception as e:
        logger.error(f"Error parseando PDF: {e}")
        return registros


def generar_uid_adjudicacion(registro: Dict) -> str:
    """Genera UID determinista para una adjudicacion."""
    datos = json.dumps(registro, sort_keys=True).encode()
    return hashlib.sha256(datos).hexdigest()
