#!/usr/bin/env python3
"""Motor A: FinTech — Tokenización, factoraje y mesa de dinero."""

import json
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List

import aiohttp
import asyncpg

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.security import firmar_payload_efirma, generar_token_jwt


async def obtener_tasa_descuento_banxico() -> Optional[float]:
    """Obtiene tasa de descuento de Banxico."""
    if not settings.BANXICO_API_KEY:
        return settings.TASA_DESCUENTO_DEFAULT
    url = f"https://www.banxico.org.mx/SieAPIRest/service/v1/series/{settings.BANXICO_TASA_SERIE}/datos/oportuno"
    headers = {"Bmx-Token": settings.BANXICO_API_KEY}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers, timeout=10) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    series = data.get("bmx", {}).get("series", [])
                    if series and series[0].get("datos"):
                        return float(series[0]["datos"][-1]["dato"]) / 100.0
    except Exception as e:
        logger.error(f"Error obteniendo tasa de descuento: {e}")
    return settings.TASA_DESCUENTO_DEFAULT


def calcular_flujo_caja(monto_total: float, plazo_meses: int = None) -> List[float]:
    """Calcula flujo de caja mensual."""
    if plazo_meses is None:
        plazo_meses = settings.PLAZO_CONTRATO_MESES
    pago_mensual = monto_total / plazo_meses
    return [pago_mensual] * plazo_meses


def calcular_vpn(flujos: List[float], tasa_anual: float) -> float:
    """Calcula Valor Presente Neto."""
    tasa_mensual = tasa_anual / 12.0
    vpn = 0.0
    for i, flujo in enumerate(flujos, start=1):
        vpn += flujo / ((1 + tasa_mensual) ** i)
    return vpn


class MesaDinero:
    """Mesa de dinero para evaluación y tokenización de factoraje."""

    def __init__(self, pg_pool: asyncpg.Pool, sat_client):
        self.pg_pool = pg_pool
        self.sat_client = sat_client

    async def evaluar_riesgo(self, rfc: str) -> Dict[str, Any]:
        """Evalúa riesgo crediticio combinando SAT e historial interno."""
        resultado_sat = await self.sat_client.consultar_rfc(rfc)
        async with self.pg_pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT COUNT(*) as incumplimientos FROM adjudicaciones WHERE datos->>'rfc' = $1",
                rfc
            )
        incumplimientos = row["incumplimientos"] if row else 0
        riesgo = "ALTO" if resultado_sat["blacklisted"] or incumplimientos > 3 else "BAJO"
        return {
            "rfc": rfc,
            "blacklisted_sat": resultado_sat["blacklisted"],
            "incumplimientos_internos": incumplimientos,
            "riesgo": riesgo
        }

    async def solicitar_factoraje(
        self, adj_id: int, monto: float, plazo_meses: int = None
    ) -> Dict[str, Any]:
        """Solicita factoraje para una adjudicación.
        CORRECCION #6: Loguea advertencia si adj_id es None.
        """
        if adj_id is None:
            logger.warning("Factoraje rechazado: adj_id es None")
            return {"error": "Adjudicacion no encontrada", "riesgo": None}

        async with self.pg_pool.acquire() as conn:
            adj = await conn.fetchrow("SELECT * FROM adjudicaciones WHERE id = $1", adj_id)
            if not adj:
                logger.warning(f"Factoraje rechazado: adjudicacion {adj_id} no existe")
                return {"error": "Adjudicacion no encontrada", "riesgo": None}
            datos = json.loads(adj["datos"]) if adj["datos"] else {}
            ajuste = json.loads(adj["ajuste_inflacion"]) if adj["ajuste_inflacion"] else {}
            monto_original = ajuste.get("monto_ajustado", datos.get("monto_total", monto))
            rfc = datos.get("rfc", "")

        riesgo = await self.evaluar_riesgo(rfc)
        if riesgo["riesgo"] == "ALTO":
            return {"error": "Riesgo elevado, factoraje rechazado", "riesgo": riesgo}

        tasa_anual = await obtener_tasa_descuento_banxico()
        flujos = calcular_flujo_caja(monto_original, plazo_meses)
        vpn = calcular_vpn(flujos, tasa_anual)
        monto_factoraje = vpn
        token_id = str(uuid.uuid4())

        payload_token = {
            "token_id": token_id, "adjudicacion_id": adj_id, "rfc": rfc,
            "monto_original": monto_original, "monto_factoraje": monto_factoraje,
            "tasa_descuento": tasa_anual, "plazo_meses": plazo_meses or settings.PLAZO_CONTRATO_MESES,
            "fecha_emision": datetime.now(timezone.utc).isoformat(),
            "propietario_actual": rfc, "estado": "ACTIVO"
        }
        firma = firmar_payload_efirma(payload_token)
        payload_token["firma"] = firma.hex()

        async with self.pg_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO token_contratos (token_id, adjudicacion_id, rfc, monto_original, monto_factoraje,
                                             tasa_descuento, plazo_meses, propietario_actual, estado, metadata_firma)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """, token_id, adj_id, rfc, monto_original, monto_factoraje, tasa_anual,
                plazo_meses or settings.PLAZO_CONTRATO_MESES, rfc, "ACTIVO", json.dumps(payload_token))

        await metrics.increment("tokens_emitidos")
        logger.info(f"Token {token_id} emitido para adjudicacion {adj_id} por ${monto_factoraje:,.2f}")
        return {
            "token_id": token_id, "monto_factoraje": monto_factoraje,
            "tasa_descuento": tasa_anual, "vpn": vpn, "riesgo": riesgo
        }
