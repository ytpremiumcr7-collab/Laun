#!/usr/bin/env python3
"""Motor C: Macroeconómico — Ajuste de costos, INPP, documentos técnicos."""

import asyncio
import json
import os
import time
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

import aiohttp
import asyncpg
from minio import Minio

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.core.security import firmar_payload_efirma
from soberano.core.utils import now_iso

# Librerías opcionales
try:
    from jinja2 import Template
    from weasyprint import HTML
    ANEXOS_DISPONIBLES = True
except ImportError:
    ANEXOS_DISPONIBLES = False


async def obtener_inpp_sectorial(sector: str, fecha_base: str, fecha_actual: str) -> Optional[Tuple[float, float]]:
    """Obtiene índices INPP sectorial de Banxico."""
    serie = settings.INPP_SERIES.get(sector)
    if not serie or not settings.BANXICO_API_KEY:
        return None
    url = f"https://www.banxico.org.mx/SieAPIRest/service/v1/series/{serie}/datos/{fecha_base}/{fecha_actual}"
    headers = {"Bmx-Token": settings.BANXICO_API_KEY}
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, headers=headers, timeout=15) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    series_data = data.get("bmx", {}).get("series", [])
                    if series_data and series_data[0].get("datos") and len(series_data[0]["datos"]) >= 2:
                        base = float(series_data[0]["datos"][0]["dato"])
                        actual = float(series_data[0]["datos"][-1]["dato"])
                        return base, actual
        except Exception as e:
            logger.error(f"Error obteniendo INPP sectorial {sector}: {e}")
    return None


def calcular_ajuste_por_partida(monto_original: float, indice_base: float, indice_actual: float) -> Dict[str, Any]:
    """Calcula factor de ajuste por partida."""
    factor = indice_actual / indice_base
    monto_ajustado = monto_original * factor
    return {
        "factor": factor,
        "monto_original": monto_original,
        "monto_ajustado": monto_ajustado,
        "indice_base": indice_base,
        "indice_actual": indice_actual
    }


async def generar_documento_ajuste_costos(
    adj_id: int, partidas: List[Dict], pg_pool: asyncpg.Pool, minio_client: Minio
) -> Optional[str]:
    """Genera PDF técnico de ajuste de costos."""
    if not ANEXOS_DISPONIBLES:
        logger.error("Jinja2/WeasyPrint no disponibles; no se puede generar documento de ajuste.")
        return None

    async with pg_pool.acquire() as conn:
        adj = await conn.fetchrow("SELECT * FROM adjudicaciones WHERE id = $1", adj_id)
        if not adj:
            return None
        estado = adj["estado"]

    tabla_partidas_html = """<table border="1" cellpadding="4" cellspacing="0">
        <tr><th>Partida</th><th>Insumo</th><th>Sector</th><th>Monto Original</th><th>Índice Base</th><th>Índice Actual</th><th>Factor</th><th>Monto Ajustado</th></tr>"""
    for p in partidas:
        tabla_partidas_html += f"""
        <tr>
            <td>{p.get('partida','')}</td><td>{p.get('insumo','')}</td><td>{p.get('sector','')}</td>
            <td>${p.get('monto_original',0):,.2f}</td><td>{p.get('indice_base',0):.4f}</td>
            <td>{p.get('indice_actual',0):.4f}</td><td>{p.get('factor',1.0):.4f}</td>
            <td>${p.get('monto_ajustado',0):,.2f}</td>
        </tr>"""
    tabla_partidas_html += "</table>"

    plantilla = Template(f"""
    <html><body>
    <h1>Documento Técnico de Ajuste de Costos</h1>
    <p>Adjudicación: {{adj_id}}</p><p>Estado: {{estado}}</p>
    <p>Fecha de emisión: {{fecha_emision}}</p>
    <h2>Metodología</h2>
    <p>De conformidad con la Ley de Adquisiciones Arrendamientos y Servicios del Sector Público, se aplican los Índices Nacionales de Precios al Productor (INPP) por sector, publicados por el INEGI a través del Banco de México.</p>
    <p>El factor de ajuste se calcula como <em>Índice Actual / Índice Base</em>.</p>
    <h2>Resultados</h2>
    {tabla_partidas_html}
    <p>Firma digital: {{firma}}</p>
    </body></html>
    """)
    html = plantilla.render(
        adj_id=adj_id, estado=estado,
        fecha_emision=datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M"),
        firma=firmar_payload_efirma({"adj_id": adj_id, "tipo": "ajuste_costos"}).hex()[:64]
    )
    pdf_bytes = HTML(string=html).write_pdf()
    ruta_temp = os.path.join(settings.SPOOL_DIR, f"ajuste_costos_{adj_id}_{int(time.time())}.pdf")
    with open(ruta_temp, "wb") as f:
        f.write(pdf_bytes)

    from soberano.storage.minio_client import guardar_en_minio_sync
    obj_name = await asyncio.get_running_loop().run_in_executor(
        None, guardar_en_minio_sync, minio_client, ruta_temp, estado,
        __import__("hashlib").sha256(pdf_bytes).hexdigest()
    )
    os.remove(ruta_temp)

    async with pg_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO documentos_ajuste (adjudicacion_id, tipo, ruta_minio) VALUES ($1, 'ajuste_costos', $2)",
            adj_id, obj_name
        )
    logger.info(f"Documento de ajuste de costos generado para adjudicación {adj_id}")
    return obj_name


async def procesar_ajuste_costos(adj_id: int, pg_pool: asyncpg.Pool, minio_client: Minio) -> bool:
    """Procesa ajuste de costos completo para una adjudicación."""
    async with pg_pool.acquire() as conn:
        adj = await conn.fetchrow("SELECT * FROM adjudicaciones WHERE id = $1", adj_id)
        if not adj:
            return False
        datos = json.loads(adj["datos"]) if adj["datos"] else {}
        monto_total = datos.get("monto_total", 0)

    partidas = [
        {"partida": "1", "insumo": "Materiales de construcción", "sector": "construccion", "monto_original": monto_total * 0.4},
        {"partida": "2", "insumo": "Mano de obra", "sector": "servicios", "monto_original": monto_total * 0.3},
        {"partida": "3", "insumo": "Maquinaria", "sector": "manufactura", "monto_original": monto_total * 0.3},
    ]

    fecha_base = "2024-01-15"
    fecha_actual = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    ajustes_aplicados = []

    for partida in partidas:
        indices = await obtener_inpp_sectorial(partida["sector"], fecha_base, fecha_actual)
        if not indices:
            logger.warning(f"No se pudieron obtener índices para sector {partida['sector']}")
            continue
        base, actual = indices
        resultado = calcular_ajuste_por_partida(partida["monto_original"], base, actual)
        async with pg_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO ajustes_costos (adjudicacion_id, partida, insumo, sector, monto_original,
                                            indice_base, indice_actual, factor_ajuste, monto_ajustado)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            """, adj_id, partida["partida"], partida["insumo"], partida["sector"],
                partida["monto_original"], base, actual, resultado["factor"], resultado["monto_ajustado"])
        ajustes_aplicados.append({**partida, **resultado})

    if ajustes_aplicados and settings.GENERAR_AJUSTE_COSTOS_AUTOMATICO:
        await generar_documento_ajuste_costos(adj_id, ajustes_aplicados, pg_pool, minio_client)
    return True
