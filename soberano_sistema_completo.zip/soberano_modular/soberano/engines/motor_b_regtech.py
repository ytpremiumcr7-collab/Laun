#!/usr/bin/env python3
"""Motor B: RegTech — SAT 69-B, cadena de suministro, actas de rescisión."""

import asyncio
import json
import os
import re
import time
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

import aiohttp
from minio import Minio

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.security import firmar_payload_efirma, cargar_efirma

# Librerías opcionales
try:
    from lxml import etree
    from signxml import XMLSigner, XMLVerifier
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, NoEncryption
    SOAP_SIGNING_AVAILABLE = True
except ImportError:
    SOAP_SIGNING_AVAILABLE = False

try:
    from jinja2 import Template
    from weasyprint import HTML
    ANEXOS_DISPONIBLES = True
except ImportError:
    ANEXOS_DISPONIBLES = False


class SATClient:
    """Cliente para consulta SAT 69-B con firma SOAP."""

    def __init__(self):
        self.wsdl_url = settings.SAT_WSOPIC_WSDL
        self.cert_path = settings.SAT_WSOPIC_CERT_PATH
        self.verify_ssl = settings.SAT_WSOPIC_VERIFY_SSL

    def _firmar_soap(self, xml_envelope: str) -> str:
        """Firma envelope SOAP con e.Firma."""
        if not SOAP_SIGNING_AVAILABLE:
            raise RuntimeError("Librerías para firma SOAP no instaladas")
        private_key, certificate = cargar_efirma()
        cert_pem = certificate.public_bytes(serialization.Encoding.PEM).decode()
        key_pem = private_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()).decode()
        root = etree.fromstring(xml_envelope)
        signed = XMLSigner(
            method=signxml.methods.enveloped,
            signature_algorithm="rsa-sha256",
            digest_algorithm="sha256",
            c14n_algorithm="http://www.w3.org/2001/10/xml-exc-c14n#"
        ).sign(root, key=key_pem, cert=cert_pem)
        return etree.tostring(signed, xml_declaration=True, encoding="UTF-8").decode()

    async def consultar_rfc(self, rfc: str) -> Dict[str, Any]:
        """Consulta RFC en lista negra SAT 69-B."""
        await metrics.increment("sat_consultas")
        soap_template = f"""<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:ns="http://sat.gob.mx/ws/opinion">
    <soap:Body>
        <ns:consultaOpinion>
            <rfc>{rfc}</rfc>
        </ns:consultaOpinion>
    </soap:Body>
</soap:Envelope>"""
        try:
            xml_firmado = self._firmar_soap(soap_template)
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.wsdl_url,
                    data=xml_firmado,
                    headers={"Content-Type": "text/xml; charset=utf-8", "SOAPAction": "consultaOpinion"},
                    ssl=self.verify_ssl,
                    timeout=30
                ) as resp:
                    if resp.status == 200:
                        respuesta_xml = await resp.text()
                        root = etree.fromstring(respuesta_xml)
                        ns = {"soap": "http://schemas.xmlsoap.org/soap/envelope/",
                              "ns2": "http://sat.gob.mx/ws/opinion"}
                        estatus = root.find(".//ns2:estatus", ns).text
                        blacklisted = estatus == "Negativa"
                        nivel_riesgo = "ALTO" if blacklisted else "BAJO"
                        nombre = root.find(".//ns2:nombre", ns).text if root.find(".//ns2:nombre", ns) is not None else ""
                        return {
                            "rfc": rfc, "blacklisted": blacklisted,
                            "nivel_riesgo": nivel_riesgo, "nombre": nombre,
                            "fecha_consulta": datetime.now(timezone.utc).isoformat()
                        }
                    else:
                        logger.error(f"SAT devolvió HTTP {resp.status}")
                        return {"rfc": rfc, "blacklisted": False, "nivel_riesgo": "ERROR", "nombre": "", "fecha_consulta": ""}
        except Exception as e:
            logger.error(f"Error consultando SAT 69-B: {e}")
            return {"rfc": rfc, "blacklisted": False, "nivel_riesgo": "ERROR", "nombre": str(e), "fecha_consulta": ""}


async def suspender_spei_automatico(rfc: str, motivo: str) -> Dict[str, Any]:
    """Suspende SPEI para un RFC en lista negra."""
    if not settings.SPEI_API_URL:
        logger.warning("SPEI no configurado; la suspensión no se ejecutará realmente.")
        return {"status": "SIMULADO", "rfc": rfc}
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(
                settings.SPEI_API_URL,
                json={"rfc": rfc, "motivo": motivo},
                headers={"Authorization": f"Bearer {settings.SPEI_API_KEY}"},
                timeout=15
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    logger.info(f"SPEI suspendido para {rfc}: {data}")
                    return data
                else:
                    logger.error(f"Error SPEI {resp.status}")
                    return {"status": "ERROR", "rfc": rfc}
        except Exception as e:
            logger.error(f"Excepción SPEI: {e}")
            return {"status": "ERROR", "rfc": rfc}


PLANTILLA_ACTA_RESCISION = """
<html><body>
<h1>ACTA DE RESCISIÓN DE CONTRATO</h1>
<p>En la Ciudad de México, a {{ fecha_emision }}.</p>
<p>Con fundamento en el artículo 69-B del Código Fiscal de la Federación y demás aplicables,
se rescinde el contrato derivado de la adjudicación {{ adjudicacion_id }}.</p>
<p>Proveedor: {{ rfc_proveedor }}</p>
<p>Motivo: {{ motivo }}</p>
<p>Monto original del contrato: ${{ monto_original }}</p>
<p>La presente acta se emite de manera automática por el Sistema Soberano de 10 Capas.</p>
<p>Firma digital: {{ firma }}</p>
</body></html>"""


async def generar_acta_rescision(
    adj_id: int, rfc: str, motivo: str, pg_pool, minio_client: Minio
) -> Optional[str]:
    """Genera acta de rescisión en PDF y la guarda en MinIO."""
    if not ANEXOS_DISPONIBLES:
        logger.error("Jinja2/WeasyPrint no disponibles; no se puede generar acta.")
        return None

    async with pg_pool.acquire() as conn:
        adj = await conn.fetchrow("SELECT * FROM adjudicaciones WHERE id = $1", adj_id)
        if not adj:
            raise ValueError("Adjudicación no encontrada")
        datos = json.loads(adj["datos"]) if adj["datos"] else {}
        ajuste = json.loads(adj["ajuste_inflacion"]) if adj["ajuste_inflacion"] else {}
        monto_original = ajuste.get("monto_ajustado", datos.get("monto_total", 0))
        estado = adj["estado"]

    template = Template(PLANTILLA_ACTA_RESCISION)
    html = template.render(
        adjudicacion_id=adj_id, rfc_proveedor=rfc, motivo=motivo,
        monto_original=monto_original,
        fecha_emision=datetime.now(timezone.utc).strftime("%d/%m/%Y %H:%M"),
        firma=firmar_payload_efirma({"adj_id": adj_id, "rfc": rfc}).hex()[:64]
    )
    pdf_bytes = HTML(string=html).write_pdf()
    ruta_temp = os.path.join(settings.SPOOL_DIR, f"acta_rescision_{adj_id}_{int(time.time())}.pdf")
    with open(ruta_temp, "wb") as f:
        f.write(pdf_bytes)

    from soberano.storage.minio_client import guardar_en_minio_sync
    obj_name = await asyncio.get_running_loop().run_in_executor(
        None, guardar_en_minio_sync, minio_client, ruta_temp, estado,
        __import__("hashlib").sha256(pdf_bytes).hexdigest()
    )
    os.remove(ruta_temp)

    async with pg_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO actas_rescision (adjudicacion_id, rfc_proveedor, motivo, ruta_minio, firma_rsa) "
            "VALUES ($1, $2, $3, $4, $5)",
            adj_id, rfc, motivo, obj_name,
            firmar_payload_efirma({"adj_id": adj_id, "rfc": rfc})
        )
    logger.info(f"Acta de rescisión generada para adjudicación {adj_id}")
    return obj_name
