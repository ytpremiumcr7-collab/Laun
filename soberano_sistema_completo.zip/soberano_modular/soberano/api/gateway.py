#!/usr/bin/env python3
"""API Gateway con JWT, health checks y métricas."""

import json
from aiohttp import web

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.security import validar_token_jwt


async def ingesta_handler(request: web.Request) -> web.Response:
    """Handler de ingesta de documentos estatales."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)

    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    required = ["estado", "anio", "ruta_pdf", "hash", "url_origen", "fuente", "timestamp_descarga", "tamano_bytes"]
    if not all(k in data for k in required):
        return web.json_response({"error": "ERR_MALFORMED"}, status=400)

    redis_client = request.app["redis"]
    try:
        msg_id = await redis_client.xadd(settings.REDIS_STREAM, {k: str(v) for k, v in data.items()})
        logger.info(f"Mensaje {msg_id} insertado para {data['estado']}")
        return web.json_response({"success": True, "transaction_id": msg_id, "status": "METADATA_SECURED"})
    except Exception as e:
        logger.error(f"Redis error: {e}")
        return web.json_response({"error": "ERR_REDIS"}, status=500)


async def health_handler(request: web.Request) -> web.Response:
    """Health check de todos los servicios."""
    status = {"redis": False, "postgres": False, "minio": False, "sat": False}
    try:
        await request.app["redis"].ping()
        status["redis"] = True
    except Exception:
        pass
    try:
        async with request.app["pg_pool"].acquire() as conn:
            await conn.execute("SELECT 1")
        status["postgres"] = True
    except Exception:
        pass
    try:
        minio_client = request.app["minio_client"]
        loop = __import__("asyncio").get_running_loop()
        exists = await loop.run_in_executor(None, minio_client.bucket_exists, settings.MINIO_BUCKET)
        status["minio"] = exists
    except Exception:
        pass
    try:
        from soberano.engines.motor_b_regtech import SATClient
        sat = SATClient()
        await sat.consultar_rfc("XAXX010101000")
        status["sat"] = True
    except Exception:
        pass
    return web.json_response(status)


async def metrics_handler(request: web.Request) -> web.Response:
    """Devuelve métricas actuales del sistema."""
    current_metrics = await metrics.snapshot()
    try:
        dlq_len = await request.app["redis"].xlen(settings.REDIS_DLQ_STREAM)
        current_metrics["dlq_size"] = dlq_len
    except Exception:
        current_metrics["dlq_size"] = -1
    return web.json_response(current_metrics)


async def market_intel_handler(request: web.Request) -> web.Response:
    """Handler para consultar inteligencia de mercado."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)

    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    material = data.get("material")
    action = data.get("action", "compare")

    if not material:
        return web.json_response({"error": "MISSING_MATERIAL"}, status=400)

    redis_client = request.app["redis"]

    if action == "compare":
        # Verificar caché
        cached = await redis_client.get(f"market:compare:{material}")
        if cached:
            return web.json_response(json.loads(cached))

    # Encolar para worker
    try:
        msg_id = await redis_client.xadd(settings.MARKET_INTEL_STREAM, {
            "action": action,
            "material": material,
            "timestamp": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        })
        return web.json_response({"success": True, "transaction_id": msg_id, "status": "QUEUED"})
    except Exception as e:
        logger.error(f"Error encolando market intel: {e}")
        return web.json_response({"error": "ERR_REDIS"}, status=500)


async def market_prices_handler(request: web.Request) -> web.Response:
    """Consulta precios históricos de materiales."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)

    material = request.query.get("material")
    fuente = request.query.get("fuente")
    limit = int(request.query.get("limit", "50"))

    pool = request.app["pg_pool"]
    async with pool.acquire() as conn:
        if material and fuente:
            rows = await conn.fetch(
                "SELECT * FROM precios_mercado WHERE material = $1 AND fuente = $2 ORDER BY fecha_extraccion DESC LIMIT $3",
                material, fuente, limit
            )
        elif material:
            rows = await conn.fetch(
                "SELECT * FROM precios_mercado WHERE material = $1 ORDER BY fecha_extraccion DESC LIMIT $2",
                material, limit
            )
        else:
            rows = await conn.fetch(
                "SELECT * FROM precios_mercado ORDER BY fecha_extraccion DESC LIMIT $1", limit
            )

    resultados = [dict(r) for r in rows]
    return web.json_response({"precios": resultados, "count": len(resultados)})
