#!/usr/bin/env python3
"""Middleware de la API (CORS, rate limiting, logging)."""

from aiohttp import web
from soberano.config.logging_config import logger


@web.middleware
async def cors_middleware(request, handler):
    """Middleware CORS."""
    if request.method == "OPTIONS":
        return web.Response(
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization",
            }
        )
    response = await handler(request)
    response.headers["Access-Control-Allow-Origin"] = "*"
    return response


@web.middleware
async def logging_middleware(request, handler):
    """Middleware de logging de requests."""
    logger.info(f"{request.method} {request.path} — {request.remote}")
    try:
        response = await handler(request)
        logger.info(f"{request.method} {request.path} — {response.status}")
        return response
    except Exception as e:
        logger.error(f"{request.method} {request.path} — ERROR: {e}")
        raise
