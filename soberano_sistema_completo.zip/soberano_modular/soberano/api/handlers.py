#!/usr/bin/env python3
"""Handlers adicionales de la API (factoraje, tokens, ajustes, anexos)."""

import json
from datetime import datetime, timezone, timedelta

from aiohttp import web

from soberano.config.settings import settings
from soberano.config.logging_config import logger
from soberano.config.metrics import metrics
from soberano.core.security import validar_token_jwt, generar_token_jwt, firmar_payload_efirma
from soberano.engines.motor_a_fintech import MesaDinero
from soberano.engines.motor_c_macro import procesar_ajuste_costos
from soberano.engines.motor_b_regtech import SATClient


async def certificado_factoraje_handler(request: web.Request) -> web.Response:
    """Genera certificado JWT de factoraje."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)
    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    adj_id = data.get("adjudicacion_id")
    if not adj_id:
        return web.json_response({"error": "MISSING_ADJUDICACION_ID"}, status=400)

    pool = request.app["pg_pool"]
    async with pool.acquire() as conn:
        adj = await conn.fetchrow("SELECT * FROM adjudicaciones WHERE id = $1", int(adj_id))
    if not adj:
        return web.json_response({"error": "NOT_FOUND"}, status=404)

    datos = json.loads(adj["datos"]) if adj["datos"] else {}
    ajuste = json.loads(adj["ajuste_inflacion"]) if adj["ajuste_inflacion"] else {}
    monto = ajuste.get("monto_ajustado", datos.get("monto_total", 0))
    rfc = datos.get("rfc", "")

    payload = {
        "sub": "certificado_factoraje", "adjudicacion_id": adj_id, "rfc": rfc,
        "monto": monto, "estado": adj["estado"],
        "iat": datetime.now(timezone.utc),
        "exp": datetime.now(timezone.utc) + timedelta(days=30),
        "jti": str(__import__("uuid").uuid4()),
    }
    token = generar_token_jwt(payload)
    await metrics.increment("tokens_emitidos")
    return web.json_response({"certificado_jwt": token, "adjudicacion_id": adj_id, "monto": monto, "rfc": rfc})


async def factoraje_solicitar_handler(request: web.Request) -> web.Response:
    """Solicita factoraje real."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)
    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    adj_id = data.get("adjudicacion_id")
    plazo_meses = data.get("plazo_meses")
    monto = float(data.get("monto", 0))
    if not adj_id:
        return web.json_response({"error": "MISSING_ADJUDICACION_ID"}, status=400)

    try:
        mesa = MesaDinero(request.app["pg_pool"], SATClient())
        resultado = await mesa.solicitar_factoraje(int(adj_id), monto, plazo_meses)
        if "error" in resultado:
            return web.json_response(resultado, status=400)
        return web.json_response(resultado)
    except Exception as e:
        logger.error(f"Error en factoraje: {e}")
        return web.json_response({"error": str(e)}, status=500)


async def transferir_token_handler(request: web.Request) -> web.Response:
    """Transfiere token de factoraje."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)
    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    token_id = data.get("token_id")
    nuevo_propietario = data.get("nuevo_propietario")
    if not token_id or not nuevo_propietario:
        return web.json_response({"error": "MISSING_FIELDS"}, status=400)

    pool = request.app["pg_pool"]
    async with pool.acquire() as conn:
        token = await conn.fetchrow("SELECT * FROM token_contratos WHERE token_id = $1", __import__("uuid").UUID(token_id))
        if not token:
            return web.json_response({"error": "TOKEN_NOT_FOUND"}, status=404)
        if token["estado"] != "ACTIVO":
            return web.json_response({"error": "TOKEN_NOT_ACTIVE"}, status=400)
        await conn.execute(
            "UPDATE token_contratos SET propietario_actual = $1 WHERE token_id = $2",
            nuevo_propietario, __import__("uuid").UUID(token_id)
        )
    logger.info(f"Token {token_id} transferido a {nuevo_propietario}")
    return web.json_response({"status": "TRANSFERIDO", "token_id": token_id, "nuevo_propietario": nuevo_propietario})


async def ajuste_costos_handler(request: web.Request) -> web.Response:
    """Ejecuta ajuste de costos."""
    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)
    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    adj_id = data.get("adjudicacion_id")
    if not adj_id:
        return web.json_response({"error": "MISSING_ADJUDICACION_ID"}, status=400)

    pool = request.app["pg_pool"]
    minio_client = request.app["minio_client"]
    success = await procesar_ajuste_costos(int(adj_id), pool, minio_client)
    if success:
        return web.json_response({"status": "AJUSTE_PROCESADO", "adj_id": adj_id})
    else:
        return web.json_response({"error": "ADJUDICACION_NO_ENCONTRADA"}, status=404)


async def generar_anexo_handler(request: web.Request) -> web.Response:
    """Genera anexo técnico en PDF.
    CORRECCION #3: Plantilla Jinja2 completa del anexo.
    """
    try:
        from jinja2 import Template as Jinja2Template
        from weasyprint import HTML as WeasyHTML
    except ImportError:
        return web.json_response({"error": "Jinja2/WeasyPrint no instalados"}, status=501)

    if not await validar_token_jwt(request.headers.get("Authorization", "")):
        return web.json_response({"error": "ERR_UNAUTHORIZED"}, status=401)
    try:
        data = await request.json()
    except json.JSONDecodeError:
        return web.json_response({"error": "ERR_INVALID_JSON"}, status=400)

    adj_id = data.get("adjudicacion_id")
    if not adj_id:
        return web.json_response({"error": "MISSING_ADJUDICACION_ID"}, status=400)

    pool = request.app["pg_pool"]
    async with pool.acquire() as conn:
        adj = await conn.fetchrow("SELECT * FROM adjudicaciones WHERE id = $1", int(adj_id))
    if not adj:
        return web.json_response({"error": "NOT_FOUND"}, status=404)

    datos = json.loads(adj["datos"]) if adj["datos"] else {}
    ajuste = json.loads(adj["ajuste_inflacion"]) if adj["ajuste_inflacion"] else {}

    # CORRECCION #3: Plantilla completa del anexo
    template = Jinja2Template("""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Anexo Técnico - Adjudicación {{ adjudicacion_id }}</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1 { color: #1a237e; border-bottom: 2px solid #1a237e; padding-bottom: 10px; }
            h2 { color: #283593; margin-top: 30px; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #1a237e; color: white; }
            tr:nth-child(even) { background-color: #f5f5f5; }
            .footer { margin-top: 50px; font-size: 10px; color: #666; border-top: 1px solid #ccc; padding-top: 10px; }
            .firma { font-family: monospace; font-size: 9px; color: #333; word-break: break-all; }
        </style>
    </head>
    <body>
        <h1>Anexo Técnico de Adjudicación</h1>
        <p><strong>ID Adjudicación:</strong> {{ adjudicacion_id }}</p>
        <p><strong>Estado:</strong> {{ estado }}</p>
        <p><strong>RFC:</strong> {{ rfc }}</p>
        <p><strong>Fecha de emisión:</strong> {{ fecha }}</p>

        <h2>Resumen Financiero</h2>
        <table>
            <tr><th>Concepto</th><th>Monto</th></tr>
            <tr><td>Monto Original</td><td>${{ "{:,.2f}".format(monto_original) }}</td></tr>
            <tr><td>Monto Ajustado (INPC)</td><td>${{ "{:,.2f}".format(monto_ajustado) }}</td></tr>
            <tr><td>Diferencia</td><td>${{ "{:,.2f}".format(monto_ajustado - monto_original) }}</td></tr>
        </table>

        <h2>Partidas y Especificaciones</h2>
        <table>
            <tr><th>Partida</th><th>Descripción</th></tr>
            {% for p in partidas %}
            <tr><td>{{ loop.index }}</td><td>{{ p }}</td></tr>
            {% endfor %}
        </table>

        <h2>Documentación de Soporte</h2>
        <p>Este anexo se genera de conformidad con la Ley de Adquisiciones, Arrendamientos y Servicios del Sector Público.</p>
        <p>Los cálculos de ajuste por inflación se basan en el INPC publicado por el INEGI a través del Banco de México.</p>

        <div class="footer">
            <p><strong>Firma Digital:</strong></p>
            <p class="firma">{{ firma }}</p>
            <p>Sistema Soberano de 10 Capas — Documento generado automáticamente</p>
        </div>
    </body>
    </html>
    """)

    html = template.render(
        adjudicacion_id=adj_id,
        estado=adj["estado"],
        rfc=datos.get("rfc", ""),
        monto_original=datos.get("monto_total", 0),
        monto_ajustado=ajuste.get("monto_ajustado", 0),
        fecha=datetime.now(timezone.utc).isoformat(),
        partidas=data.get("partidas", ["No especificadas"]),
        firma=firmar_payload_efirma({"adj_id": adj_id, "tipo": "anexo"}).hex()[:64]
    )

    pdf_bytes = WeasyHTML(string=html).write_pdf()
    loop = __import__("asyncio").get_running_loop()
    ruta_temp = os.path.join(settings.SPOOL_DIR, f"anexo_{adj_id}_{int(__import__("time").time())}.pdf")
    with open(ruta_temp, "wb") as f:
        f.write(pdf_bytes)

    from soberano.storage.minio_client import guardar_en_minio_sync
    obj_name = await loop.run_in_executor(
        None, guardar_en_minio_sync, request.app["minio_client"],
        ruta_temp, adj["estado"], __import__("hashlib").sha256(pdf_bytes).hexdigest()
    )
    os.remove(ruta_temp)

    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO anexos (adjudicacion_id, tipo, ruta_minio) VALUES ($1,'tecnico',$2)",
            int(adj_id), obj_name
        )
    await metrics.increment("anexos_generados")
    return web.json_response({"status": "ANEXO_GENERADO", "ruta_minio": obj_name})
