
                await asyncio.sleep(random.uniform(2, 5))
            except Exception as e:
                logger.error(f"Error escaneando {material}: {e}")
                resultados[material] = []
        return resultados

    async def comparar_precios(self, material: str) -> Dict[str, any]:
        """Compara precios de un material entre fuentes."""
        precios = await self.obtener_precios_material(material)
        if not precios:
            return {"material": material, "precios": [], "analisis": None}

        por_tipo = {"mayorista": [], "menudista": [], "fabricante": [], "oficial": [], "marketplace": []}
        for p in precios:
            if p.tipo_precio in por_tipo:
                por_tipo[p.tipo_precio].append(p.precio)

        analisis = {}
        for tipo, vals in por_tipo.items():
            if vals:
                analisis[tipo] = {
                    "min": min(vals),
                    "max": max(vals),
                    "promedio": sum(vals) / len(vals),
                    "mediana": sorted(vals)[len(vals) // 2],
                    "count": len(vals),
                }

        return {
            "material": material,
            "precios": [p.to_dict() for p in precios],
            "analisis": analisis,
            "recomendacion": self._generar_recomendacion(analisis),
            "timestamp": now_iso(),
        }

    def _generar_recomendacion(self, analisis: Dict) -> str:
        """Genera recomendacion de compra basada en analisis de precios."""
        if not analisis:
            return "Sin datos suficientes"
        partes = []
        if "mayorista" in analisis and "menudista" in analisis:
            ratio = analisis["menudista"]["promedio"] / analisis["mayorista"]["promedio"]
            if ratio > 1.5:
                partes.append(f"Diferencia mayorista/menudista: {ratio:.1f}x — comprar al mayoreo")
            else:
                partes.append(f"Diferencia mayorista/menudista: {ratio:.1f}x — precios competitivos")
        if "oficial" in analisis:
            partes.append("Datos oficiales disponibles para validacion contractual")
        return " | ".join(partes) if partes else "Analisis neutral"


# Instancia global
market_engine = MarketIntelligenceEngine()
