# Sistema Soberano de 10 Capas — Modularizado

## Arquitectura

```
soberano/
├── config/          # Configuración, logging, métricas
├── core/            # Seguridad, locks, utilidades, identidad stealth
├── extractors/      # Ghost Extractor + Market Intelligence + Stealth Browser
├── engines/         # Motor A (FinTech), B (RegTech), C (Macro)
├── workers/         # Workers especializados con retry y DLQ
├── api/             # Gateway REST con JWT
├── bots/            # Bot de Telegram
├── storage/         # PostgreSQL, Redis, MinIO
├── parsers/         # PDF parser + cadena de suministro
├── documents/       # Generadores de documentos
└── main.py          # Arranque principal
```

## Correcciones Implementadas

1. **Worker Documental**: Usa `ruta_pdf` directamente, elimina variable `local` indefinida
2. **Import pdfplumber**: Ya está en el módulo `parsers/pdf_parser.py` (no en workers)
3. **Plantilla Anexo**: Template Jinja2 completa con tabla de partidas, firma, estilos CSS
4. **SQL RegTech**: Simplificado con `LIMIT 1` en subconsulta de `cadena_suministro`
5. **Retry + DLQ**: `BaseWorker` con `retry_counts`, backoff exponencial, DLQ solo tras `REDIS_MAX_RETRIES`
6. **FinTech None**: Loguea advertencia cuando `adj_id` no se encuentra

## Inteligencia de Mercado (Nuevo)

- **Fuentes**: Home Depot México, Sodimac, ferreterías mayoristas, CEMEX, Fierros, INEGI/CMIC
- **Materiales**: 50+ materiales de construcción monitoreados
- **Stealth**: Rotación de identidad cada 30 min, proxy pool, canvas noise, WebRTC spoof
- **API**: `/api/v1/market/intel` y `/api/v1/market/precios`
- **Telegram**: `/precios <material>`

## Variables de Entorno Clave

```bash
# Stealth
STEALTH_ROTATION_INTERVAL=1800
STEALTH_USER_AGENT_POOL_SIZE=100
STEALTH_USE_CANVAS_NOISE=true
STEALTH_USE_WEBRTC_SPOOF=true

# Market Intel
MARKET_INTEL_ENABLED=true
MARKET_INTEL_INTERVAL_HOURS=6
MATERIALES_MONITOREO='["cemento gris", "varilla corrugada", ...]'
FUENTES_PRECIOS='{...}'
```

## Ejecución

```bash
pip install -r requirements.txt
python -m soberano.main
```

Para extracción manual:
```bash
python -m soberano.main extract
```
